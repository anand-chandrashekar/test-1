package com.infosys.bian;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.model.CRConsumerLoanCreateInputModel;
import io.swagger.model.CRConsumerLoanCreateOutputModel;
import io.swagger.model.CRConsumerLoanCreateOutputModelConsumerLoanRecord;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementControlInputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementControlOutputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateOutputModel;
import io.swagger.model.CRConsumerLoanRetrieveOutputModel;
import io.swagger.model.CRConsumerLoanRetrieveOutputModelConsumerLoanRecord;
import io.swagger.model.CRConsumerLoanSearchOutputModel;
import io.swagger.model.CRConsumerLoanSearchOutputModelInner;
import io.swagger.model.SDConsumerLoanActivateInputModel;
import io.swagger.model.SDConsumerLoanActivateOutputModel;

public class LDPHelper {
	SparqlHelper sparql = new SparqlHelper();
	public String LDP_URL = "http://ec2-54-198-179-118.compute-1.amazonaws.com:8080";

	public LDPHelper(String ldpUrl) {
		this.LDP_URL = ldpUrl;
		System.out.println("created ldp helper for url " + ldpUrl);
	}

	public static void main(String[] args) throws Exception {
		System.out.println("In main");
		LDPHelper helper = new LDPHelper("http://ec2-52-90-50-241.compute-1.amazonaws.com:8080");
		CRConsumerLoanFulfillmentArrangementInitiateInputModel body = new CRConsumerLoanFulfillmentArrangementInitiateInputModel();
		helper.initiateConsumerLoanFulfillmentArrangement(body);
	}

	public SDConsumerLoanActivateOutputModel activateSDConsumerLoan(SDConsumerLoanActivateInputModel body) {
		// TODO Auto-generated method stub
		return null;
	}

	public CRConsumerLoanFulfillmentArrangementControlOutputModel controlConsumerLoanFulfillmentArrangementUpdate(
			CRConsumerLoanFulfillmentArrangementControlInputModel body) {
		// TODO Auto-generated method stub
		String query = "SELECT distinct ?sessionreference WHERE {\r\n"
				+ "  ?record <http://infosys.bian.com#CustomerReference> \"727556\" .\r\n"
				+ "  ?loan  <http://infosys.bian.com#CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord> ?record .\r\n"
				+ "  ?loan <http://infosys.bian.com#ConsumerLoanServicingSessionReference> ?sessionreference\r\n"
				+ "	\r\n" + "}";
		try {
			String response = sparql.sendPost(SparqlHelper.POST_URL, query);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public CRConsumerLoanFulfillmentArrangementInitiateOutputModel initiateConsumerLoanFulfillmentArrangement(
			CRConsumerLoanFulfillmentArrangementInitiateInputModel body) throws ClientProtocolException, IOException {

		System.out.println(" Calling backend ...");
		CRConsumerLoanFulfillmentArrangementInitiateOutputModel apiResponse = new CRConsumerLoanFulfillmentArrangementInitiateOutputModel();

		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(LDP_URL + "/marmotta/ldp");
		// setup slugs
		String slug = "initiate_loan_" + UUID.randomUUID();
		String slugindividual = "parent:" + slug;

		StringBuffer bodyLines = new StringBuffer();
		bodyLines.append("<>" + " a ldp:Resource , ldp:RDFSource , ldp:Container , ldp:BasicContainer.\r\n");
		bodyLines.append("<>" + "<http://infosys.bian.com#" + "ConsumerLoanServicingSessionReference" + "> " + "\""
				+ body.getConsumerLoanServicingSessionReference() + "\"" + ". \r\n");
		bodyLines.append("<>" + "<http://infosys.bian.com#" + "ConsumerLoanFulfillmentArrangementInstanceStatus" + "> "
				+ "\"" + body.getConsumerLoanFulfillmentArrangementInstanceStatus() + "\"" + ". \r\n");
		// process record
		CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord record = body
				.getConsumerLoanFulfillmentArrangementInstanceRecord();
		String recordNode = "<http://infosys.bian.com#record" + UUID.randomUUID() + "> ";
		bodyLines.append("<>" + "<http://infosys.bian.com#"
				+ "CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord"
				+ "> " + recordNode + ". \r\n");
		bodyLines.append(
				recordNode + "<http://infosys.bian.com#" + "consumerLoanNumber" + "> " + "\"" + slug + "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "customerReference" + "> " + "\""
				+ record.getCustomerReference() + "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "loanType" + "> " + "\"" + record.getLoanType()
				+ "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "loanAmount" + "> " + "\"" + record.getLoanAmount()
				+ "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "loanCurrency" + "> " + "\""
				+ record.getLoanCurrency() + "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "loanRateType" + "> " + "\""
				+ record.getLoanRateType() + "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "loanApplicableRate" + "> " + "\""
				+ record.getLoanApplicableRate() + "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "customerCommentary" + "> " + "\""
				+ record.getCustomerCommentary() + "\"" + ". \r\n");
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "productInstanceReference" + "> " + "\""
				+ record.getInsuranceReference() + "\"" + ". \r\n");

		
		bodyLines.append(recordNode + "<http://infosys.bian.com#" + "LoanAmount" + "> " + "\"" + record.getLoanAmount()
				+ "\"" + ". \r\n");

		bodyLines.append("<> rdfs:comment \"this is a loan initiation request\"^^xsd:string .");

		String ttl = createPrefixTurtle() + bodyLines.toString();
		System.out.println(ttl);

		StringEntity entity = new StringEntity(ttl);
		httpPost.setEntity(entity);

		httpPost.setHeader("Content-Type", "text/turtle");
		httpPost.setHeader("Slug", slug);

		CloseableHttpResponse response = client.execute(httpPost);
		System.out.println(response.getStatusLine());
//	    assertThat(response.getStatusLine().getStatusCode(), equalTo(200));
		client.close();
		System.out.println("created initiate loan request " + slugindividual);

		//
		apiResponse.setConsumerLoanFulfillmentArrangementInitiateActionReference(LDP_URL + "/marmotta/ldp/" + slug);
		return apiResponse;
	}

	private String createPrefixTurtle() {
		String prefix = "@prefix ldp: <http://www.w3.org/ns/ldp#> .\r\n"
				+ "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\r\n"
				+ "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\r\n"
				+ "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\r\n"
				+ "@prefix dcterms: <http://purl.org/dc/terms/> .\r\n"
				+ "@prefix parent: <http://localhost:8080/marmotta/ldp/> .\r\n";
		return prefix;
	}

	public CRConsumerLoanRetrieveOutputModel retrieveConsumerLoan(String correlationId, String loanId)
			throws IOException {
		String query = "SELECT distinct * WHERE {\r\n"
				+ "  ?subject <http://infosys.bian.com#CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord> ?record .\r\n"
				+ " ?record <http://infosys.bian.com#consumerLoanNumber> \"" + loanId + "\" .\r\n"
				+ " ?record <http://infosys.bian.com#customerCommentary> ?commentary .\r\n"
				+ " ?record <http://infosys.bian.com#LoanAmount> ?loanAmount .\r\n"
				+ " ?record <http://infosys.bian.com#customerReference> ?customerReference .\r\n"
				+ " ?record <http://infosys.bian.com#loanApplicableRate> ?loanApplicableRate .\r\n"
				+ " ?record <http://infosys.bian.com#loanCurrency> ?loanCurrency .\r\n"
				+ " ?record <http://infosys.bian.com#loanRateType> ?loanRateType .\r\n"				
				+ " ?record <http://infosys.bian.com#productInstanceReference> ?productInstanceReference .\r\n"
				+ " ?record <http://infosys.bian.com#loanType> ?loanType .\r\n" + "}\r\n" + "\r\n";
		URL obj = new URL(LDP_URL + "/marmotta/sparql/select");
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Accept", "application/sparql-results+json");
		con.setRequestProperty("Content-Type", "application/sparql-query;charset=UTF-8");

		// For POST only - START
		con.setDoOutput(true);
		OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
		System.out.println("Sending query " + query);
		writer.write(query);
		writer.flush();
		writer.close();

		int responseCode = con.getResponseCode();
		System.out.println("POST Response Code :: " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
		System.out.println(response.toString());
//		return response.toString();

		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readValue(response.toString(), JsonNode.class);
		String loanName = jsonNode.get("results").get("bindings").get(0).get("commentary").get("value").asText();
//		String loanNumber=jsonNode.get("results").get("bindings").get(0).get("loanNumber").get("value").asText();
		String loanAmount = jsonNode.get("results").get("bindings").get(0).get("loanAmount").get("value").asText();
		String customerReference = jsonNode.get("results").get("bindings").get(0).get("customerReference").get("value")
				.asText();
		String loanApplicableRate = jsonNode.get("results").get("bindings").get(0).get("loanApplicableRate")
				.get("value").asText();
		String loanCurrency = jsonNode.get("results").get("bindings").get(0).get("loanCurrency").get("value").asText();
		String loanRateType = jsonNode.get("results").get("bindings").get(0).get("loanRateType").get("value").asText();
		String loanType = jsonNode.get("results").get("bindings").get(0).get("loanType").get("value").asText();
		String productInstanceReference = jsonNode.get("results").get("bindings").get(0).get("productInstanceReference").get("value").asText();
		System.out.println(loanName + ":" + loanId);

		// prepare response
		CRConsumerLoanRetrieveOutputModel retrieveResponse = new CRConsumerLoanRetrieveOutputModel();
		CRConsumerLoanRetrieveOutputModelConsumerLoanRecord consumerLoanRecord = new CRConsumerLoanRetrieveOutputModelConsumerLoanRecord();
		consumerLoanRecord.setConsumerLoanName(loanName);
		consumerLoanRecord.setConsumerLoanNumber(loanId);
		consumerLoanRecord.setCustomerReference(customerReference);
		consumerLoanRecord.setLoanAmount(loanAmount);
		consumerLoanRecord.setLoanApplicableRate(loanApplicableRate);
		consumerLoanRecord.setLoanCurrency(loanCurrency);
		consumerLoanRecord.setLoanRateType(loanRateType);
		consumerLoanRecord.setLoanType(loanType);
		consumerLoanRecord.setProductInstanceReference(productInstanceReference);

		retrieveResponse.setConsumerLoanRecord(consumerLoanRecord);
		return retrieveResponse;
	}

	public void call_initiate_backend() throws ClientProtocolException, IOException {
		CRConsumerLoanFulfillmentArrangementInitiateInputModel body = new CRConsumerLoanFulfillmentArrangementInitiateInputModel();
		CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord record = new CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord();
		// populate record
		record.setCustomerAgreementReference("some reference");
		record.setLoanAmount("USD2501");
		body.setConsumerLoanFulfillmentArrangementInstanceRecord(record);

		ObjectMapper objectMapper = new ObjectMapper();
		String bodyString = objectMapper.writeValueAsString(body);

		// call http
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(
				"http://localhost:8080/BIAN/sd-consumer-loan/1.0.0/consumer-loan/consumer-loan-fulfillment-arrangement/initiation");
		System.out.println("posting string \n" + bodyString);
		StringEntity entity = new StringEntity(bodyString);
		httpPost.setEntity(entity);
		System.out.println("created and set the entity");

		httpPost.setHeader("Accept", "application/json");
		httpPost.setHeader("Content-Type", "application/json");

		CloseableHttpResponse httpResponse = client.execute(httpPost);

		BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = reader.readLine()) != null) {
			response.append(inputLine);
		}
		reader.close();
		System.out.println(response.toString());

	}

	public CRConsumerLoanCreateOutputModel call_initiate_backend(String correlationId,
			CRConsumerLoanCreateInputModel sourceBody) throws ClientProtocolException, IOException {
		CRConsumerLoanFulfillmentArrangementInitiateInputModel body = new CRConsumerLoanFulfillmentArrangementInitiateInputModel();
		CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord record = new CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord();
		// populate record
		record.setCustomerReference(sourceBody.getConsumerLoanRecord().getCustomerReference());
		record.setLoanAmount(sourceBody.getConsumerLoanRecord().getLoanAmount());
		record.setLoanApplicableRate(sourceBody.getConsumerLoanRecord().getLoanApplicableRate());
		record.setLoanCurrency(sourceBody.getConsumerLoanRecord().getLoanCurrency());
		record.setLoanRateType(sourceBody.getConsumerLoanRecord().getLoanRateType());
		record.setLoanType(sourceBody.getConsumerLoanRecord().getLoanType());
		record.setCustomerCommentary(sourceBody.getConsumerLoanRecord().getConsumerLoanName());
		record.setInsuranceReference(sourceBody.getConsumerLoanRecord().getProductInstanceReference());
		record.setPartyReference(correlationId);
//		record.setLoanAmount("USD2501");
		body.setConsumerLoanFulfillmentArrangementInstanceRecord(record);

		ObjectMapper objectMapper = new ObjectMapper();
		String bodyString = objectMapper.writeValueAsString(body);

		// call http
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(
				"http://localhost:8080/BIAN/sd-consumer-loan/1.0.0/consumer-loan/consumer-loan-fulfillment-arrangement/initiation");
		System.out.println("posting string \n" + bodyString);
		StringEntity entity = new StringEntity(bodyString);
		httpPost.setEntity(entity);
		System.out.println("created and set the entity");

		httpPost.setHeader("Accept", "application/json");
		httpPost.setHeader("Content-Type", "application/json");

		CloseableHttpResponse httpResponse = client.execute(httpPost);

		BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = reader.readLine()) != null) {
			response.append(inputLine);
		}
		reader.close();
		System.out.println(response.toString());

		CRConsumerLoanFulfillmentArrangementInitiateOutputModel callResponse = objectMapper
				.readValue(response.toString(), CRConsumerLoanFulfillmentArrangementInitiateOutputModel.class);
		System.out.println("converted");
		CRConsumerLoanCreateOutputModel output = new CRConsumerLoanCreateOutputModel();
		CRConsumerLoanCreateOutputModelConsumerLoanRecord consumerLoanRecord = new CRConsumerLoanCreateOutputModelConsumerLoanRecord();
		consumerLoanRecord
				.setConsumerLoanNumber(callResponse.getConsumerLoanFulfillmentArrangementInitiateActionReference());
		output.setConsumerLoanRecord(consumerLoanRecord);
		System.out.println("Loan number is " + consumerLoanRecord.getConsumerLoanNumber());
		return output;

	}

	public CRConsumerLoanSearchOutputModel searchByCustomerReference(String customerReference)
			throws UnsupportedEncodingException, IOException {
		String query = "SELECT distinct * WHERE {\r\n"
				+ "  ?subject <http://infosys.bian.com#CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord> ?record .\r\n"
				+ " ?record <http://infosys.bian.com#customerReference> \"" + customerReference + "\" .\r\n"
				+ " ?record <http://infosys.bian.com#consumerLoanNumber> ?loanNumber .\r\n"
				+ " ?record <http://infosys.bian.com#customerCommentary> ?commentary .\r\n" + "}\r\n" + "\r\n";
		URL obj = new URL(LDP_URL + "/marmotta/sparql/select");
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Accept", "application/sparql-results+json");
		con.setRequestProperty("Content-Type", "application/sparql-query;charset=UTF-8");

		// For POST only - START
		con.setDoOutput(true);
		OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
		System.out.println("Sending query " + query);
		writer.write(query);
		writer.flush();
		writer.close();

		int responseCode = con.getResponseCode();
		System.out.println("POST Response Code :: " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
		System.out.println(response.toString());
//		return response.toString();

		// prepare response
		CRConsumerLoanSearchOutputModel searchResponse = new CRConsumerLoanSearchOutputModel();
		CRConsumerLoanSearchOutputModelInner searchResponseLineItem = null;
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readValue(response.toString(), JsonNode.class);
		for (int i = 0; i < jsonNode.get("results").get("bindings").size(); i++) {

			String loanName = jsonNode.get("results").get("bindings").get(i).get("commentary").get("value").asText();
			String loanNumber = jsonNode.get("results").get("bindings").get(i).get("loanNumber").get("value").asText();
			System.out.println(loanName + ":" + loanNumber);
			searchResponseLineItem = new CRConsumerLoanSearchOutputModelInner();
			searchResponseLineItem.setConsumerLoanName(loanName);
			searchResponseLineItem.setConsumerLoanNumber(loanNumber);
			searchResponse.add(searchResponseLineItem);
		}
		return searchResponse;
	}

}
