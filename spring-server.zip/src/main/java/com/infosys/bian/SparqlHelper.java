package com.infosys.bian;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SparqlHelper {
	public static final String POST_URL = "http://ec2-52-90-50-241.compute-1.amazonaws.com:8080/marmotta/sparql/select";
	public static final String query = "SELECT * WHERE {\r\n"
			+ "  <http://ec2-52-90-50-241.compute-1.amazonaws.com:8080/marmotta/ldp/bian1567337864235> ?property ?object\r\n"
			+ "}\r\n";
//			"LIMIT 10";

	public static void main(String[] args) throws Exception {
		System.out.println("in main");
		new SparqlHelper().sendQuery("727556");
	}

	public String sendPost(String sparqlEndpoint, String postableQuery) throws Exception {
		URL obj = new URL(sparqlEndpoint);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Accept", "application/sparql-results+json");
		con.setRequestProperty("Content-Type", "application/sparql-query;charset=UTF-8");

		// For POST only - START
		con.setDoOutput(true);
		OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
		System.out.println("Sending query " + query);
		writer.write(query);
		writer.flush();
		writer.close();
//		OutputStream os = con.getOutputStream();
//		os.wr
//		os.write(postableQuery);
//		os.flush();
//		os.close();
		// For POST only - END

		int responseCode = con.getResponseCode();
		System.out.println("POST Response Code :: " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
		System.out.println(response.toString());
		return response.toString();
	}

	void sendQuery(String customerReference) throws Exception {
		LDPHelper helper = new LDPHelper("http://ec2-54-198-179-118.compute-1.amazonaws.com:8080");
		String query = "SELECT distinct * WHERE {\r\n"
				+ "  ?subject <http://infosys.bian.com#CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord> ?record .\r\n"
				+ " ?record <http://infosys.bian.com#customerReference> \"" + customerReference + "\" .\r\n"
				+ " ?record <http://infosys.bian.com#consumerLoanNumber> ?loanNumber .\r\n"
				+ " ?record <http://infosys.bian.com#customerCommentary> ?commentary .\r\n" + "}\r\n" + "\r\n";
		URL obj = new URL(helper.LDP_URL + "/marmotta/sparql/select");
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Accept", "application/sparql-results+json");
		con.setRequestProperty("Content-Type", "application/sparql-query;charset=UTF-8");

		// For POST only - START
		con.setDoOutput(true);
		OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
		System.out.println("Sending query " + query);
		writer.write(query);
		writer.flush();
		writer.close();

		int responseCode = con.getResponseCode();
		System.out.println("POST Response Code :: " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
		System.out.println(response.toString());

		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readValue(response.toString(), JsonNode.class);
		String loanName=jsonNode.get("results").get("bindings").get(0).get("commentary").get("value").asText();
		String loanNumber=jsonNode.get("results").get("bindings").get(0).get("loanNumber").get("value").asText();
		System.out.println(loanName + ":" + loanNumber);
		
	}

}
