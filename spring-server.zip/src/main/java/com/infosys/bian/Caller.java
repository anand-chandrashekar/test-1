package com.infosys.bian;

import java.io.File;
import java.util.List;
import java.util.Map;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;

public class Caller {
	static OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
	static String slug="bian"+System.currentTimeMillis();
	static String slugindividual="parent:"+slug;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("in main");

		Caller caller = new Caller();
		
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost("http://ec2-52-90-50-241.compute-1.amazonaws.com:8080/marmotta/ldp");

		String ttl = "@prefix ldp: <http://www.w3.org/ns/ldp#> .\r\n" + 
				"@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\r\n" + 
				"@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\r\n" + 
				"@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\r\n" + 
				"@prefix dcterms: <http://purl.org/dc/terms/> .\r\n" + 
				"@prefix parent: <http://localhost:8080/marmotta/ldp/> .\r\n" + 
				"<> a ldp:Resource , ldp:RDFSource , ldp:Container , ldp:BasicContainer.\r\n" + 
				"<> <http://infosys.bian.com#ConsumerLoanServicingSessionReference> \"CLSSRTT3198\".\r\n" + 
				"<> <http://infosys.bian.com#ConsumerLoanFulfillmentArrangementInstanceStatus> \"string\".\r\n" + 
				"<> <http://infosys.bian.com#CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecord> <http://infosys.bian.com#recordbc9c50d1-9637-4012-8521-b2ad1ca78af5> .\r\n" + 
//				"<http://infosys.bian.com#recordbc9c50d1-9637-4012-8521-b2ad1ca78af5> <http://infosys.bian.com#CustomerReference> \"727556\";\r\n" + 
//				"<http://infosys.bian.com#recordbc9c50d1-9637-4012-8521-b2ad1ca78af5> <http://infosys.bian.com#LoanAmount> \"USD 250\";\r\n" + 
				"<> rdfs:comment \"this is a loan initiation request\"^^xsd:string ."+ 
				"<http://infosys.bian.com#recordbc9c50d1-9637-4012-8521-b2ad1ca78af5> <http://infosys.bian.com#CustomerReference> \"727556\".\r\n" +
				"<http://infosys.bian.com#recordbc9c50d1-9637-4012-8521-b2ad1ca78af5> <http://infosys.bian.com#LoanAmount> \"USD 250\".\r\n" ;
//		String ttl=caller.createPrefixTurtle()+caller.createBody();
		System.out.println(ttl);
		
		StringEntity entity = new StringEntity(ttl);
		httpPost.setEntity(entity);
		
		httpPost.setHeader("Content-Type", "text/turtle");
		httpPost.setHeader("Slug", slug);

		CloseableHttpResponse response = client.execute(httpPost);
		System.out.println(response.getStatusLine());
//	    assertThat(response.getStatusLine().getStatusCode(), equalTo(200));
		client.close();
		System.out.println("created api "+ slug);
	}

	public String createPrefixTurtle() {
		String prefix = "@prefix ldp: <http://www.w3.org/ns/ldp#> .\r\n"
				+ "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\r\n"
				+ "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\r\n"
				+ "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\r\n"
				+ "@prefix dcterms: <http://purl.org/dc/terms/> .\r\n"
				+ "@prefix parent: <http://localhost:8080/marmotta/ldp/> .\r\n";
		return prefix;
	}

	public String createBody() throws Exception {
		StringBuffer bodyLines = new StringBuffer();
		bodyLines.append(slugindividual+" a ldp:Resource , ldp:RDFSource , ldp:Container , ldp:BasicContainer;\r\n");
//
//		OWLOntology ontology = manager.loadOntologyFromOntologyDocument(new File(fileName));
//		Map<OWLObjectProperty, List<OWLNamedIndividual>> apiProperties = new TurtleAPIDefinitionWriter()
//				.getAPIProperties(ontology);
//
//		for (OWLObjectProperty p : apiProperties.keySet()) {
//			List<OWLNamedIndividual> namedIndividuals = apiProperties.get(p);
//			if (namedIndividuals.size() > 0) {
//				for(OWLNamedIndividual namedIndividual:namedIndividuals) {
//					String line = p +" "+ namedIndividual +"; \r\n";
//					bodyLines.append(line);
//				}
//			} else {
//				//do nothing
////				String line = p +" "+ "<rdfs:Resource> ; \r\n";
////				bodyLines.append(line);
//			}
//		}
		bodyLines.append("rdfs:comment \"this is a dynamically created api\"^^xsd:string .");
		return bodyLines.toString();
	}
}
