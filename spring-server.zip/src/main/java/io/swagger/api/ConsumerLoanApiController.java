package io.swagger.api;

import io.swagger.model.BQDisbursementRetrieveInputModel;
import io.swagger.model.BQDisbursementRetrieveOutputModel;
import io.swagger.model.BQInterestRetrieveInputModel;
import io.swagger.model.BQInterestRetrieveOutputModel;
import io.swagger.model.BQMaintenanceRequestInputModel;
import io.swagger.model.BQMaintenanceRequestOutputModel;
import io.swagger.model.BQMaintenanceRetrieveInputModel;
import io.swagger.model.BQMaintenanceRetrieveOutputModel;
import io.swagger.model.BQRepaymentExecuteInputModel;
import io.swagger.model.BQRepaymentExecuteOutputModel;
import io.swagger.model.BQRepaymentRequestInputModel;
import io.swagger.model.BQRepaymentRequestOutputModel;
import io.swagger.model.BQRepaymentRetrieveInputModel;
import io.swagger.model.BQRepaymentRetrieveOutputModel;
import io.swagger.model.BQRepaymentUpdateInputModel;
import io.swagger.model.BQRepaymentUpdateOutputModel;
import io.swagger.model.BQRestructuringExchangeInputModel;
import io.swagger.model.BQRestructuringExchangeOutputModel;
import io.swagger.model.BQRestructuringInitiateInputModel;
import io.swagger.model.BQRestructuringInitiateOutputModel;
import io.swagger.model.BQRestructuringRequestInputModel;
import io.swagger.model.BQRestructuringRequestOutputModel;
import io.swagger.model.BQRestructuringRetrieveInputModel;
import io.swagger.model.BQRestructuringRetrieveOutputModel;
import io.swagger.model.BQRestructuringUpdateInputModel;
import io.swagger.model.BQRestructuringUpdateOutputModel;
import io.swagger.model.BQServiceFeesExecuteInputModel;
import io.swagger.model.BQServiceFeesExecuteOutputModel;
import io.swagger.model.BQServiceFeesRetrieveInputModel;
import io.swagger.model.BQServiceFeesRetrieveOutputModel;
import io.swagger.model.BQWithdrawalExecuteInputModel;
import io.swagger.model.BQWithdrawalExecuteOutputModel;
import io.swagger.model.BQWithdrawalRequestInputModel;
import io.swagger.model.BQWithdrawalRequestOutputModel;
import io.swagger.model.BQWithdrawalRetrieveInputModel;
import io.swagger.model.BQWithdrawalRetrieveOutputModel;
import io.swagger.model.BQWithdrawalUpdateInputModel;
import io.swagger.model.BQWithdrawalUpdateOutputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementControlInputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementControlOutputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateOutputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveInputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveOutputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementUpdateInputModel;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementUpdateOutputModel;
import io.swagger.model.SDConsumerLoanActivateInputModel;
import io.swagger.model.SDConsumerLoanActivateOutputModel;
import io.swagger.model.SDConsumerLoanConfigureInputModel;
import io.swagger.model.SDConsumerLoanConfigureOutputModel;
import io.swagger.model.SDConsumerLoanFeedbackInputModel;
import io.swagger.model.SDConsumerLoanFeedbackOutputModel;
import io.swagger.model.SDConsumerLoanRetrieveInputModel;
import io.swagger.model.SDConsumerLoanRetrieveOutputModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.bian.LDPHelper;

import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

@Controller
public class ConsumerLoanApiController implements ConsumerLoanApi {
	
	@Value("${ldp.url}")
	private String ldpUrl;
	
	

    private static final Logger log = LoggerFactory.getLogger(ConsumerLoanApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public ConsumerLoanApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<SDConsumerLoanActivateOutputModel> activateSDConsumerLoan(@ApiParam(value = "SDConsumerLoan Request Payload" ,required=true )  @Valid @RequestBody SDConsumerLoanActivateInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<SDConsumerLoanActivateOutputModel>(objectMapper.readValue("{  \"serviceDomainServicingSessionStatus\" : \"serviceDomainServicingSessionStatus\",  \"serviceDomainServicingSessionReference\" : \"SSSR783215\",  \"serviceDomainServicingSessionRecord\" : \"{}\",  \"serviceDomainActivationActionTaskReference\" : \"SAATR758836\",  \"serviceDomainActivationActionTaskRecord\" : \"{}\",  \"serviceDomainServiceConfigurationRecord\" : {    \"serviceDomainServiceStatus\" : \"serviceDomainServiceStatus\",    \"serviceDomainServiceConfigurationSettingDescription\" : \"serviceDomainServiceConfigurationSettingDescription\",    \"serviceDomainServiceConfigurationSetup\" : {      \"serviceDomainServiceConfigurationParameter\" : \"serviceDomainServiceConfigurationParameter\"    },    \"serviceDomainServiceAgreement\" : {      \"serviceDomainServiceAgreementReference\" : \"791202\",      \"serviceDomainServiceAgreementTermsandConditions\" : \"serviceDomainServiceAgreementTermsandConditions\",      \"serviceDomainServiceUserReference\" : \"767210\"    },    \"serviceDomainServiceConfigurationSettingReference\" : \"700761\",    \"serviceDomainServiceSubscription\" : {      \"serviceDomainServiceSubscriberAccessProfile\" : \"serviceDomainServiceSubscriberAccessProfile\",      \"serviceDomainServiceSubscriberReference\" : \"769192\"    }  }}", SDConsumerLoanActivateOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<SDConsumerLoanActivateOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<SDConsumerLoanActivateOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<SDConsumerLoanConfigureOutputModel> configureSDConsumerLoan(@ApiParam(value = "SDConsumerLoan Configure Request Payload" ,required=true )  @Valid @RequestBody SDConsumerLoanConfigureInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<SDConsumerLoanConfigureOutputModel>(objectMapper.readValue("{  \"serviceDomainServicingSessionStatus\" : \"serviceDomainServicingSessionStatus\",  \"serviceDomainConfigurationActionTaskRecord\" : \"{}\",  \"serviceDomainConfigurationActionTaskReference\" : \"SCATR765419\",  \"serviceDomainServiceConfigurationRecord\" : {    \"serviceDomainServiceStatus\" : \"serviceDomainServiceStatus\",    \"serviceDomainServiceConfigurationSettingDescription\" : \"serviceDomainServiceConfigurationSettingDescription\",    \"serviceDomainServiceConfigurationSetup\" : {      \"serviceDomainServiceConfigurationParameter\" : \"serviceDomainServiceConfigurationParameter\"    },    \"serviceDomainServiceAgreement\" : {      \"serviceDomainServiceAgreementReference\" : \"721156\",      \"serviceDomainServiceAgreementTermsandConditions\" : \"serviceDomainServiceAgreementTermsandConditions\",      \"serviceDomainServiceUserReference\" : \"733696\"    },    \"serviceDomainServiceSubscription\" : {      \"serviceDomainServiceSubscriberAccessProfile\" : \"serviceDomainServiceSubscriberAccessProfile\",      \"serviceDomainServiceSubscriberReference\" : \"756221\"    }  }}", SDConsumerLoanConfigureOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<SDConsumerLoanConfigureOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<SDConsumerLoanConfigureOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<CRConsumerLoanFulfillmentArrangementControlOutputModel> controlConsumerLoanFulfillmentArrangementUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "ConsumerLoanFulfillmentArrangement Request Payload" ,required=true )  @Valid @RequestBody CRConsumerLoanFulfillmentArrangementControlInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementControlOutputModel>(objectMapper.readValue("{  \"consumerLoanFulfillmentArrangementControlActionTaskRecord\" : \"{}\",  \"consumerLoanFulfillmentArrangementControlActionTaskReference\" : \"CLFACATR722455\",  \"consumerLoanFulfillmentArrangementControlActionResponse\" : \"consumerLoanFulfillmentArrangementControlActionResponse\"}", CRConsumerLoanFulfillmentArrangementControlOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementControlOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<CRConsumerLoanFulfillmentArrangementControlOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRestructuringExchangeOutputModel> exchangeConsumerLoanFulfillmentArrangementRestructuringUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Restructuring BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Restructuring request payload" ,required=true )  @Valid @RequestBody BQRestructuringExchangeInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRestructuringExchangeOutputModel>(objectMapper.readValue("{  \"restructuringInstanceStatus\" : \"restructuringInstanceStatus\",  \"restructuringExchangeActionResponse\" : \"restructuringExchangeActionResponse\",  \"restructuringExchangeActionTaskReference\" : \"REATR729446\",  \"restructuringExchangeActionTaskRecord\" : \"{}\"}", BQRestructuringExchangeOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRestructuringExchangeOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRestructuringExchangeOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRepaymentExecuteOutputModel> executeConsumerLoanFulfillmentArrangementRepaymentUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Repayment BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Repayment request payload" ,required=true )  @Valid @RequestBody BQRepaymentExecuteInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRepaymentExecuteOutputModel>(objectMapper.readValue("{  \"repaymentExecuteRecordReference\" : \"RERR718935\",  \"executeResponseRecord\" : \"{}\",  \"repaymentExecuteActionTaskReference\" : \"REATR734947\",  \"repaymentExecuteActionTaskRecord\" : \"{}\"}", BQRepaymentExecuteOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRepaymentExecuteOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRepaymentExecuteOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQServiceFeesExecuteOutputModel> executeConsumerLoanFulfillmentArrangementServiceFeesUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "ServiceFees BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "ServiceFees request payload" ,required=true )  @Valid @RequestBody BQServiceFeesExecuteInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQServiceFeesExecuteOutputModel>(objectMapper.readValue("{  \"serviceFeesExecuteActionTaskRecord\" : \"{}\",  \"serviceFeesExecuteRecordReference\" : \"SFERR748496\",  \"executeResponseRecord\" : \"{}\",  \"serviceFeesExecuteActionTaskReference\" : \"SFEATR713583\",  \"serviceFeesInstanceRecord\" : {    \"feeConfigurationProfile\" : {      \"feeDefinition\" : \"feeDefinition\"    },    \"feeApplicationRecord\" : {      \"feeAccrualAmount\" : {        \"accrualFeeType\" : \"accrualFeeType\",        \"accrualFeeCharge\" : \"USD 250\"      },      \"feeTransaction\" : {        \"transactionFeeCharge\" : \"USD 250\",        \"transactionFeeType\" : \"transactionFeeType\"      },      \"feeProjectionsandCommitments\" : {        \"projectedTransactionFeeType\" : \"projectedTransactionFeeType\",        \"projectedTransactionFeeCharge\" : \"USD 250\"      }    }  }}", BQServiceFeesExecuteOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQServiceFeesExecuteOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQServiceFeesExecuteOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQWithdrawalExecuteOutputModel> executeConsumerLoanFulfillmentArrangementWithdrawalUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Withdrawal BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Withdrawal request payload" ,required=true )  @Valid @RequestBody BQWithdrawalExecuteInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQWithdrawalExecuteOutputModel>(objectMapper.readValue("{  \"withdrawalExecuteRecordReference\" : \"WERR765203\",  \"executeResponseRecord\" : \"{}\",  \"withdrawalExecuteActionTaskRecord\" : \"{}\",  \"withdrawalExecuteActionTaskReference\" : \"WEATR783508\"}", BQWithdrawalExecuteOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQWithdrawalExecuteOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQWithdrawalExecuteOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<SDConsumerLoanFeedbackOutputModel> feedbackSDConsumerLoan(@ApiParam(value = "SDConsumerLoan Feedback Request Payload" ,required=true )  @Valid @RequestBody SDConsumerLoanFeedbackInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<SDConsumerLoanFeedbackOutputModel>(objectMapper.readValue("{  \"serviceDomainFeedbackActionTaskReference\" : \"SFATR765157\",  \"serviceDomainFeedbackActionRecord\" : {    \"employeeBusinessUnitReference\" : \"769031\",    \"feedbackRecordStatus\" : \"feedbackRecordStatus\",    \"feedbackRecordDateTime\" : \"09-22-2018\"  },  \"serviceDomainFeedbackActionTaskRecord\" : \"{}\"}", SDConsumerLoanFeedbackOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<SDConsumerLoanFeedbackOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<SDConsumerLoanFeedbackOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<CRConsumerLoanFulfillmentArrangementInitiateOutputModel> initiateConsumerLoanFulfillmentArrangement(@ApiParam(value = "ConsumerLoanFulfillmentArrangement Request Payload" ,required=true )  @Valid @RequestBody CRConsumerLoanFulfillmentArrangementInitiateInputModel body) {
    	//TO DO initiation
    	LDPHelper helper=new LDPHelper(ldpUrl);
        String accept = request.getHeader("Accept");
        
        if (accept != null && accept.contains("application/json")) {
            try {
            	// call LDP Helper
            	System.out.println(" Calling LDP Helper ");
            	CRConsumerLoanFulfillmentArrangementInitiateOutputModel apiResponse = helper.initiateConsumerLoanFulfillmentArrangement(body);
//                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementInitiateOutputModel>(objectMapper.readValue("{  \"consumerLoanFulfillmentArrangementInitiateActionReference\" : \"CLFAIAR739165\",  \"consumerLoanFulfillmentArrangementInstanceReference\" : \"CLFAIR701727\",  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"productInstanceReference\" : \"748861\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"stagedRepaymentStatement\" : \"stagedRepaymentStatement\",    \"customerCommentary\" : \"customerCommentary\"  },  \"consumerLoanFulfillmentArrangementInitiateActionRecord\" : \"{}\",  \"consumerLoanFulfillmentArrangementInstanceStatus\" : \"consumerLoanFulfillmentArrangementInstanceStatus\"}", CRConsumerLoanFulfillmentArrangementInitiateOutputModel.class), HttpStatus.CREATED);
            	return new ResponseEntity<CRConsumerLoanFulfillmentArrangementInitiateOutputModel>(apiResponse, HttpStatus.CREATED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementInitiateOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<CRConsumerLoanFulfillmentArrangementInitiateOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRestructuringInitiateOutputModel> initiateConsumerLoanFulfillmentArrangementRestructuring(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Restructuring Request Payload" ,required=true )  @Valid @RequestBody BQRestructuringInitiateInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRestructuringInitiateOutputModel>(objectMapper.readValue("{  \"restructuringInstanceStatus\" : \"restructuringInstanceStatus\",  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"stagedRepaymentStatement\" : \"stagedRepaymentStatement\",    \"customerCommentary\" : \"customerCommentary\"  },  \"restructuringInstanceReference\" : \"RIR731688\",  \"restructuringInitiateActionReference\" : \"RIAR737902\",  \"restructuringInitiateActionRecord\" : \"{}\",  \"restructuringInstanceRecord\" : {    \"restructuringEvaluation\" : \"restructuringEvaluation\",    \"restructuringWriteDown\" : \"restructuringWriteDown\",    \"restructuringTask\" : \"restructuringTask\"  }}", BQRestructuringInitiateOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRestructuringInitiateOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRestructuringInitiateOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQMaintenanceRequestOutputModel> requestConsumerLoanFulfillmentArrangementMaintenanceUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Maintenance BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Maintenance request payload" ,required=true )  @Valid @RequestBody BQMaintenanceRequestInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQMaintenanceRequestOutputModel>(objectMapper.readValue("{  \"maintenanceRequestActionTaskRecord\" : \"{}\",  \"maintenanceRequestActionTaskReference\" : \"MRATR745107\",  \"maintenanceInstanceRecord\" : {    \"maintenanceReportType\" : {      \"penalties\" : \"penalties\",      \"loanFees\" : \"loanFees\",      \"collateralValuation\" : \"collateralValuation\",      \"loanFeeType\" : \"loanFeeType\",      \"loanTaxReport\" : \"{}\"    }  },  \"maintenanceRequestRecordReference\" : \"MRRR746772\",  \"requestResponseRecord\" : \"{}\"}", BQMaintenanceRequestOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQMaintenanceRequestOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQMaintenanceRequestOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRepaymentRequestOutputModel> requestConsumerLoanFulfillmentArrangementRepaymentUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Repayment BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Repayment request payload" ,required=true )  @Valid @RequestBody BQRepaymentRequestInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRepaymentRequestOutputModel>(objectMapper.readValue("{  \"repaymentRequestRecordReference\" : \"RRRR731602\",  \"repaymentRequestActionTaskReference\" : \"RRATR712892\",  \"repaymentRequestActionTaskRecord\" : \"{}\",  \"requestResponseRecord\" : \"{}\"}", BQRepaymentRequestOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRepaymentRequestOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRepaymentRequestOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRestructuringRequestOutputModel> requestConsumerLoanFulfillmentArrangementRestructuringUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Restructuring BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Restructuring request payload" ,required=true )  @Valid @RequestBody BQRestructuringRequestInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRestructuringRequestOutputModel>(objectMapper.readValue("{  \"restructuringRequestActionTaskRecord\" : \"{}\",  \"restructuringRequestRecordReference\" : \"RRRR783109\",  \"restructuringRequestActionTaskReference\" : \"RRATR771841\",  \"restructuringInstanceRecord\" : {    \"restructuringEvaluation\" : \"restructuringEvaluation\",    \"restructuringWriteDown\" : \"restructuringWriteDown\",    \"restructuringTask\" : \"restructuringTask\"  },  \"requestResponseRecord\" : \"{}\"}", BQRestructuringRequestOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRestructuringRequestOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRestructuringRequestOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQWithdrawalRequestOutputModel> requestConsumerLoanFulfillmentArrangementWithdrawalUpdate(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Withdrawal BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Withdrawal request payload" ,required=true )  @Valid @RequestBody BQWithdrawalRequestInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQWithdrawalRequestOutputModel>(objectMapper.readValue("{  \"withdrawalRequestActionTaskReference\" : \"WRATR721337\",  \"withdrawalRequestActionTaskRecord\" : \"{}\",  \"withdrawalRequestRecordReference\" : \"WRRR774651\",  \"requestResponseRecord\" : \"{}\"}", BQWithdrawalRequestOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQWithdrawalRequestOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQWithdrawalRequestOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<CRConsumerLoanFulfillmentArrangementRetrieveOutputModel> retrieveConsumerLoan(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Consumer Loan Request Payload" ,required=true )  @Valid @RequestBody CRConsumerLoanFulfillmentArrangementRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementRetrieveOutputModel>(objectMapper.readValue("{  \"consumerLoanFulfillmentArrangementInstanceAnalysis\" : {    \"consumerLoanFulfillmentArrangementInstanceAnalysisData\" : \"consumerLoanFulfillmentArrangementInstanceAnalysisData\",    \"consumerLoanFulfillmentArrangementInstanceAnalysisReportType\" : \"consumerLoanFulfillmentArrangementInstanceAnalysisReportType\",    \"consumerLoanFulfillmentArrangementInstanceAnalysisReport\" : \"{}\"  },  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"associations\" : {      \"associationReference\" : \"724357\",      \"associationType\" : \"associationType\",      \"associationObligationEntitlement\" : \"associationObligationEntitlement\"    },    \"taxReference\" : \"721038\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"loanType\" : \"loanType\",    \"insuranceReference\" : \"718877\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"interestType\" : \"interestType\",    \"customerCreditAssessmentReference\" : \"713628\",    \"loanApplicableRate\" : \"loanApplicableRate\",    \"productInstanceReference\" : \"787535\",    \"repaymentType\" : \"repaymentType\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"customerReference\" : \"739115\",    \"loanRateType\" : \"loanRateType\",    \"loanRepaymentSchedule\" : \"loanRepaymentSchedule\",    \"loanCurrency\" : \"USD\",    \"customerAgreementReference\" : \"777496\",    \"collateralAllocation\" : \"collateralAllocation\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"stagedRepaymentStatement\" : \"stagedRepaymentStatement\",    \"interestAccrualMethod\" : \"interestAccrualMethod\",    \"partyReference\" : \"708755\",    \"collateralReference\" : \"779767\",    \"customerCommentary\" : \"customerCommentary\",    \"loanAmount\" : \"USD 250\",    \"bankBranchLocationReference\" : \"754492\",    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"bankAccountingUnitReference\" : \"705364\",    \"loanMaturityDate\" : \"09-22-2018\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"delinquencyCollectionReference\" : \"734161\",    \"loanOriginationDate\" : \"09-22-2018\"  },  \"consumerLoanFulfillmentArrangementRetrieveActionTaskRecord\" : \"{}\",  \"consumerLoanFulfillmentArrangementRetrieveActionTaskReference\" : \"CLFARATR751295\",  \"consumerLoanFulfillmentArrangementRetrieveActionResponse\" : \"consumerLoanFulfillmentArrangementRetrieveActionResponse\",  \"consumerLoanFulfillmentArrangementInstanceReportRecord\" : {    \"consumerLoanFulfillmentArrangementInstanceReportType\" : \"consumerLoanFulfillmentArrangementInstanceReportType\",    \"consumerLoanFulfillmentArrangementInstanceReportData\" : \"consumerLoanFulfillmentArrangementInstanceReportData\",    \"consumerLoanFulfillmentArrangementInstanceReport\" : \"{}\"  }}", CRConsumerLoanFulfillmentArrangementRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<CRConsumerLoanFulfillmentArrangementRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<String>> retrieveConsumerLoanBehaviorQualifierReferenceIds(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Behavior Qualifier Name. ex- Restructuring",required=true) @PathVariable("behavior-qualifier") String behaviorQualifier,@ApiParam(value = "Filter to refine the result set. ex- Restructuring Instance Status = 'pending'") @Valid @RequestParam(value = "collection-filter", required = false) String collectionFilter) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<String>>(objectMapper.readValue("[ \"RestructuringID1\", \"RestructuringID2\" ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<String>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<String>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<String>> retrieveConsumerLoanBehaviorQualifiers() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<String>>(objectMapper.readValue("[ \"Interest\", \"ServiceFees\", \"Disbursement\", \"Maintenance\", \"Withdrawal\", \"Repayment\", \"Restructuring\" ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<String>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<String>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQDisbursementRetrieveOutputModel> retrieveConsumerLoanDisbursement(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Disbursement BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Consumer Loan Disbursement Request Payload" ,required=true )  @Valid @RequestBody BQDisbursementRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQDisbursementRetrieveOutputModel>(objectMapper.readValue("{  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"productInstanceReference\" : \"712949\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"customerReference\" : \"743497\",    \"partyReference\" : \"728944\",    \"loanOriginationDate\" : \"09-22-2018\"  },  \"disbursementInstanceRecord\" : {    \"disbursementValueDate\" : \"09-22-2018\",    \"disbursementPayeeProductInstanceReference\" : \"770515\",    \"disbursementPayeeBankReference\" : \"760328\",    \"disbursementCurrency\" : \"USD\",    \"disbursementPayeeReference\" : \"700160\",    \"disbursementAmount\" : \"USD 250\"  },  \"disbursementRetrieveActionResponse\" : \"disbursementRetrieveActionResponse\",  \"disbursementInstanceAnalysis\" : {    \"disbursementInstanceAnalysisReport\" : \"{}\",    \"disbursementInstanceAnalysisRecord\" : \"{}\",    \"disbursementInstanceAnalysisParameters\" : \"disbursementInstanceAnalysisParameters\",    \"disbursementInstanceAnalysisReportType\" : \"disbursementInstanceAnalysisReportType\"  },  \"disbursementInstanceReport\" : {    \"disbursementInstanceReportType\" : \"disbursementInstanceReportType\",    \"disbursementInstanceReportRecord\" : \"{}\",    \"disbursementInstanceReportParameters\" : \"disbursementInstanceReportParameters\",    \"disbursementInstanceReport\" : \"{}\"  },  \"disbursementRetrieveActionTaskRecord\" : \"{}\",  \"disbursementRetrieveActionTaskReference\" : \"DRATR775814\"}", BQDisbursementRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQDisbursementRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQDisbursementRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQInterestRetrieveOutputModel> retrieveConsumerLoanInterest(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Interest BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Consumer Loan Interest Request Payload" ,required=true )  @Valid @RequestBody BQInterestRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQInterestRetrieveOutputModel>(objectMapper.readValue("{  \"interestRetrieveActionResponse\" : \"interestRetrieveActionResponse\",  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"loanType\" : \"loanType\",    \"interestType\" : \"interestType\",    \"interestAccrualMethod\" : \"interestAccrualMethod\",    \"loanApplicableRate\" : \"loanApplicableRate\",    \"loanAmount\" : \"USD 250\",    \"productInstanceReference\" : \"789278\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"loanRateType\" : \"loanRateType\",    \"loanMaturityDate\" : \"09-22-2018\",    \"loanOriginationDate\" : \"09-22-2018\",    \"loanCurrency\" : \"USD\"  },  \"interestRetrieveActionTaskReference\" : \"IRATR758844\",  \"interestInstanceRecord\" : \"{}\",  \"interestRetrieveActionTaskRecord\" : \"{}\",  \"interestInstanceReport\" : {    \"interestInstanceReportRecord\" : \"{}\",    \"interestInstanceReportParameters\" : \"interestInstanceReportParameters\",    \"interestInstanceReportType\" : \"interestInstanceReportType\",    \"interestInstanceReport\" : \"{}\"  },  \"interestInstanceAnalysis\" : {    \"interestInstanceAnalysisRecord\" : \"{}\",    \"interestInstanceAnalysisParameters\" : \"interestInstanceAnalysisParameters\",    \"interestInstanceAnalysisReportType\" : \"interestInstanceAnalysisReportType\",    \"interestInstanceAnalysisReport\" : \"{}\"  }}", BQInterestRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQInterestRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQInterestRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQMaintenanceRetrieveOutputModel> retrieveConsumerLoanMaintenance(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Maintenance BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Consumer Loan Maintenance Request Payload" ,required=true )  @Valid @RequestBody BQMaintenanceRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQMaintenanceRetrieveOutputModel>(objectMapper.readValue("{  \"maintenanceRetrieveActionTaskRecord\" : \"{}\",  \"maintenanceInstanceRecord\" : {    \"maintenanceReportType\" : {      \"penalties\" : \"penalties\",      \"loanFees\" : \"loanFees\",      \"collateralValuation\" : \"collateralValuation\",      \"loanFeeType\" : \"loanFeeType\",      \"loanTaxReport\" : \"{}\"    }  },  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"associations\" : {      \"associationReference\" : \"719240\",      \"associationType\" : \"associationType\",      \"associationObligationEntitlement\" : \"associationObligationEntitlement\"    },    \"taxReference\" : \"749964\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"loanType\" : \"loanType\",    \"insuranceReference\" : \"772552\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"interestType\" : \"interestType\",    \"customerCreditAssessmentReference\" : \"770746\",    \"loanApplicableRate\" : \"loanApplicableRate\",    \"productInstanceReference\" : \"716449\",    \"repaymentType\" : \"repaymentType\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"customerReference\" : \"743693\",    \"loanRateType\" : \"loanRateType\",    \"loanRepaymentSchedule\" : \"loanRepaymentSchedule\",    \"loanCurrency\" : \"USD\",    \"customerAgreementReference\" : \"701562\",    \"collateralAllocation\" : \"collateralAllocation\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"stagedRepaymentStatement\" : \"stagedRepaymentStatement\",    \"interestAccrualMethod\" : \"interestAccrualMethod\",    \"partyReference\" : \"719244\",    \"collateralReference\" : \"779687\",    \"customerCommentary\" : \"customerCommentary\",    \"loanAmount\" : \"USD 250\",    \"bankBranchLocationReference\" : \"722855\",    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"bankAccountingUnitReference\" : \"776211\",    \"loanMaturityDate\" : \"09-22-2018\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"delinquencyCollectionReference\" : \"746798\",    \"loanOriginationDate\" : \"09-22-2018\"  },  \"maintenanceRetrieveActionTaskReference\" : \"MRATR715116\",  \"maintenanceInstanceReport\" : {    \"maintenanceInstanceReportRecord\" : \"{}\",    \"maintenanceInstanceReportParameters\" : \"maintenanceInstanceReportParameters\",    \"maintenanceInstanceReportType\" : \"maintenanceInstanceReportType\",    \"maintenanceInstanceReport\" : \"{}\"  },  \"maintenanceInstanceAnalysis\" : {    \"maintenanceInstanceAnalysisRecord\" : \"{}\",    \"maintenanceInstanceAnalysisReport\" : \"{}\",    \"maintenanceInstanceAnalysisReportType\" : \"maintenanceInstanceAnalysisReportType\",    \"maintenanceInstanceAnalysisParameters\" : \"maintenanceInstanceAnalysisParameters\"  },  \"maintenanceRetrieveActionResponse\" : \"maintenanceRetrieveActionResponse\"}", BQMaintenanceRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQMaintenanceRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQMaintenanceRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<String>> retrieveConsumerLoanReferenceIds(@ApiParam(value = "Filter to refine the result set. ex- ConsumerLoan Instance Status='active'") @Valid @RequestParam(value = "collection-filter", required = false) String collectionFilter) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<String>>(objectMapper.readValue("[ \"ID726464\", \"ID7264642\" ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<String>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<String>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRepaymentRetrieveOutputModel> retrieveConsumerLoanRepayment(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Repayment BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Consumer Loan Repayment Request Payload" ,required=true )  @Valid @RequestBody BQRepaymentRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRepaymentRetrieveOutputModel>(objectMapper.readValue("{  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"productInstanceReference\" : \"726045\",    \"repaymentType\" : \"repaymentType\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"customerReference\" : \"721269\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"partyReference\" : \"729022\"  },  \"repaymentRetrieveActionTaskReference\" : \"RRATR737534\",  \"repaymentInstanceReport\" : {    \"repaymentInstanceReportParameters\" : \"repaymentInstanceReportParameters\",    \"repaymentInstanceReportType\" : \"repaymentInstanceReportType\",    \"repaymentInstanceReport\" : \"{}\",    \"repaymentInstanceReportRecord\" : \"{}\"  },  \"repaymentRetrieveActionResponse\" : \"repaymentRetrieveActionResponse\",  \"repaymentInstanceRecord\" : {    \"repaymentTransactionPayerProductInstanceReference\" : \"757064\",    \"repaymentTransactionCurrency\" : \"USD\",    \"repaymentTransactionType\" : \"repaymentTransactionType\",    \"repaymentTransactionAmount\" : \"USD 250\",    \"repaymentTransactionPayerReference\" : \"703337\",    \"repaymentTransactionPayerBankReference\" : \"726848\",    \"repaymentTransactionValueDate\" : \"09-22-2018\"  },  \"repaymentRetrieveActionTaskRecord\" : \"{}\",  \"repaymentInstanceAnalysis\" : {    \"repaymentInstanceAnalysisReportType\" : \"repaymentInstanceAnalysisReportType\",    \"repaymentInstanceAnalysisRecord\" : \"{}\",    \"repaymentInstanceAnalysisReport\" : \"{}\",    \"repaymentInstanceAnalysisParameters\" : \"repaymentInstanceAnalysisParameters\"  }}", BQRepaymentRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRepaymentRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRepaymentRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRestructuringRetrieveOutputModel> retrieveConsumerLoanRestructuring(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Restructuring BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Consumer Loan Restructuring Request Payload" ,required=true )  @Valid @RequestBody BQRestructuringRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRestructuringRetrieveOutputModel>(objectMapper.readValue("{  \"restructuringInstanceReport\" : {    \"restructuringInstanceReport\" : \"{}\",    \"restructuringInstanceReportRecord\" : \"{}\",    \"restructuringInstanceReportType\" : \"restructuringInstanceReportType\",    \"restructuringInstanceReportParameters\" : \"restructuringInstanceReportParameters\"  },  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"associations\" : {      \"associationReference\" : \"748844\",      \"associationType\" : \"associationType\",      \"associationObligationEntitlement\" : \"associationObligationEntitlement\"    },    \"taxReference\" : \"738305\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"loanType\" : \"loanType\",    \"insuranceReference\" : \"752950\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"interestType\" : \"interestType\",    \"customerCreditAssessmentReference\" : \"705997\",    \"loanApplicableRate\" : \"loanApplicableRate\",    \"productInstanceReference\" : \"776005\",    \"repaymentType\" : \"repaymentType\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"customerReference\" : \"721629\",    \"loanRateType\" : \"loanRateType\",    \"loanRepaymentSchedule\" : \"loanRepaymentSchedule\",    \"loanCurrency\" : \"USD\",    \"customerAgreementReference\" : \"731034\",    \"collateralAllocation\" : \"collateralAllocation\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"stagedRepaymentStatement\" : \"stagedRepaymentStatement\",    \"interestAccrualMethod\" : \"interestAccrualMethod\",    \"partyReference\" : \"730746\",    \"collateralReference\" : \"754630\",    \"customerCommentary\" : \"customerCommentary\",    \"loanAmount\" : \"USD 250\",    \"bankBranchLocationReference\" : \"728241\",    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"bankAccountingUnitReference\" : \"721448\",    \"loanMaturityDate\" : \"09-22-2018\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"delinquencyCollectionReference\" : \"728223\",    \"loanOriginationDate\" : \"09-22-2018\"  },  \"restructuringInstanceAnalysis\" : {    \"restructuringInstanceAnalysisParameters\" : \"restructuringInstanceAnalysisParameters\",    \"restructuringInstanceAnalysisRecord\" : \"{}\",    \"restructuringInstanceAnalysisReport\" : \"{}\",    \"restructuringInstanceAnalysisReportType\" : \"restructuringInstanceAnalysisReportType\"  },  \"restructuringRetrieveActionTaskRecord\" : \"{}\",  \"restructuringRetrieveActionResponse\" : \"restructuringRetrieveActionResponse\",  \"restructuringInstanceRecord\" : {    \"restructuringEvaluation\" : \"restructuringEvaluation\",    \"restructuringWriteDown\" : \"restructuringWriteDown\",    \"restructuringTask\" : \"restructuringTask\"  },  \"restructuringRetrieveActionTaskReference\" : \"RRATR798316\"}", BQRestructuringRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRestructuringRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRestructuringRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQServiceFeesRetrieveOutputModel> retrieveConsumerLoanServiceFees(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "ServiceFees BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Consumer Loan ServiceFees Request Payload" ,required=true )  @Valid @RequestBody BQServiceFeesRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQServiceFeesRetrieveOutputModel>(objectMapper.readValue("{  \"serviceFeesInstanceReport\" : {    \"serviceFeesInstanceReport\" : \"{}\",    \"serviceFeesInstanceReportType\" : \"serviceFeesInstanceReportType\",    \"serviceFeesInstanceReportParameters\" : \"serviceFeesInstanceReportParameters\",    \"serviceFeesInstanceReportRecord\" : \"{}\"  },  \"serviceFeesInstanceAnalysis\" : {    \"serviceFeesInstanceAnalysisReport\" : \"{}\",    \"serviceFeesInstanceAnalysisParameters\" : \"serviceFeesInstanceAnalysisParameters\",    \"serviceFeesInstanceAnalysisReportType\" : \"serviceFeesInstanceAnalysisReportType\",    \"serviceFeesInstanceAnalysisRecord\" : \"{}\"  },  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"associations\" : {      \"associationReference\" : \"718623\",      \"associationType\" : \"associationType\",      \"associationObligationEntitlement\" : \"associationObligationEntitlement\"    },    \"productInstanceReference\" : \"743618\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"customerReference\" : \"738140\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"customerCommentary\" : \"customerCommentary\"  },  \"serviceFeesRetrieveActionTaskReference\" : \"SFRATR713423\",  \"serviceFeesRetrieveActionResponse\" : \"serviceFeesRetrieveActionResponse\",  \"serviceFeesRetrieveActionTaskRecord\" : \"{}\",  \"serviceFeesInstanceRecord\" : {    \"feeConfigurationProfile\" : {      \"feeDefinition\" : \"feeDefinition\",      \"feeType\" : \"feeType\"    },    \"feeApplicationRecord\" : {      \"feeAccrualAmount\" : {        \"accrualFeeType\" : \"accrualFeeType\",        \"accrualFeeCharge\" : \"USD 250\"      },      \"feeTransaction\" : {        \"transactionFeeCharge\" : \"USD 250\",        \"transactionDescription\" : \"transactionDescription\",        \"transactionFeeType\" : \"transactionFeeType\"      },      \"feeProjectionsandCommitments\" : {        \"projectedTransactionDescription\" : \"projectedTransactionDescription\",        \"projectedTransactionFeeType\" : \"projectedTransactionFeeType\",        \"projectedTransactionFeeCharge\" : \"USD 250\"      }    }  }}", BQServiceFeesRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQServiceFeesRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQServiceFeesRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQWithdrawalRetrieveOutputModel> retrieveConsumerLoanWithdrawal(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Withdrawal BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Consumer Loan Withdrawal Request Payload" ,required=true )  @Valid @RequestBody BQWithdrawalRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQWithdrawalRetrieveOutputModel>(objectMapper.readValue("{  \"withdrawalInstanceAnalysis\" : {    \"withdrawalInstanceAnalysisParameters\" : \"withdrawalInstanceAnalysisParameters\",    \"withdrawalInstanceAnalysisReportType\" : \"withdrawalInstanceAnalysisReportType\",    \"withdrawalInstanceAnalysisReport\" : \"{}\",    \"withdrawalInstanceAnalysisRecord\" : \"{}\"  },  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"productInstanceReference\" : \"777223\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"customerReference\" : \"708476\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"partyReference\" : \"702396\"  },  \"withdrawalRetrieveActionResponse\" : \"withdrawalRetrieveActionResponse\",  \"withdrawalRetrieveActionTaskRecord\" : \"{}\",  \"withdrawalInstanceReport\" : {    \"withdrawalInstanceReportType\" : \"withdrawalInstanceReportType\",    \"withdrawalInstanceReport\" : \"{}\",    \"withdrawalInstanceReportParameters\" : \"withdrawalInstanceReportParameters\",    \"withdrawalInstanceReportRecord\" : \"{}\"  },  \"withdrawalInstanceRecord\" : {    \"paymentTransaction\" : {      \"paymentTransactionPayeeReference\" : \"717761\",      \"paymentTransactionPayeeBankReference\" : \"792184\",      \"paymentTransactionFeeType\" : \"paymentTransactionFeeType\",      \"paymentTransactionFeeCharge\" : \"USD 250\",      \"paymentTransactionPaymentPurpose\" : \"paymentTransactionPaymentPurpose\",      \"paymentTransactionStatus\" : \"paymentTransactionStatus\",      \"paymentTransactionPayeeAccountReference\" : \"729441\",      \"paymentTransactionType\" : \"paymentTransactionType\",      \"paymentTransactionDate\" : \"09-22-2018\",      \"paymentTransactionAmount\" : \"USD 250\",      \"paymentTransactionPaymentMechanism\" : \"paymentTransactionPaymentMechanism\",      \"paymentTransactionBankBranchLocationReference\" : \"775306\"    }  },  \"withdrawalRetrieveActionTaskReference\" : \"WRATR748809\"}", BQWithdrawalRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQWithdrawalRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQWithdrawalRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<SDConsumerLoanRetrieveOutputModel> retrieveSDConsumerLoan(@ApiParam(value = "SDConsumerLoan Retrieve Request Payload" ,required=true )  @Valid @RequestBody SDConsumerLoanRetrieveInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<SDConsumerLoanRetrieveOutputModel>(objectMapper.readValue("{  \"serviceDomainRetrieveActionRecord\" : {    \"serviceDomainPerformanceAnalysis\" : {      \"performanceAnalysisReport\" : \"{}\",      \"performanceAnalysisReportType\" : \"performanceAnalysisReportType\",      \"performanceAnalysisResult\" : \"performanceAnalysisResult\",      \"performanceAnalysisReference\" : \"761670\"    },    \"controlRecordPortfolioAnalysis\" : {      \"controlRecordPortfolioAnalysisResult\" : \"controlRecordPortfolioAnalysisResult\",      \"controlRecordPortfolioAnalysisReportType\" : \"controlRecordPortfolioAnalysisReportType\",      \"controlRecordAnalysisReport\" : \"{}\",      \"controlRecordPortfolioAnalysisReference\" : \"739764\"    },    \"serviceDomainActivityAnalysis\" : {      \"activityAnalysisResult\" : \"activityAnalysisResult\",      \"activityAnalysisReportType\" : \"activityAnalysisReportType\",      \"activityAnalysisReport\" : \"{}\",      \"activityAnalysisReference\" : \"730230\"    }  },  \"serviceDomainRetrieveActionTaskReference\" : \"SRATR795161\",  \"serviceDomainRetrieveActionResponse\" : \"serviceDomainRetrieveActionResponse\",  \"serviceDomainRetrieveActionTaskRecord\" : \"{}\",  \"serviceDomainOfferedService\" : {    \"serviceDomainServiceReference\" : \"776158\",    \"serviceDomainServiceRecord\" : {      \"serviceDomainServiceDescription\" : \"serviceDomainServiceDescription\",      \"serviceDomainServiceType\" : \"serviceDomainServiceType\",      \"serviceDomainServiceVersion\" : \"serviceDomainServiceVersion\",      \"serviceDomainServicePoliciesandGuidelines\" : {        \"serviceDomainServiceEligibility\" : \"serviceDomainServiceEligibility\",        \"serviceDomainServiceIntendedUses\" : \"serviceDomainServiceIntendedUses\",        \"serviceDomainServicePricingandTerms\" : \"serviceDomainServicePricingandTerms\"      },      \"serviceDomainServiceSchedule\" : \"serviceDomainServiceSchedule\"    }  }}", SDConsumerLoanRetrieveOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<SDConsumerLoanRetrieveOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<SDConsumerLoanRetrieveOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<CRConsumerLoanFulfillmentArrangementUpdateOutputModel> updateConsumerLoanFulfillmentArrangement(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "ConsumerLoanFulfillmentArrangement Request Payload" ,required=true )  @Valid @RequestBody CRConsumerLoanFulfillmentArrangementUpdateInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementUpdateOutputModel>(objectMapper.readValue("{  \"consumerLoanFulfillmentArrangementUpdateActionTaskReference\" : \"CLFAUATR760326\",  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"associations\" : {      \"associationReference\" : \"736980\",      \"associationType\" : \"associationType\",      \"associationObligationEntitlement\" : \"associationObligationEntitlement\"    },    \"taxReference\" : \"781175\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"loanType\" : \"loanType\",    \"insuranceReference\" : \"784536\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"interestType\" : \"interestType\",    \"customerCreditAssessmentReference\" : \"775806\",    \"loanApplicableRate\" : \"loanApplicableRate\",    \"productInstanceReference\" : \"700999\",    \"repaymentType\" : \"repaymentType\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"customerReference\" : \"743221\",    \"loanRateType\" : \"loanRateType\",    \"loanRepaymentSchedule\" : \"loanRepaymentSchedule\",    \"loanCurrency\" : \"USD\",    \"customerAgreementReference\" : \"731396\",    \"collateralAllocation\" : \"collateralAllocation\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"stagedRepaymentStatement\" : \"stagedRepaymentStatement\",    \"interestAccrualMethod\" : \"interestAccrualMethod\",    \"partyReference\" : \"757979\",    \"collateralReference\" : \"732692\",    \"customerCommentary\" : \"customerCommentary\",    \"loanAmount\" : \"USD 250\",    \"bankBranchLocationReference\" : \"756293\",    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"bankAccountingUnitReference\" : \"785702\",    \"loanMaturityDate\" : \"09-22-2018\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"delinquencyCollectionReference\" : \"755818\",    \"loanOriginationDate\" : \"09-22-2018\"  },  \"updateResponseRecord\" : \"{}\",  \"consumerLoanFulfillmentArrangementUpdateActionTaskRecord\" : \"{}\"}", CRConsumerLoanFulfillmentArrangementUpdateOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<CRConsumerLoanFulfillmentArrangementUpdateOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<CRConsumerLoanFulfillmentArrangementUpdateOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRepaymentUpdateOutputModel> updateConsumerLoanFulfillmentArrangementRepayment(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Repayment BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Repayment Request Payload" ,required=true )  @Valid @RequestBody BQRepaymentUpdateInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRepaymentUpdateOutputModel>(objectMapper.readValue("{  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"loanOutstandingBalance\" : \"loanOutstandingBalance\"  },  \"updateResponseRecord\" : \"{}\",  \"repaymentInstanceRecord\" : {    \"repaymentTransactionPayerProductInstanceReference\" : \"793278\",    \"repaymentTransactionCurrency\" : \"USD\",    \"repaymentTransactionType\" : \"repaymentTransactionType\",    \"repaymentTransactionAmount\" : \"USD 250\",    \"repaymentTransactionPayerReference\" : \"704482\",    \"repaymentTransactionPayerBankReference\" : \"791646\",    \"repaymentTransactionValueDate\" : \"09-22-2018\"  },  \"repaymentUpdateActionTaskRecord\" : \"{}\",  \"repaymentUpdateActionTaskReference\" : \"RUATR721714\"}", BQRepaymentUpdateOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRepaymentUpdateOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRepaymentUpdateOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQRestructuringUpdateOutputModel> updateConsumerLoanFulfillmentArrangementRestructuring(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Restructuring BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Restructuring Request Payload" ,required=true )  @Valid @RequestBody BQRestructuringUpdateInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQRestructuringUpdateOutputModel>(objectMapper.readValue("{  \"restructuringUpdateActionTaskRecord\" : \"{}\",  \"restructuringUpdateActionTaskReference\" : \"RUATR705563\",  \"consumerLoanFulfillmentArrangementInstanceRecord\" : {    \"associations\" : {      \"associationReference\" : \"798245\",      \"associationType\" : \"associationType\",      \"associationObligationEntitlement\" : \"associationObligationEntitlement\"    },    \"taxReference\" : \"707714\",    \"restrictionOptionSetting\" : \"restrictionOptionSetting\",    \"loanType\" : \"loanType\",    \"insuranceReference\" : \"751200\",    \"loanAccessTerms\" : \"loanAccessTerms\",    \"interestType\" : \"interestType\",    \"customerCreditAssessmentReference\" : \"740035\",    \"loanApplicableRate\" : \"loanApplicableRate\",    \"productInstanceReference\" : \"744972\",    \"repaymentType\" : \"repaymentType\",    \"dateType\" : {      \"date\" : \"09-22-2018\"    },    \"customerReference\" : \"773789\",    \"loanRateType\" : \"loanRateType\",    \"loanRepaymentSchedule\" : \"loanRepaymentSchedule\",    \"loanCurrency\" : \"USD\",    \"customerAgreementReference\" : \"793604\",    \"collateralAllocation\" : \"collateralAllocation\",    \"restrictionOptionDefinition\" : \"restrictionOptionDefinition\",    \"stagedRepaymentStatement\" : \"stagedRepaymentStatement\",    \"interestAccrualMethod\" : \"interestAccrualMethod\",    \"partyReference\" : \"733013\",    \"collateralReference\" : \"719601\",    \"customerCommentary\" : \"customerCommentary\",    \"loanAmount\" : \"USD 250\",    \"bankBranchLocationReference\" : \"739409\",    \"consumerLoanNumber\" : \"consumerLoanNumber\",    \"entitlementOptionSetting\" : \"entitlementOptionSetting\",    \"loanOutstandingBalance\" : \"loanOutstandingBalance\",    \"bankAccountingUnitReference\" : \"789531\",    \"loanMaturityDate\" : \"09-22-2018\",    \"entitlementOptionDefinition\" : \"entitlementOptionDefinition\",    \"delinquencyCollectionReference\" : \"768817\",    \"loanOriginationDate\" : \"09-22-2018\"  },  \"updateResponseRecord\" : \"{}\",  \"restructuringInstanceRecord\" : {    \"restructuringEvaluation\" : \"restructuringEvaluation\",    \"restructuringWriteDown\" : \"restructuringWriteDown\",    \"restructuringTask\" : \"restructuringTask\"  }}", BQRestructuringUpdateOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQRestructuringUpdateOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQRestructuringUpdateOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<BQWithdrawalUpdateOutputModel> updateConsumerLoanFulfillmentArrangementWithdrawal(@ApiParam(value = "Consumer Loan Fulfillment Arrangement Instance",required=true) @PathVariable("cr-reference-id") String crReferenceId,@ApiParam(value = "Withdrawal BQ Reference Id",required=true) @PathVariable("bq-reference-id") String bqReferenceId,@ApiParam(value = "Withdrawal Request Payload" ,required=true )  @Valid @RequestBody BQWithdrawalUpdateInputModel body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<BQWithdrawalUpdateOutputModel>(objectMapper.readValue("{  \"updateResponseRecord\" : \"{}\",  \"withdrawalUpdateActionTaskRecord\" : \"{}\",  \"withdrawalInstanceRecord\" : {    \"paymentTransaction\" : {      \"paymentTransactionPayeeReference\" : \"788407\",      \"paymentTransactionPayeeBankReference\" : \"747160\",      \"paymentTransactionFeeType\" : \"paymentTransactionFeeType\",      \"paymentTransactionFeeCharge\" : \"USD 250\",      \"paymentTransactionPaymentPurpose\" : \"paymentTransactionPaymentPurpose\",      \"paymentTransactionStatus\" : \"paymentTransactionStatus\",      \"paymentTransactionPayeeAccountReference\" : \"798358\",      \"paymentTransactionType\" : \"paymentTransactionType\",      \"paymentTransactionDate\" : \"09-22-2018\",      \"paymentTransactionAmount\" : \"USD 250\",      \"paymentTransactionPaymentMechanism\" : \"paymentTransactionPaymentMechanism\",      \"paymentTransactionBankBranchLocationReference\" : \"707827\"    }  },  \"withdrawalUpdateActionTaskReference\" : \"WUATR719357\"}", BQWithdrawalUpdateOutputModel.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<BQWithdrawalUpdateOutputModel>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<BQWithdrawalUpdateOutputModel>(HttpStatus.NOT_IMPLEMENTED);
    }

}
