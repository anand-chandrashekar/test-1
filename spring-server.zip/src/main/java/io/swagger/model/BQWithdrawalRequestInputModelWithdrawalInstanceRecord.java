package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQWithdrawalRequestInputModelWithdrawalInstanceRecordPaymentTransaction;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalRequestInputModelWithdrawalInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalRequestInputModelWithdrawalInstanceRecord   {
  @JsonProperty("paymentTransaction")
  private BQWithdrawalRequestInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransaction = null;

  public BQWithdrawalRequestInputModelWithdrawalInstanceRecord paymentTransaction(BQWithdrawalRequestInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransaction) {
    this.paymentTransaction = paymentTransaction;
    return this;
  }

  /**
   * Get paymentTransaction
   * @return paymentTransaction
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRequestInputModelWithdrawalInstanceRecordPaymentTransaction getPaymentTransaction() {
    return paymentTransaction;
  }

  public void setPaymentTransaction(BQWithdrawalRequestInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransaction) {
    this.paymentTransaction = paymentTransaction;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalRequestInputModelWithdrawalInstanceRecord bqWithdrawalRequestInputModelWithdrawalInstanceRecord = (BQWithdrawalRequestInputModelWithdrawalInstanceRecord) o;
    return Objects.equals(this.paymentTransaction, bqWithdrawalRequestInputModelWithdrawalInstanceRecord.paymentTransaction);
  }

  @Override
  public int hashCode() {
    return Objects.hash(paymentTransaction);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalRequestInputModelWithdrawalInstanceRecord {\n");
    
    sb.append("    paymentTransaction: ").append(toIndentedString(paymentTransaction)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

