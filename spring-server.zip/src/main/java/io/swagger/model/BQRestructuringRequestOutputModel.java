package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRestructuringInitiateOutputModelRestructuringInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringRequestOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringRequestOutputModel   {
  @JsonProperty("restructuringInstanceRecord")
  private BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord = null;

  @JsonProperty("restructuringRequestActionTaskReference")
  private String restructuringRequestActionTaskReference = null;

  @JsonProperty("restructuringRequestActionTaskRecord")
  private Object restructuringRequestActionTaskRecord = null;

  @JsonProperty("restructuringRequestRecordReference")
  private String restructuringRequestRecordReference = null;

  @JsonProperty("requestResponseRecord")
  private Object requestResponseRecord = null;

  public BQRestructuringRequestOutputModel restructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
    return this;
  }

  /**
   * Get restructuringInstanceRecord
   * @return restructuringInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringInitiateOutputModelRestructuringInstanceRecord getRestructuringInstanceRecord() {
    return restructuringInstanceRecord;
  }

  public void setRestructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
  }

  public BQRestructuringRequestOutputModel restructuringRequestActionTaskReference(String restructuringRequestActionTaskReference) {
    this.restructuringRequestActionTaskReference = restructuringRequestActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Restructuring instance request service call 
   * @return restructuringRequestActionTaskReference
  **/
  @ApiModelProperty(example = "RRATR771841", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Restructuring instance request service call ")


  public String getRestructuringRequestActionTaskReference() {
    return restructuringRequestActionTaskReference;
  }

  public void setRestructuringRequestActionTaskReference(String restructuringRequestActionTaskReference) {
    this.restructuringRequestActionTaskReference = restructuringRequestActionTaskReference;
  }

  public BQRestructuringRequestOutputModel restructuringRequestActionTaskRecord(Object restructuringRequestActionTaskRecord) {
    this.restructuringRequestActionTaskRecord = restructuringRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return restructuringRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getRestructuringRequestActionTaskRecord() {
    return restructuringRequestActionTaskRecord;
  }

  public void setRestructuringRequestActionTaskRecord(Object restructuringRequestActionTaskRecord) {
    this.restructuringRequestActionTaskRecord = restructuringRequestActionTaskRecord;
  }

  public BQRestructuringRequestOutputModel restructuringRequestRecordReference(String restructuringRequestRecordReference) {
    this.restructuringRequestRecordReference = restructuringRequestRecordReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring service request record 
   * @return restructuringRequestRecordReference
  **/
  @ApiModelProperty(example = "RRRR783109", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring service request record ")


  public String getRestructuringRequestRecordReference() {
    return restructuringRequestRecordReference;
  }

  public void setRestructuringRequestRecordReference(String restructuringRequestRecordReference) {
    this.restructuringRequestRecordReference = restructuringRequestRecordReference;
  }

  public BQRestructuringRequestOutputModel requestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response 
   * @return requestResponseRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response ")


  public Object getRequestResponseRecord() {
    return requestResponseRecord;
  }

  public void setRequestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringRequestOutputModel bqRestructuringRequestOutputModel = (BQRestructuringRequestOutputModel) o;
    return Objects.equals(this.restructuringInstanceRecord, bqRestructuringRequestOutputModel.restructuringInstanceRecord) &&
        Objects.equals(this.restructuringRequestActionTaskReference, bqRestructuringRequestOutputModel.restructuringRequestActionTaskReference) &&
        Objects.equals(this.restructuringRequestActionTaskRecord, bqRestructuringRequestOutputModel.restructuringRequestActionTaskRecord) &&
        Objects.equals(this.restructuringRequestRecordReference, bqRestructuringRequestOutputModel.restructuringRequestRecordReference) &&
        Objects.equals(this.requestResponseRecord, bqRestructuringRequestOutputModel.requestResponseRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(restructuringInstanceRecord, restructuringRequestActionTaskReference, restructuringRequestActionTaskRecord, restructuringRequestRecordReference, requestResponseRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringRequestOutputModel {\n");
    
    sb.append("    restructuringInstanceRecord: ").append(toIndentedString(restructuringInstanceRecord)).append("\n");
    sb.append("    restructuringRequestActionTaskReference: ").append(toIndentedString(restructuringRequestActionTaskReference)).append("\n");
    sb.append("    restructuringRequestActionTaskRecord: ").append(toIndentedString(restructuringRequestActionTaskRecord)).append("\n");
    sb.append("    restructuringRequestRecordReference: ").append(toIndentedString(restructuringRequestRecordReference)).append("\n");
    sb.append("    requestResponseRecord: ").append(toIndentedString(requestResponseRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

