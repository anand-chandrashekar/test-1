package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis   {
  @JsonProperty("restructuringInstanceAnalysisRecord")
  private Object restructuringInstanceAnalysisRecord = null;

  @JsonProperty("restructuringInstanceAnalysisReportType")
  private String restructuringInstanceAnalysisReportType = null;

  @JsonProperty("restructuringInstanceAnalysisParameters")
  private String restructuringInstanceAnalysisParameters = null;

  @JsonProperty("restructuringInstanceAnalysisReport")
  private Object restructuringInstanceAnalysisReport = null;

  public BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis restructuringInstanceAnalysisRecord(Object restructuringInstanceAnalysisRecord) {
    this.restructuringInstanceAnalysisRecord = restructuringInstanceAnalysisRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected 
   * @return restructuringInstanceAnalysisRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected ")


  public Object getRestructuringInstanceAnalysisRecord() {
    return restructuringInstanceAnalysisRecord;
  }

  public void setRestructuringInstanceAnalysisRecord(Object restructuringInstanceAnalysisRecord) {
    this.restructuringInstanceAnalysisRecord = restructuringInstanceAnalysisRecord;
  }

  public BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis restructuringInstanceAnalysisReportType(String restructuringInstanceAnalysisReportType) {
    this.restructuringInstanceAnalysisReportType = restructuringInstanceAnalysisReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available 
   * @return restructuringInstanceAnalysisReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available ")


  public String getRestructuringInstanceAnalysisReportType() {
    return restructuringInstanceAnalysisReportType;
  }

  public void setRestructuringInstanceAnalysisReportType(String restructuringInstanceAnalysisReportType) {
    this.restructuringInstanceAnalysisReportType = restructuringInstanceAnalysisReportType;
  }

  public BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis restructuringInstanceAnalysisParameters(String restructuringInstanceAnalysisParameters) {
    this.restructuringInstanceAnalysisParameters = restructuringInstanceAnalysisParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) 
   * @return restructuringInstanceAnalysisParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) ")


  public String getRestructuringInstanceAnalysisParameters() {
    return restructuringInstanceAnalysisParameters;
  }

  public void setRestructuringInstanceAnalysisParameters(String restructuringInstanceAnalysisParameters) {
    this.restructuringInstanceAnalysisParameters = restructuringInstanceAnalysisParameters;
  }

  public BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis restructuringInstanceAnalysisReport(Object restructuringInstanceAnalysisReport) {
    this.restructuringInstanceAnalysisReport = restructuringInstanceAnalysisReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate 
   * @return restructuringInstanceAnalysisReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate ")


  public Object getRestructuringInstanceAnalysisReport() {
    return restructuringInstanceAnalysisReport;
  }

  public void setRestructuringInstanceAnalysisReport(Object restructuringInstanceAnalysisReport) {
    this.restructuringInstanceAnalysisReport = restructuringInstanceAnalysisReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis bqRestructuringRetrieveOutputModelRestructuringInstanceAnalysis = (BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis) o;
    return Objects.equals(this.restructuringInstanceAnalysisRecord, bqRestructuringRetrieveOutputModelRestructuringInstanceAnalysis.restructuringInstanceAnalysisRecord) &&
        Objects.equals(this.restructuringInstanceAnalysisReportType, bqRestructuringRetrieveOutputModelRestructuringInstanceAnalysis.restructuringInstanceAnalysisReportType) &&
        Objects.equals(this.restructuringInstanceAnalysisParameters, bqRestructuringRetrieveOutputModelRestructuringInstanceAnalysis.restructuringInstanceAnalysisParameters) &&
        Objects.equals(this.restructuringInstanceAnalysisReport, bqRestructuringRetrieveOutputModelRestructuringInstanceAnalysis.restructuringInstanceAnalysisReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(restructuringInstanceAnalysisRecord, restructuringInstanceAnalysisReportType, restructuringInstanceAnalysisParameters, restructuringInstanceAnalysisReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis {\n");
    
    sb.append("    restructuringInstanceAnalysisRecord: ").append(toIndentedString(restructuringInstanceAnalysisRecord)).append("\n");
    sb.append("    restructuringInstanceAnalysisReportType: ").append(toIndentedString(restructuringInstanceAnalysisReportType)).append("\n");
    sb.append("    restructuringInstanceAnalysisParameters: ").append(toIndentedString(restructuringInstanceAnalysisParameters)).append("\n");
    sb.append("    restructuringInstanceAnalysisReport: ").append(toIndentedString(restructuringInstanceAnalysisReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

