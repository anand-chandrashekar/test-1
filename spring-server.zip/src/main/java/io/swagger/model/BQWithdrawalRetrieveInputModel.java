package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQWithdrawalRetrieveInputModelWithdrawalInstanceAnalysis;
import io.swagger.model.BQWithdrawalRetrieveInputModelWithdrawalInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalRetrieveInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalRetrieveInputModel   {
  @JsonProperty("withdrawalRetrieveActionTaskRecord")
  private Object withdrawalRetrieveActionTaskRecord = null;

  @JsonProperty("withdrawalRetrieveActionRequest")
  private String withdrawalRetrieveActionRequest = null;

  @JsonProperty("withdrawalInstanceReport")
  private BQWithdrawalRetrieveInputModelWithdrawalInstanceReport withdrawalInstanceReport = null;

  @JsonProperty("withdrawalInstanceAnalysis")
  private BQWithdrawalRetrieveInputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysis = null;

  public BQWithdrawalRetrieveInputModel withdrawalRetrieveActionTaskRecord(Object withdrawalRetrieveActionTaskRecord) {
    this.withdrawalRetrieveActionTaskRecord = withdrawalRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return withdrawalRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getWithdrawalRetrieveActionTaskRecord() {
    return withdrawalRetrieveActionTaskRecord;
  }

  public void setWithdrawalRetrieveActionTaskRecord(Object withdrawalRetrieveActionTaskRecord) {
    this.withdrawalRetrieveActionTaskRecord = withdrawalRetrieveActionTaskRecord;
  }

  public BQWithdrawalRetrieveInputModel withdrawalRetrieveActionRequest(String withdrawalRetrieveActionRequest) {
    this.withdrawalRetrieveActionRequest = withdrawalRetrieveActionRequest;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) 
   * @return withdrawalRetrieveActionRequest
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) ")


  public String getWithdrawalRetrieveActionRequest() {
    return withdrawalRetrieveActionRequest;
  }

  public void setWithdrawalRetrieveActionRequest(String withdrawalRetrieveActionRequest) {
    this.withdrawalRetrieveActionRequest = withdrawalRetrieveActionRequest;
  }

  public BQWithdrawalRetrieveInputModel withdrawalInstanceReport(BQWithdrawalRetrieveInputModelWithdrawalInstanceReport withdrawalInstanceReport) {
    this.withdrawalInstanceReport = withdrawalInstanceReport;
    return this;
  }

  /**
   * Get withdrawalInstanceReport
   * @return withdrawalInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRetrieveInputModelWithdrawalInstanceReport getWithdrawalInstanceReport() {
    return withdrawalInstanceReport;
  }

  public void setWithdrawalInstanceReport(BQWithdrawalRetrieveInputModelWithdrawalInstanceReport withdrawalInstanceReport) {
    this.withdrawalInstanceReport = withdrawalInstanceReport;
  }

  public BQWithdrawalRetrieveInputModel withdrawalInstanceAnalysis(BQWithdrawalRetrieveInputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysis) {
    this.withdrawalInstanceAnalysis = withdrawalInstanceAnalysis;
    return this;
  }

  /**
   * Get withdrawalInstanceAnalysis
   * @return withdrawalInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRetrieveInputModelWithdrawalInstanceAnalysis getWithdrawalInstanceAnalysis() {
    return withdrawalInstanceAnalysis;
  }

  public void setWithdrawalInstanceAnalysis(BQWithdrawalRetrieveInputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysis) {
    this.withdrawalInstanceAnalysis = withdrawalInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalRetrieveInputModel bqWithdrawalRetrieveInputModel = (BQWithdrawalRetrieveInputModel) o;
    return Objects.equals(this.withdrawalRetrieveActionTaskRecord, bqWithdrawalRetrieveInputModel.withdrawalRetrieveActionTaskRecord) &&
        Objects.equals(this.withdrawalRetrieveActionRequest, bqWithdrawalRetrieveInputModel.withdrawalRetrieveActionRequest) &&
        Objects.equals(this.withdrawalInstanceReport, bqWithdrawalRetrieveInputModel.withdrawalInstanceReport) &&
        Objects.equals(this.withdrawalInstanceAnalysis, bqWithdrawalRetrieveInputModel.withdrawalInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(withdrawalRetrieveActionTaskRecord, withdrawalRetrieveActionRequest, withdrawalInstanceReport, withdrawalInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalRetrieveInputModel {\n");
    
    sb.append("    withdrawalRetrieveActionTaskRecord: ").append(toIndentedString(withdrawalRetrieveActionTaskRecord)).append("\n");
    sb.append("    withdrawalRetrieveActionRequest: ").append(toIndentedString(withdrawalRetrieveActionRequest)).append("\n");
    sb.append("    withdrawalInstanceReport: ").append(toIndentedString(withdrawalInstanceReport)).append("\n");
    sb.append("    withdrawalInstanceAnalysis: ").append(toIndentedString(withdrawalInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

