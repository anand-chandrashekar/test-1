package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRequestInputModelRepaymentInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRequestInputModelRepaymentInstanceRecord   {
  @JsonProperty("repaymentTransactionType")
  private String repaymentTransactionType = null;

  @JsonProperty("repaymentTransactionPayerReference")
  private String repaymentTransactionPayerReference = null;

  @JsonProperty("repaymentTransactionPayerProductInstanceReference")
  private String repaymentTransactionPayerProductInstanceReference = null;

  @JsonProperty("repaymentTransactionPayerBankReference")
  private String repaymentTransactionPayerBankReference = null;

  @JsonProperty("repaymentTransactionCurrency")
  private String repaymentTransactionCurrency = null;

  @JsonProperty("repaymentTransactionValueDate")
  private String repaymentTransactionValueDate = null;

  public BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentTransactionType(String repaymentTransactionType) {
    this.repaymentTransactionType = repaymentTransactionType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment (e.g. scheduled repayment, balloon/early termination) 
   * @return repaymentTransactionType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment (e.g. scheduled repayment, balloon/early termination) ")


  public String getRepaymentTransactionType() {
    return repaymentTransactionType;
  }

  public void setRepaymentTransactionType(String repaymentTransactionType) {
    this.repaymentTransactionType = repaymentTransactionType;
  }

  public BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentTransactionPayerReference(String repaymentTransactionPayerReference) {
    this.repaymentTransactionPayerReference = repaymentTransactionPayerReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer 
   * @return repaymentTransactionPayerReference
  **/
  @ApiModelProperty(example = "775883", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer ")


  public String getRepaymentTransactionPayerReference() {
    return repaymentTransactionPayerReference;
  }

  public void setRepaymentTransactionPayerReference(String repaymentTransactionPayerReference) {
    this.repaymentTransactionPayerReference = repaymentTransactionPayerReference;
  }

  public BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentTransactionPayerProductInstanceReference(String repaymentTransactionPayerProductInstanceReference) {
    this.repaymentTransactionPayerProductInstanceReference = repaymentTransactionPayerProductInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account where the payment is made from 
   * @return repaymentTransactionPayerProductInstanceReference
  **/
  @ApiModelProperty(example = "785253", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account where the payment is made from ")


  public String getRepaymentTransactionPayerProductInstanceReference() {
    return repaymentTransactionPayerProductInstanceReference;
  }

  public void setRepaymentTransactionPayerProductInstanceReference(String repaymentTransactionPayerProductInstanceReference) {
    this.repaymentTransactionPayerProductInstanceReference = repaymentTransactionPayerProductInstanceReference;
  }

  public BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentTransactionPayerBankReference(String repaymentTransactionPayerBankReference) {
    this.repaymentTransactionPayerBankReference = repaymentTransactionPayerBankReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer's bank 
   * @return repaymentTransactionPayerBankReference
  **/
  @ApiModelProperty(example = "796363", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer's bank ")


  public String getRepaymentTransactionPayerBankReference() {
    return repaymentTransactionPayerBankReference;
  }

  public void setRepaymentTransactionPayerBankReference(String repaymentTransactionPayerBankReference) {
    this.repaymentTransactionPayerBankReference = repaymentTransactionPayerBankReference;
  }

  public BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentTransactionCurrency(String repaymentTransactionCurrency) {
    this.repaymentTransactionCurrency = repaymentTransactionCurrency;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Currency  general-info: The currency used for the repayment 
   * @return repaymentTransactionCurrency
  **/
  @ApiModelProperty(example = "USD", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Currency  general-info: The currency used for the repayment ")


  public String getRepaymentTransactionCurrency() {
    return repaymentTransactionCurrency;
  }

  public void setRepaymentTransactionCurrency(String repaymentTransactionCurrency) {
    this.repaymentTransactionCurrency = repaymentTransactionCurrency;
  }

  public BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentTransactionValueDate(String repaymentTransactionValueDate) {
    this.repaymentTransactionValueDate = repaymentTransactionValueDate;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The value date for the repayment transaction 
   * @return repaymentTransactionValueDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The value date for the repayment transaction ")


  public String getRepaymentTransactionValueDate() {
    return repaymentTransactionValueDate;
  }

  public void setRepaymentTransactionValueDate(String repaymentTransactionValueDate) {
    this.repaymentTransactionValueDate = repaymentTransactionValueDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRequestInputModelRepaymentInstanceRecord bqRepaymentRequestInputModelRepaymentInstanceRecord = (BQRepaymentRequestInputModelRepaymentInstanceRecord) o;
    return Objects.equals(this.repaymentTransactionType, bqRepaymentRequestInputModelRepaymentInstanceRecord.repaymentTransactionType) &&
        Objects.equals(this.repaymentTransactionPayerReference, bqRepaymentRequestInputModelRepaymentInstanceRecord.repaymentTransactionPayerReference) &&
        Objects.equals(this.repaymentTransactionPayerProductInstanceReference, bqRepaymentRequestInputModelRepaymentInstanceRecord.repaymentTransactionPayerProductInstanceReference) &&
        Objects.equals(this.repaymentTransactionPayerBankReference, bqRepaymentRequestInputModelRepaymentInstanceRecord.repaymentTransactionPayerBankReference) &&
        Objects.equals(this.repaymentTransactionCurrency, bqRepaymentRequestInputModelRepaymentInstanceRecord.repaymentTransactionCurrency) &&
        Objects.equals(this.repaymentTransactionValueDate, bqRepaymentRequestInputModelRepaymentInstanceRecord.repaymentTransactionValueDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repaymentTransactionType, repaymentTransactionPayerReference, repaymentTransactionPayerProductInstanceReference, repaymentTransactionPayerBankReference, repaymentTransactionCurrency, repaymentTransactionValueDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRequestInputModelRepaymentInstanceRecord {\n");
    
    sb.append("    repaymentTransactionType: ").append(toIndentedString(repaymentTransactionType)).append("\n");
    sb.append("    repaymentTransactionPayerReference: ").append(toIndentedString(repaymentTransactionPayerReference)).append("\n");
    sb.append("    repaymentTransactionPayerProductInstanceReference: ").append(toIndentedString(repaymentTransactionPayerProductInstanceReference)).append("\n");
    sb.append("    repaymentTransactionPayerBankReference: ").append(toIndentedString(repaymentTransactionPayerBankReference)).append("\n");
    sb.append("    repaymentTransactionCurrency: ").append(toIndentedString(repaymentTransactionCurrency)).append("\n");
    sb.append("    repaymentTransactionValueDate: ").append(toIndentedString(repaymentTransactionValueDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

