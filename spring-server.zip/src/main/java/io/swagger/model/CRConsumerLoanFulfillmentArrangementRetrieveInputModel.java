package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementRetrieveInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementRetrieveInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementRetrieveActionTaskRecord")
  private Object consumerLoanFulfillmentArrangementRetrieveActionTaskRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementRetrieveActionRequest")
  private String consumerLoanFulfillmentArrangementRetrieveActionRequest = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReportRecord")
  private CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceAnalysis")
  private CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysis = null;

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModel consumerLoanFulfillmentArrangementRetrieveActionTaskRecord(Object consumerLoanFulfillmentArrangementRetrieveActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord = consumerLoanFulfillmentArrangementRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return consumerLoanFulfillmentArrangementRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getConsumerLoanFulfillmentArrangementRetrieveActionTaskRecord() {
    return consumerLoanFulfillmentArrangementRetrieveActionTaskRecord;
  }

  public void setConsumerLoanFulfillmentArrangementRetrieveActionTaskRecord(Object consumerLoanFulfillmentArrangementRetrieveActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord = consumerLoanFulfillmentArrangementRetrieveActionTaskRecord;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModel consumerLoanFulfillmentArrangementRetrieveActionRequest(String consumerLoanFulfillmentArrangementRetrieveActionRequest) {
    this.consumerLoanFulfillmentArrangementRetrieveActionRequest = consumerLoanFulfillmentArrangementRetrieveActionRequest;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) 
   * @return consumerLoanFulfillmentArrangementRetrieveActionRequest
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) ")


  public String getConsumerLoanFulfillmentArrangementRetrieveActionRequest() {
    return consumerLoanFulfillmentArrangementRetrieveActionRequest;
  }

  public void setConsumerLoanFulfillmentArrangementRetrieveActionRequest(String consumerLoanFulfillmentArrangementRetrieveActionRequest) {
    this.consumerLoanFulfillmentArrangementRetrieveActionRequest = consumerLoanFulfillmentArrangementRetrieveActionRequest;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModel consumerLoanFulfillmentArrangementInstanceReportRecord(CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportRecord) {
    this.consumerLoanFulfillmentArrangementInstanceReportRecord = consumerLoanFulfillmentArrangementInstanceReportRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceReportRecord
   * @return consumerLoanFulfillmentArrangementInstanceReportRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord getConsumerLoanFulfillmentArrangementInstanceReportRecord() {
    return consumerLoanFulfillmentArrangementInstanceReportRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReportRecord(CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportRecord) {
    this.consumerLoanFulfillmentArrangementInstanceReportRecord = consumerLoanFulfillmentArrangementInstanceReportRecord;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModel consumerLoanFulfillmentArrangementInstanceAnalysis(CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysis) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysis = consumerLoanFulfillmentArrangementInstanceAnalysis;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceAnalysis
   * @return consumerLoanFulfillmentArrangementInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis getConsumerLoanFulfillmentArrangementInstanceAnalysis() {
    return consumerLoanFulfillmentArrangementInstanceAnalysis;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceAnalysis(CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysis) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysis = consumerLoanFulfillmentArrangementInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementRetrieveInputModel crConsumerLoanFulfillmentArrangementRetrieveInputModel = (CRConsumerLoanFulfillmentArrangementRetrieveInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord, crConsumerLoanFulfillmentArrangementRetrieveInputModel.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementRetrieveActionRequest, crConsumerLoanFulfillmentArrangementRetrieveInputModel.consumerLoanFulfillmentArrangementRetrieveActionRequest) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReportRecord, crConsumerLoanFulfillmentArrangementRetrieveInputModel.consumerLoanFulfillmentArrangementInstanceReportRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceAnalysis, crConsumerLoanFulfillmentArrangementRetrieveInputModel.consumerLoanFulfillmentArrangementInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementRetrieveActionTaskRecord, consumerLoanFulfillmentArrangementRetrieveActionRequest, consumerLoanFulfillmentArrangementInstanceReportRecord, consumerLoanFulfillmentArrangementInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementRetrieveInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementRetrieveActionTaskRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementRetrieveActionTaskRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementRetrieveActionRequest: ").append(toIndentedString(consumerLoanFulfillmentArrangementRetrieveActionRequest)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReportRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReportRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceAnalysis: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

