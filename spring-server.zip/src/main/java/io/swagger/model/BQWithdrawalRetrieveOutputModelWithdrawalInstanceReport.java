package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport   {
  @JsonProperty("withdrawalInstanceReportRecord")
  private Object withdrawalInstanceReportRecord = null;

  @JsonProperty("withdrawalInstanceReportType")
  private String withdrawalInstanceReportType = null;

  @JsonProperty("withdrawalInstanceReportParameters")
  private String withdrawalInstanceReportParameters = null;

  @JsonProperty("withdrawalInstanceReport")
  private Object withdrawalInstanceReport = null;

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport withdrawalInstanceReportRecord(Object withdrawalInstanceReportRecord) {
    this.withdrawalInstanceReportRecord = withdrawalInstanceReportRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected 
   * @return withdrawalInstanceReportRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected ")


  public Object getWithdrawalInstanceReportRecord() {
    return withdrawalInstanceReportRecord;
  }

  public void setWithdrawalInstanceReportRecord(Object withdrawalInstanceReportRecord) {
    this.withdrawalInstanceReportRecord = withdrawalInstanceReportRecord;
  }

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport withdrawalInstanceReportType(String withdrawalInstanceReportType) {
    this.withdrawalInstanceReportType = withdrawalInstanceReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available 
   * @return withdrawalInstanceReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available ")


  public String getWithdrawalInstanceReportType() {
    return withdrawalInstanceReportType;
  }

  public void setWithdrawalInstanceReportType(String withdrawalInstanceReportType) {
    this.withdrawalInstanceReportType = withdrawalInstanceReportType;
  }

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport withdrawalInstanceReportParameters(String withdrawalInstanceReportParameters) {
    this.withdrawalInstanceReportParameters = withdrawalInstanceReportParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) 
   * @return withdrawalInstanceReportParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) ")


  public String getWithdrawalInstanceReportParameters() {
    return withdrawalInstanceReportParameters;
  }

  public void setWithdrawalInstanceReportParameters(String withdrawalInstanceReportParameters) {
    this.withdrawalInstanceReportParameters = withdrawalInstanceReportParameters;
  }

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport withdrawalInstanceReport(Object withdrawalInstanceReport) {
    this.withdrawalInstanceReport = withdrawalInstanceReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate 
   * @return withdrawalInstanceReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate ")


  public Object getWithdrawalInstanceReport() {
    return withdrawalInstanceReport;
  }

  public void setWithdrawalInstanceReport(Object withdrawalInstanceReport) {
    this.withdrawalInstanceReport = withdrawalInstanceReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport bqWithdrawalRetrieveOutputModelWithdrawalInstanceReport = (BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport) o;
    return Objects.equals(this.withdrawalInstanceReportRecord, bqWithdrawalRetrieveOutputModelWithdrawalInstanceReport.withdrawalInstanceReportRecord) &&
        Objects.equals(this.withdrawalInstanceReportType, bqWithdrawalRetrieveOutputModelWithdrawalInstanceReport.withdrawalInstanceReportType) &&
        Objects.equals(this.withdrawalInstanceReportParameters, bqWithdrawalRetrieveOutputModelWithdrawalInstanceReport.withdrawalInstanceReportParameters) &&
        Objects.equals(this.withdrawalInstanceReport, bqWithdrawalRetrieveOutputModelWithdrawalInstanceReport.withdrawalInstanceReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(withdrawalInstanceReportRecord, withdrawalInstanceReportType, withdrawalInstanceReportParameters, withdrawalInstanceReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport {\n");
    
    sb.append("    withdrawalInstanceReportRecord: ").append(toIndentedString(withdrawalInstanceReportRecord)).append("\n");
    sb.append("    withdrawalInstanceReportType: ").append(toIndentedString(withdrawalInstanceReportType)).append("\n");
    sb.append("    withdrawalInstanceReportParameters: ").append(toIndentedString(withdrawalInstanceReportParameters)).append("\n");
    sb.append("    withdrawalInstanceReport: ").append(toIndentedString(withdrawalInstanceReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

