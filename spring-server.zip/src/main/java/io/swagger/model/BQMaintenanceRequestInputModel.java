package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRequestInputModelMaintenanceInstanceRecord;
import io.swagger.model.BQMaintenanceRequestInputModelRequestRecordType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRequestInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRequestInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("maintenanceInstanceReference")
  private String maintenanceInstanceReference = null;

  @JsonProperty("maintenanceInstanceRecord")
  private BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord = null;

  @JsonProperty("maintenanceRequestActionTaskRecord")
  private Object maintenanceRequestActionTaskRecord = null;

  @JsonProperty("requestRecordType")
  private BQMaintenanceRequestInputModelRequestRecordType requestRecordType = null;

  public BQMaintenanceRequestInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR719635", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQMaintenanceRequestInputModel maintenanceInstanceReference(String maintenanceInstanceReference) {
    this.maintenanceInstanceReference = maintenanceInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Maintenance instance 
   * @return maintenanceInstanceReference
  **/
  @ApiModelProperty(example = "MIR721864", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Maintenance instance ")


  public String getMaintenanceInstanceReference() {
    return maintenanceInstanceReference;
  }

  public void setMaintenanceInstanceReference(String maintenanceInstanceReference) {
    this.maintenanceInstanceReference = maintenanceInstanceReference;
  }

  public BQMaintenanceRequestInputModel maintenanceInstanceRecord(BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord) {
    this.maintenanceInstanceRecord = maintenanceInstanceRecord;
    return this;
  }

  /**
   * Get maintenanceInstanceRecord
   * @return maintenanceInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecord getMaintenanceInstanceRecord() {
    return maintenanceInstanceRecord;
  }

  public void setMaintenanceInstanceRecord(BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord) {
    this.maintenanceInstanceRecord = maintenanceInstanceRecord;
  }

  public BQMaintenanceRequestInputModel maintenanceRequestActionTaskRecord(Object maintenanceRequestActionTaskRecord) {
    this.maintenanceRequestActionTaskRecord = maintenanceRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return maintenanceRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getMaintenanceRequestActionTaskRecord() {
    return maintenanceRequestActionTaskRecord;
  }

  public void setMaintenanceRequestActionTaskRecord(Object maintenanceRequestActionTaskRecord) {
    this.maintenanceRequestActionTaskRecord = maintenanceRequestActionTaskRecord;
  }

  public BQMaintenanceRequestInputModel requestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
    return this;
  }

  /**
   * Get requestRecordType
   * @return requestRecordType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelRequestRecordType getRequestRecordType() {
    return requestRecordType;
  }

  public void setRequestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRequestInputModel bqMaintenanceRequestInputModel = (BQMaintenanceRequestInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqMaintenanceRequestInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.maintenanceInstanceReference, bqMaintenanceRequestInputModel.maintenanceInstanceReference) &&
        Objects.equals(this.maintenanceInstanceRecord, bqMaintenanceRequestInputModel.maintenanceInstanceRecord) &&
        Objects.equals(this.maintenanceRequestActionTaskRecord, bqMaintenanceRequestInputModel.maintenanceRequestActionTaskRecord) &&
        Objects.equals(this.requestRecordType, bqMaintenanceRequestInputModel.requestRecordType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, maintenanceInstanceReference, maintenanceInstanceRecord, maintenanceRequestActionTaskRecord, requestRecordType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRequestInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    maintenanceInstanceReference: ").append(toIndentedString(maintenanceInstanceReference)).append("\n");
    sb.append("    maintenanceInstanceRecord: ").append(toIndentedString(maintenanceInstanceRecord)).append("\n");
    sb.append("    maintenanceRequestActionTaskRecord: ").append(toIndentedString(maintenanceRequestActionTaskRecord)).append("\n");
    sb.append("    requestRecordType: ").append(toIndentedString(requestRecordType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

