package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRestructuringInitiateOutputModelRestructuringInstanceRecord;
import io.swagger.model.BQRestructuringUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringUpdateOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringUpdateOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQRestructuringUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("restructuringInstanceRecord")
  private BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord = null;

  @JsonProperty("restructuringUpdateActionTaskReference")
  private String restructuringUpdateActionTaskReference = null;

  @JsonProperty("restructuringUpdateActionTaskRecord")
  private Object restructuringUpdateActionTaskRecord = null;

  @JsonProperty("updateResponseRecord")
  private Object updateResponseRecord = null;

  public BQRestructuringUpdateOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQRestructuringUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQRestructuringUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQRestructuringUpdateOutputModel restructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
    return this;
  }

  /**
   * Get restructuringInstanceRecord
   * @return restructuringInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringInitiateOutputModelRestructuringInstanceRecord getRestructuringInstanceRecord() {
    return restructuringInstanceRecord;
  }

  public void setRestructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
  }

  public BQRestructuringUpdateOutputModel restructuringUpdateActionTaskReference(String restructuringUpdateActionTaskReference) {
    this.restructuringUpdateActionTaskReference = restructuringUpdateActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an update service call 
   * @return restructuringUpdateActionTaskReference
  **/
  @ApiModelProperty(example = "RUATR705563", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an update service call ")


  public String getRestructuringUpdateActionTaskReference() {
    return restructuringUpdateActionTaskReference;
  }

  public void setRestructuringUpdateActionTaskReference(String restructuringUpdateActionTaskReference) {
    this.restructuringUpdateActionTaskReference = restructuringUpdateActionTaskReference;
  }

  public BQRestructuringUpdateOutputModel restructuringUpdateActionTaskRecord(Object restructuringUpdateActionTaskRecord) {
    this.restructuringUpdateActionTaskRecord = restructuringUpdateActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record 
   * @return restructuringUpdateActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record ")


  public Object getRestructuringUpdateActionTaskRecord() {
    return restructuringUpdateActionTaskRecord;
  }

  public void setRestructuringUpdateActionTaskRecord(Object restructuringUpdateActionTaskRecord) {
    this.restructuringUpdateActionTaskRecord = restructuringUpdateActionTaskRecord;
  }

  public BQRestructuringUpdateOutputModel updateResponseRecord(Object updateResponseRecord) {
    this.updateResponseRecord = updateResponseRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the Update action service response 
   * @return updateResponseRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the Update action service response ")


  public Object getUpdateResponseRecord() {
    return updateResponseRecord;
  }

  public void setUpdateResponseRecord(Object updateResponseRecord) {
    this.updateResponseRecord = updateResponseRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringUpdateOutputModel bqRestructuringUpdateOutputModel = (BQRestructuringUpdateOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqRestructuringUpdateOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.restructuringInstanceRecord, bqRestructuringUpdateOutputModel.restructuringInstanceRecord) &&
        Objects.equals(this.restructuringUpdateActionTaskReference, bqRestructuringUpdateOutputModel.restructuringUpdateActionTaskReference) &&
        Objects.equals(this.restructuringUpdateActionTaskRecord, bqRestructuringUpdateOutputModel.restructuringUpdateActionTaskRecord) &&
        Objects.equals(this.updateResponseRecord, bqRestructuringUpdateOutputModel.updateResponseRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, restructuringInstanceRecord, restructuringUpdateActionTaskReference, restructuringUpdateActionTaskRecord, updateResponseRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringUpdateOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    restructuringInstanceRecord: ").append(toIndentedString(restructuringInstanceRecord)).append("\n");
    sb.append("    restructuringUpdateActionTaskReference: ").append(toIndentedString(restructuringUpdateActionTaskReference)).append("\n");
    sb.append("    restructuringUpdateActionTaskRecord: ").append(toIndentedString(restructuringUpdateActionTaskRecord)).append("\n");
    sb.append("    updateResponseRecord: ").append(toIndentedString(updateResponseRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

