package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringRetrieveOutputModelRestructuringInstanceReport
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringRetrieveOutputModelRestructuringInstanceReport   {
  @JsonProperty("restructuringInstanceReportRecord")
  private Object restructuringInstanceReportRecord = null;

  @JsonProperty("restructuringInstanceReportType")
  private String restructuringInstanceReportType = null;

  @JsonProperty("restructuringInstanceReportParameters")
  private String restructuringInstanceReportParameters = null;

  @JsonProperty("restructuringInstanceReport")
  private Object restructuringInstanceReport = null;

  public BQRestructuringRetrieveOutputModelRestructuringInstanceReport restructuringInstanceReportRecord(Object restructuringInstanceReportRecord) {
    this.restructuringInstanceReportRecord = restructuringInstanceReportRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected 
   * @return restructuringInstanceReportRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected ")


  public Object getRestructuringInstanceReportRecord() {
    return restructuringInstanceReportRecord;
  }

  public void setRestructuringInstanceReportRecord(Object restructuringInstanceReportRecord) {
    this.restructuringInstanceReportRecord = restructuringInstanceReportRecord;
  }

  public BQRestructuringRetrieveOutputModelRestructuringInstanceReport restructuringInstanceReportType(String restructuringInstanceReportType) {
    this.restructuringInstanceReportType = restructuringInstanceReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available 
   * @return restructuringInstanceReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available ")


  public String getRestructuringInstanceReportType() {
    return restructuringInstanceReportType;
  }

  public void setRestructuringInstanceReportType(String restructuringInstanceReportType) {
    this.restructuringInstanceReportType = restructuringInstanceReportType;
  }

  public BQRestructuringRetrieveOutputModelRestructuringInstanceReport restructuringInstanceReportParameters(String restructuringInstanceReportParameters) {
    this.restructuringInstanceReportParameters = restructuringInstanceReportParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) 
   * @return restructuringInstanceReportParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) ")


  public String getRestructuringInstanceReportParameters() {
    return restructuringInstanceReportParameters;
  }

  public void setRestructuringInstanceReportParameters(String restructuringInstanceReportParameters) {
    this.restructuringInstanceReportParameters = restructuringInstanceReportParameters;
  }

  public BQRestructuringRetrieveOutputModelRestructuringInstanceReport restructuringInstanceReport(Object restructuringInstanceReport) {
    this.restructuringInstanceReport = restructuringInstanceReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate 
   * @return restructuringInstanceReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate ")


  public Object getRestructuringInstanceReport() {
    return restructuringInstanceReport;
  }

  public void setRestructuringInstanceReport(Object restructuringInstanceReport) {
    this.restructuringInstanceReport = restructuringInstanceReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringRetrieveOutputModelRestructuringInstanceReport bqRestructuringRetrieveOutputModelRestructuringInstanceReport = (BQRestructuringRetrieveOutputModelRestructuringInstanceReport) o;
    return Objects.equals(this.restructuringInstanceReportRecord, bqRestructuringRetrieveOutputModelRestructuringInstanceReport.restructuringInstanceReportRecord) &&
        Objects.equals(this.restructuringInstanceReportType, bqRestructuringRetrieveOutputModelRestructuringInstanceReport.restructuringInstanceReportType) &&
        Objects.equals(this.restructuringInstanceReportParameters, bqRestructuringRetrieveOutputModelRestructuringInstanceReport.restructuringInstanceReportParameters) &&
        Objects.equals(this.restructuringInstanceReport, bqRestructuringRetrieveOutputModelRestructuringInstanceReport.restructuringInstanceReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(restructuringInstanceReportRecord, restructuringInstanceReportType, restructuringInstanceReportParameters, restructuringInstanceReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringRetrieveOutputModelRestructuringInstanceReport {\n");
    
    sb.append("    restructuringInstanceReportRecord: ").append(toIndentedString(restructuringInstanceReportRecord)).append("\n");
    sb.append("    restructuringInstanceReportType: ").append(toIndentedString(restructuringInstanceReportType)).append("\n");
    sb.append("    restructuringInstanceReportParameters: ").append(toIndentedString(restructuringInstanceReportParameters)).append("\n");
    sb.append("    restructuringInstanceReport: ").append(toIndentedString(restructuringInstanceReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

