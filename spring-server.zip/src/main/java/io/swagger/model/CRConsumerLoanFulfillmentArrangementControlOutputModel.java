package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementControlOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementControlOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementControlActionTaskReference")
  private String consumerLoanFulfillmentArrangementControlActionTaskReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementControlActionTaskRecord")
  private Object consumerLoanFulfillmentArrangementControlActionTaskRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementControlActionResponse")
  private String consumerLoanFulfillmentArrangementControlActionResponse = null;

  public CRConsumerLoanFulfillmentArrangementControlOutputModel consumerLoanFulfillmentArrangementControlActionTaskReference(String consumerLoanFulfillmentArrangementControlActionTaskReference) {
    this.consumerLoanFulfillmentArrangementControlActionTaskReference = consumerLoanFulfillmentArrangementControlActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Consumer Loan Fulfillment Arrangement instance control processing service call 
   * @return consumerLoanFulfillmentArrangementControlActionTaskReference
  **/
  @ApiModelProperty(example = "CLFACATR722455", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Consumer Loan Fulfillment Arrangement instance control processing service call ")


  public String getConsumerLoanFulfillmentArrangementControlActionTaskReference() {
    return consumerLoanFulfillmentArrangementControlActionTaskReference;
  }

  public void setConsumerLoanFulfillmentArrangementControlActionTaskReference(String consumerLoanFulfillmentArrangementControlActionTaskReference) {
    this.consumerLoanFulfillmentArrangementControlActionTaskReference = consumerLoanFulfillmentArrangementControlActionTaskReference;
  }

  public CRConsumerLoanFulfillmentArrangementControlOutputModel consumerLoanFulfillmentArrangementControlActionTaskRecord(Object consumerLoanFulfillmentArrangementControlActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementControlActionTaskRecord = consumerLoanFulfillmentArrangementControlActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The processing control service call consolidated processing record 
   * @return consumerLoanFulfillmentArrangementControlActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The processing control service call consolidated processing record ")


  public Object getConsumerLoanFulfillmentArrangementControlActionTaskRecord() {
    return consumerLoanFulfillmentArrangementControlActionTaskRecord;
  }

  public void setConsumerLoanFulfillmentArrangementControlActionTaskRecord(Object consumerLoanFulfillmentArrangementControlActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementControlActionTaskRecord = consumerLoanFulfillmentArrangementControlActionTaskRecord;
  }

  public CRConsumerLoanFulfillmentArrangementControlOutputModel consumerLoanFulfillmentArrangementControlActionResponse(String consumerLoanFulfillmentArrangementControlActionResponse) {
    this.consumerLoanFulfillmentArrangementControlActionResponse = consumerLoanFulfillmentArrangementControlActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the control action service response 
   * @return consumerLoanFulfillmentArrangementControlActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the control action service response ")


  public String getConsumerLoanFulfillmentArrangementControlActionResponse() {
    return consumerLoanFulfillmentArrangementControlActionResponse;
  }

  public void setConsumerLoanFulfillmentArrangementControlActionResponse(String consumerLoanFulfillmentArrangementControlActionResponse) {
    this.consumerLoanFulfillmentArrangementControlActionResponse = consumerLoanFulfillmentArrangementControlActionResponse;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementControlOutputModel crConsumerLoanFulfillmentArrangementControlOutputModel = (CRConsumerLoanFulfillmentArrangementControlOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementControlActionTaskReference, crConsumerLoanFulfillmentArrangementControlOutputModel.consumerLoanFulfillmentArrangementControlActionTaskReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementControlActionTaskRecord, crConsumerLoanFulfillmentArrangementControlOutputModel.consumerLoanFulfillmentArrangementControlActionTaskRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementControlActionResponse, crConsumerLoanFulfillmentArrangementControlOutputModel.consumerLoanFulfillmentArrangementControlActionResponse);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementControlActionTaskReference, consumerLoanFulfillmentArrangementControlActionTaskRecord, consumerLoanFulfillmentArrangementControlActionResponse);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementControlOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementControlActionTaskReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementControlActionTaskReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementControlActionTaskRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementControlActionTaskRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementControlActionResponse: ").append(toIndentedString(consumerLoanFulfillmentArrangementControlActionResponse)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

