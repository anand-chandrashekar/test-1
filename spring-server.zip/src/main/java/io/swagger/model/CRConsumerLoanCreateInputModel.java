package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanCreateInputModelConsumerLoanRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanCreateInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanCreateInputModel   {
  @JsonProperty("consumerLoanRecord")
  private CRConsumerLoanCreateInputModelConsumerLoanRecord consumerLoanRecord = null;

  public CRConsumerLoanCreateInputModel consumerLoanRecord(CRConsumerLoanCreateInputModelConsumerLoanRecord consumerLoanRecord) {
    this.consumerLoanRecord = consumerLoanRecord;
    return this;
  }

  /**
   * Get consumerLoanRecord
   * @return consumerLoanRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanCreateInputModelConsumerLoanRecord getConsumerLoanRecord() {
    return consumerLoanRecord;
  }

  public void setConsumerLoanRecord(CRConsumerLoanCreateInputModelConsumerLoanRecord consumerLoanRecord) {
    this.consumerLoanRecord = consumerLoanRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanCreateInputModel crConsumerLoanCreateInputModel = (CRConsumerLoanCreateInputModel) o;
    return Objects.equals(this.consumerLoanRecord, crConsumerLoanCreateInputModel.consumerLoanRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanCreateInputModel {\n");
    
    sb.append("    consumerLoanRecord: ").append(toIndentedString(consumerLoanRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

