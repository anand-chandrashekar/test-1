package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRequestInputModelMaintenanceInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRequestInputModelMaintenanceInstanceRecord   {
  @JsonProperty("maintenanceReportType")
  private BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType maintenanceReportType = null;

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceReportType(BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType maintenanceReportType) {
    this.maintenanceReportType = maintenanceReportType;
    return this;
  }

  /**
   * Get maintenanceReportType
   * @return maintenanceReportType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType getMaintenanceReportType() {
    return maintenanceReportType;
  }

  public void setMaintenanceReportType(BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType maintenanceReportType) {
    this.maintenanceReportType = maintenanceReportType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRequestInputModelMaintenanceInstanceRecord bqMaintenanceRequestInputModelMaintenanceInstanceRecord = (BQMaintenanceRequestInputModelMaintenanceInstanceRecord) o;
    return Objects.equals(this.maintenanceReportType, bqMaintenanceRequestInputModelMaintenanceInstanceRecord.maintenanceReportType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(maintenanceReportType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRequestInputModelMaintenanceInstanceRecord {\n");
    
    sb.append("    maintenanceReportType: ").append(toIndentedString(maintenanceReportType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

