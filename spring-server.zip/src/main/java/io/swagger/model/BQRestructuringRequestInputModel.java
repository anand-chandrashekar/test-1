package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRequestInputModelRequestRecordType;
import io.swagger.model.BQRestructuringInitiateInputModelRestructuringInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringRequestInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringRequestInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("restructuringInstanceReference")
  private String restructuringInstanceReference = null;

  @JsonProperty("restructuringInstanceRecord")
  private BQRestructuringInitiateInputModelRestructuringInstanceRecord restructuringInstanceRecord = null;

  @JsonProperty("restructuringRequestActionTaskRecord")
  private Object restructuringRequestActionTaskRecord = null;

  @JsonProperty("requestRecordType")
  private BQMaintenanceRequestInputModelRequestRecordType requestRecordType = null;

  public BQRestructuringRequestInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR746024", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQRestructuringRequestInputModel restructuringInstanceReference(String restructuringInstanceReference) {
    this.restructuringInstanceReference = restructuringInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring instance 
   * @return restructuringInstanceReference
  **/
  @ApiModelProperty(example = "RIR718314", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring instance ")


  public String getRestructuringInstanceReference() {
    return restructuringInstanceReference;
  }

  public void setRestructuringInstanceReference(String restructuringInstanceReference) {
    this.restructuringInstanceReference = restructuringInstanceReference;
  }

  public BQRestructuringRequestInputModel restructuringInstanceRecord(BQRestructuringInitiateInputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
    return this;
  }

  /**
   * Get restructuringInstanceRecord
   * @return restructuringInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringInitiateInputModelRestructuringInstanceRecord getRestructuringInstanceRecord() {
    return restructuringInstanceRecord;
  }

  public void setRestructuringInstanceRecord(BQRestructuringInitiateInputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
  }

  public BQRestructuringRequestInputModel restructuringRequestActionTaskRecord(Object restructuringRequestActionTaskRecord) {
    this.restructuringRequestActionTaskRecord = restructuringRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return restructuringRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getRestructuringRequestActionTaskRecord() {
    return restructuringRequestActionTaskRecord;
  }

  public void setRestructuringRequestActionTaskRecord(Object restructuringRequestActionTaskRecord) {
    this.restructuringRequestActionTaskRecord = restructuringRequestActionTaskRecord;
  }

  public BQRestructuringRequestInputModel requestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
    return this;
  }

  /**
   * Get requestRecordType
   * @return requestRecordType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelRequestRecordType getRequestRecordType() {
    return requestRecordType;
  }

  public void setRequestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringRequestInputModel bqRestructuringRequestInputModel = (BQRestructuringRequestInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqRestructuringRequestInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.restructuringInstanceReference, bqRestructuringRequestInputModel.restructuringInstanceReference) &&
        Objects.equals(this.restructuringInstanceRecord, bqRestructuringRequestInputModel.restructuringInstanceRecord) &&
        Objects.equals(this.restructuringRequestActionTaskRecord, bqRestructuringRequestInputModel.restructuringRequestActionTaskRecord) &&
        Objects.equals(this.requestRecordType, bqRestructuringRequestInputModel.requestRecordType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, restructuringInstanceReference, restructuringInstanceRecord, restructuringRequestActionTaskRecord, requestRecordType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringRequestInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    restructuringInstanceReference: ").append(toIndentedString(restructuringInstanceReference)).append("\n");
    sb.append("    restructuringInstanceRecord: ").append(toIndentedString(restructuringInstanceRecord)).append("\n");
    sb.append("    restructuringRequestActionTaskRecord: ").append(toIndentedString(restructuringRequestActionTaskRecord)).append("\n");
    sb.append("    requestRecordType: ").append(toIndentedString(requestRecordType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

