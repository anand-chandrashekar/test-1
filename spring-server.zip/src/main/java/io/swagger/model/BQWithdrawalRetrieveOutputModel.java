package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQWithdrawalRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis;
import io.swagger.model.BQWithdrawalRetrieveOutputModelWithdrawalInstanceRecord;
import io.swagger.model.BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQWithdrawalRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("withdrawalInstanceRecord")
  private BQWithdrawalRetrieveOutputModelWithdrawalInstanceRecord withdrawalInstanceRecord = null;

  @JsonProperty("withdrawalRetrieveActionTaskReference")
  private String withdrawalRetrieveActionTaskReference = null;

  @JsonProperty("withdrawalRetrieveActionTaskRecord")
  private Object withdrawalRetrieveActionTaskRecord = null;

  @JsonProperty("withdrawalRetrieveActionResponse")
  private String withdrawalRetrieveActionResponse = null;

  @JsonProperty("withdrawalInstanceReport")
  private BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport withdrawalInstanceReport = null;

  @JsonProperty("withdrawalInstanceAnalysis")
  private BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysis = null;

  public BQWithdrawalRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQWithdrawalRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQWithdrawalRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQWithdrawalRetrieveOutputModel withdrawalInstanceRecord(BQWithdrawalRetrieveOutputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
    return this;
  }

  /**
   * Get withdrawalInstanceRecord
   * @return withdrawalInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceRecord getWithdrawalInstanceRecord() {
    return withdrawalInstanceRecord;
  }

  public void setWithdrawalInstanceRecord(BQWithdrawalRetrieveOutputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
  }

  public BQWithdrawalRetrieveOutputModel withdrawalRetrieveActionTaskReference(String withdrawalRetrieveActionTaskReference) {
    this.withdrawalRetrieveActionTaskReference = withdrawalRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Withdrawal instance retrieve service call 
   * @return withdrawalRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "WRATR748809", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Withdrawal instance retrieve service call ")


  public String getWithdrawalRetrieveActionTaskReference() {
    return withdrawalRetrieveActionTaskReference;
  }

  public void setWithdrawalRetrieveActionTaskReference(String withdrawalRetrieveActionTaskReference) {
    this.withdrawalRetrieveActionTaskReference = withdrawalRetrieveActionTaskReference;
  }

  public BQWithdrawalRetrieveOutputModel withdrawalRetrieveActionTaskRecord(Object withdrawalRetrieveActionTaskRecord) {
    this.withdrawalRetrieveActionTaskRecord = withdrawalRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return withdrawalRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getWithdrawalRetrieveActionTaskRecord() {
    return withdrawalRetrieveActionTaskRecord;
  }

  public void setWithdrawalRetrieveActionTaskRecord(Object withdrawalRetrieveActionTaskRecord) {
    this.withdrawalRetrieveActionTaskRecord = withdrawalRetrieveActionTaskRecord;
  }

  public BQWithdrawalRetrieveOutputModel withdrawalRetrieveActionResponse(String withdrawalRetrieveActionResponse) {
    this.withdrawalRetrieveActionResponse = withdrawalRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return withdrawalRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getWithdrawalRetrieveActionResponse() {
    return withdrawalRetrieveActionResponse;
  }

  public void setWithdrawalRetrieveActionResponse(String withdrawalRetrieveActionResponse) {
    this.withdrawalRetrieveActionResponse = withdrawalRetrieveActionResponse;
  }

  public BQWithdrawalRetrieveOutputModel withdrawalInstanceReport(BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport withdrawalInstanceReport) {
    this.withdrawalInstanceReport = withdrawalInstanceReport;
    return this;
  }

  /**
   * Get withdrawalInstanceReport
   * @return withdrawalInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport getWithdrawalInstanceReport() {
    return withdrawalInstanceReport;
  }

  public void setWithdrawalInstanceReport(BQWithdrawalRetrieveOutputModelWithdrawalInstanceReport withdrawalInstanceReport) {
    this.withdrawalInstanceReport = withdrawalInstanceReport;
  }

  public BQWithdrawalRetrieveOutputModel withdrawalInstanceAnalysis(BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysis) {
    this.withdrawalInstanceAnalysis = withdrawalInstanceAnalysis;
    return this;
  }

  /**
   * Get withdrawalInstanceAnalysis
   * @return withdrawalInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis getWithdrawalInstanceAnalysis() {
    return withdrawalInstanceAnalysis;
  }

  public void setWithdrawalInstanceAnalysis(BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysis) {
    this.withdrawalInstanceAnalysis = withdrawalInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalRetrieveOutputModel bqWithdrawalRetrieveOutputModel = (BQWithdrawalRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqWithdrawalRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.withdrawalInstanceRecord, bqWithdrawalRetrieveOutputModel.withdrawalInstanceRecord) &&
        Objects.equals(this.withdrawalRetrieveActionTaskReference, bqWithdrawalRetrieveOutputModel.withdrawalRetrieveActionTaskReference) &&
        Objects.equals(this.withdrawalRetrieveActionTaskRecord, bqWithdrawalRetrieveOutputModel.withdrawalRetrieveActionTaskRecord) &&
        Objects.equals(this.withdrawalRetrieveActionResponse, bqWithdrawalRetrieveOutputModel.withdrawalRetrieveActionResponse) &&
        Objects.equals(this.withdrawalInstanceReport, bqWithdrawalRetrieveOutputModel.withdrawalInstanceReport) &&
        Objects.equals(this.withdrawalInstanceAnalysis, bqWithdrawalRetrieveOutputModel.withdrawalInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, withdrawalInstanceRecord, withdrawalRetrieveActionTaskReference, withdrawalRetrieveActionTaskRecord, withdrawalRetrieveActionResponse, withdrawalInstanceReport, withdrawalInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    withdrawalInstanceRecord: ").append(toIndentedString(withdrawalInstanceRecord)).append("\n");
    sb.append("    withdrawalRetrieveActionTaskReference: ").append(toIndentedString(withdrawalRetrieveActionTaskReference)).append("\n");
    sb.append("    withdrawalRetrieveActionTaskRecord: ").append(toIndentedString(withdrawalRetrieveActionTaskRecord)).append("\n");
    sb.append("    withdrawalRetrieveActionResponse: ").append(toIndentedString(withdrawalRetrieveActionResponse)).append("\n");
    sb.append("    withdrawalInstanceReport: ").append(toIndentedString(withdrawalInstanceReport)).append("\n");
    sb.append("    withdrawalInstanceAnalysis: ").append(toIndentedString(withdrawalInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

