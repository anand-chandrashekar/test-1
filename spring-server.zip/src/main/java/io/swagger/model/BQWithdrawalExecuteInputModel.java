package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQServiceFeesExecuteInputModelExecuteRecordType;
import io.swagger.model.BQWithdrawalExecuteInputModelWithdrawalInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalExecuteInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalExecuteInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("withdrawalInstanceReference")
  private String withdrawalInstanceReference = null;

  @JsonProperty("withdrawalInstanceRecord")
  private BQWithdrawalExecuteInputModelWithdrawalInstanceRecord withdrawalInstanceRecord = null;

  @JsonProperty("withdrawalExecuteActionTaskRecord")
  private Object withdrawalExecuteActionTaskRecord = null;

  @JsonProperty("executeRecordType")
  private BQServiceFeesExecuteInputModelExecuteRecordType executeRecordType = null;

  public BQWithdrawalExecuteInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR734717", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQWithdrawalExecuteInputModel withdrawalInstanceReference(String withdrawalInstanceReference) {
    this.withdrawalInstanceReference = withdrawalInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal instance 
   * @return withdrawalInstanceReference
  **/
  @ApiModelProperty(example = "WIR798841", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal instance ")


  public String getWithdrawalInstanceReference() {
    return withdrawalInstanceReference;
  }

  public void setWithdrawalInstanceReference(String withdrawalInstanceReference) {
    this.withdrawalInstanceReference = withdrawalInstanceReference;
  }

  public BQWithdrawalExecuteInputModel withdrawalInstanceRecord(BQWithdrawalExecuteInputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
    return this;
  }

  /**
   * Get withdrawalInstanceRecord
   * @return withdrawalInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecord getWithdrawalInstanceRecord() {
    return withdrawalInstanceRecord;
  }

  public void setWithdrawalInstanceRecord(BQWithdrawalExecuteInputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
  }

  public BQWithdrawalExecuteInputModel withdrawalExecuteActionTaskRecord(Object withdrawalExecuteActionTaskRecord) {
    this.withdrawalExecuteActionTaskRecord = withdrawalExecuteActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The execute service call consolidated processing record 
   * @return withdrawalExecuteActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The execute service call consolidated processing record ")


  public Object getWithdrawalExecuteActionTaskRecord() {
    return withdrawalExecuteActionTaskRecord;
  }

  public void setWithdrawalExecuteActionTaskRecord(Object withdrawalExecuteActionTaskRecord) {
    this.withdrawalExecuteActionTaskRecord = withdrawalExecuteActionTaskRecord;
  }

  public BQWithdrawalExecuteInputModel executeRecordType(BQServiceFeesExecuteInputModelExecuteRecordType executeRecordType) {
    this.executeRecordType = executeRecordType;
    return this;
  }

  /**
   * Get executeRecordType
   * @return executeRecordType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQServiceFeesExecuteInputModelExecuteRecordType getExecuteRecordType() {
    return executeRecordType;
  }

  public void setExecuteRecordType(BQServiceFeesExecuteInputModelExecuteRecordType executeRecordType) {
    this.executeRecordType = executeRecordType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalExecuteInputModel bqWithdrawalExecuteInputModel = (BQWithdrawalExecuteInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqWithdrawalExecuteInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.withdrawalInstanceReference, bqWithdrawalExecuteInputModel.withdrawalInstanceReference) &&
        Objects.equals(this.withdrawalInstanceRecord, bqWithdrawalExecuteInputModel.withdrawalInstanceRecord) &&
        Objects.equals(this.withdrawalExecuteActionTaskRecord, bqWithdrawalExecuteInputModel.withdrawalExecuteActionTaskRecord) &&
        Objects.equals(this.executeRecordType, bqWithdrawalExecuteInputModel.executeRecordType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, withdrawalInstanceReference, withdrawalInstanceRecord, withdrawalExecuteActionTaskRecord, executeRecordType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalExecuteInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    withdrawalInstanceReference: ").append(toIndentedString(withdrawalInstanceReference)).append("\n");
    sb.append("    withdrawalInstanceRecord: ").append(toIndentedString(withdrawalInstanceRecord)).append("\n");
    sb.append("    withdrawalExecuteActionTaskRecord: ").append(toIndentedString(withdrawalExecuteActionTaskRecord)).append("\n");
    sb.append("    executeRecordType: ").append(toIndentedString(executeRecordType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

