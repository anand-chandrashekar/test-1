package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringExchangeOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringExchangeOutputModel   {
  @JsonProperty("restructuringExchangeActionTaskReference")
  private String restructuringExchangeActionTaskReference = null;

  @JsonProperty("restructuringExchangeActionTaskRecord")
  private Object restructuringExchangeActionTaskRecord = null;

  @JsonProperty("restructuringExchangeActionResponse")
  private String restructuringExchangeActionResponse = null;

  @JsonProperty("restructuringInstanceStatus")
  private String restructuringInstanceStatus = null;

  public BQRestructuringExchangeOutputModel restructuringExchangeActionTaskReference(String restructuringExchangeActionTaskReference) {
    this.restructuringExchangeActionTaskReference = restructuringExchangeActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Restructuring instance exchange service call 
   * @return restructuringExchangeActionTaskReference
  **/
  @ApiModelProperty(example = "REATR729446", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Restructuring instance exchange service call ")


  public String getRestructuringExchangeActionTaskReference() {
    return restructuringExchangeActionTaskReference;
  }

  public void setRestructuringExchangeActionTaskReference(String restructuringExchangeActionTaskReference) {
    this.restructuringExchangeActionTaskReference = restructuringExchangeActionTaskReference;
  }

  public BQRestructuringExchangeOutputModel restructuringExchangeActionTaskRecord(Object restructuringExchangeActionTaskRecord) {
    this.restructuringExchangeActionTaskRecord = restructuringExchangeActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The exchange service call consolidated processing record 
   * @return restructuringExchangeActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The exchange service call consolidated processing record ")


  public Object getRestructuringExchangeActionTaskRecord() {
    return restructuringExchangeActionTaskRecord;
  }

  public void setRestructuringExchangeActionTaskRecord(Object restructuringExchangeActionTaskRecord) {
    this.restructuringExchangeActionTaskRecord = restructuringExchangeActionTaskRecord;
  }

  public BQRestructuringExchangeOutputModel restructuringExchangeActionResponse(String restructuringExchangeActionResponse) {
    this.restructuringExchangeActionResponse = restructuringExchangeActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the exchange action service response 
   * @return restructuringExchangeActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the exchange action service response ")


  public String getRestructuringExchangeActionResponse() {
    return restructuringExchangeActionResponse;
  }

  public void setRestructuringExchangeActionResponse(String restructuringExchangeActionResponse) {
    this.restructuringExchangeActionResponse = restructuringExchangeActionResponse;
  }

  public BQRestructuringExchangeOutputModel restructuringInstanceStatus(String restructuringInstanceStatus) {
    this.restructuringInstanceStatus = restructuringInstanceStatus;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The status of the Restructuring instance (e.g. accepted, rejected, verified) 
   * @return restructuringInstanceStatus
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The status of the Restructuring instance (e.g. accepted, rejected, verified) ")


  public String getRestructuringInstanceStatus() {
    return restructuringInstanceStatus;
  }

  public void setRestructuringInstanceStatus(String restructuringInstanceStatus) {
    this.restructuringInstanceStatus = restructuringInstanceStatus;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringExchangeOutputModel bqRestructuringExchangeOutputModel = (BQRestructuringExchangeOutputModel) o;
    return Objects.equals(this.restructuringExchangeActionTaskReference, bqRestructuringExchangeOutputModel.restructuringExchangeActionTaskReference) &&
        Objects.equals(this.restructuringExchangeActionTaskRecord, bqRestructuringExchangeOutputModel.restructuringExchangeActionTaskRecord) &&
        Objects.equals(this.restructuringExchangeActionResponse, bqRestructuringExchangeOutputModel.restructuringExchangeActionResponse) &&
        Objects.equals(this.restructuringInstanceStatus, bqRestructuringExchangeOutputModel.restructuringInstanceStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(restructuringExchangeActionTaskReference, restructuringExchangeActionTaskRecord, restructuringExchangeActionResponse, restructuringInstanceStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringExchangeOutputModel {\n");
    
    sb.append("    restructuringExchangeActionTaskReference: ").append(toIndentedString(restructuringExchangeActionTaskReference)).append("\n");
    sb.append("    restructuringExchangeActionTaskRecord: ").append(toIndentedString(restructuringExchangeActionTaskRecord)).append("\n");
    sb.append("    restructuringExchangeActionResponse: ").append(toIndentedString(restructuringExchangeActionResponse)).append("\n");
    sb.append("    restructuringInstanceStatus: ").append(toIndentedString(restructuringInstanceStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

