package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQInterestRetrieveOutputModelInterestInstanceAnalysis;
import io.swagger.model.BQInterestRetrieveOutputModelInterestInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQInterestRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQInterestRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("interestInstanceRecord")
  private Object interestInstanceRecord = null;

  @JsonProperty("interestRetrieveActionTaskReference")
  private String interestRetrieveActionTaskReference = null;

  @JsonProperty("interestRetrieveActionTaskRecord")
  private Object interestRetrieveActionTaskRecord = null;

  @JsonProperty("interestRetrieveActionResponse")
  private String interestRetrieveActionResponse = null;

  @JsonProperty("interestInstanceReport")
  private BQInterestRetrieveOutputModelInterestInstanceReport interestInstanceReport = null;

  @JsonProperty("interestInstanceAnalysis")
  private BQInterestRetrieveOutputModelInterestInstanceAnalysis interestInstanceAnalysis = null;

  public BQInterestRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQInterestRetrieveOutputModel interestInstanceRecord(Object interestInstanceRecord) {
    this.interestInstanceRecord = interestInstanceRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Applies interest to the loan account interestRateType:  type: string  description: |   `status: Not Mapped`    core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text    general-info: The type of rate calculation that can be applied interestRateApplicationSchedule:  type: string  description: |   `status: Not Mapped`    core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text    general-info: The processing schedule for applying interest rates to the account interestRateConfiguration:  type: object  properties:   interestRateType:    type: string    description: |     `status: Not Mapped`      core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text      general-info: Applicable rate type   interestRate:    type: string    description: |     `status: Not Mapped`      core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text      general-info: The interest rate value to be applied (note could be variable) interestApplicationRecord:  type: object  properties:   interestTransaction:    type: object    properties:     transactionDescription:      type: string      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text        general-info: General description of the interest transaction     transactionRateType:      type: string      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text        general-info: Applicable rate type     transactionInterestCharge:      type: string      example: USD 250      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount        general-info: The derived interest amount to be applied   interestAccrualAmount:    type: object    properties:     interestAccrualType:      type: string      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text        general-info: The interest type being tracked     interestAccrualCharge:      type: string      example: USD 250      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount        general-info: The accrued amount of applied interest 
   * @return interestInstanceRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Applies interest to the loan account interestRateType:  type: string  description: |   `status: Not Mapped`    core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text    general-info: The type of rate calculation that can be applied interestRateApplicationSchedule:  type: string  description: |   `status: Not Mapped`    core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text    general-info: The processing schedule for applying interest rates to the account interestRateConfiguration:  type: object  properties:   interestRateType:    type: string    description: |     `status: Not Mapped`      core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text      general-info: Applicable rate type   interestRate:    type: string    description: |     `status: Not Mapped`      core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text      general-info: The interest rate value to be applied (note could be variable) interestApplicationRecord:  type: object  properties:   interestTransaction:    type: object    properties:     transactionDescription:      type: string      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text        general-info: General description of the interest transaction     transactionRateType:      type: string      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text        general-info: Applicable rate type     transactionInterestCharge:      type: string      example: USD 250      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount        general-info: The derived interest amount to be applied   interestAccrualAmount:    type: object    properties:     interestAccrualType:      type: string      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text        general-info: The interest type being tracked     interestAccrualCharge:      type: string      example: USD 250      description: |       `status: Not Mapped`        core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount        general-info: The accrued amount of applied interest ")


  public Object getInterestInstanceRecord() {
    return interestInstanceRecord;
  }

  public void setInterestInstanceRecord(Object interestInstanceRecord) {
    this.interestInstanceRecord = interestInstanceRecord;
  }

  public BQInterestRetrieveOutputModel interestRetrieveActionTaskReference(String interestRetrieveActionTaskReference) {
    this.interestRetrieveActionTaskReference = interestRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Interest instance retrieve service call 
   * @return interestRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "IRATR758844", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Interest instance retrieve service call ")


  public String getInterestRetrieveActionTaskReference() {
    return interestRetrieveActionTaskReference;
  }

  public void setInterestRetrieveActionTaskReference(String interestRetrieveActionTaskReference) {
    this.interestRetrieveActionTaskReference = interestRetrieveActionTaskReference;
  }

  public BQInterestRetrieveOutputModel interestRetrieveActionTaskRecord(Object interestRetrieveActionTaskRecord) {
    this.interestRetrieveActionTaskRecord = interestRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return interestRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getInterestRetrieveActionTaskRecord() {
    return interestRetrieveActionTaskRecord;
  }

  public void setInterestRetrieveActionTaskRecord(Object interestRetrieveActionTaskRecord) {
    this.interestRetrieveActionTaskRecord = interestRetrieveActionTaskRecord;
  }

  public BQInterestRetrieveOutputModel interestRetrieveActionResponse(String interestRetrieveActionResponse) {
    this.interestRetrieveActionResponse = interestRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return interestRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getInterestRetrieveActionResponse() {
    return interestRetrieveActionResponse;
  }

  public void setInterestRetrieveActionResponse(String interestRetrieveActionResponse) {
    this.interestRetrieveActionResponse = interestRetrieveActionResponse;
  }

  public BQInterestRetrieveOutputModel interestInstanceReport(BQInterestRetrieveOutputModelInterestInstanceReport interestInstanceReport) {
    this.interestInstanceReport = interestInstanceReport;
    return this;
  }

  /**
   * Get interestInstanceReport
   * @return interestInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQInterestRetrieveOutputModelInterestInstanceReport getInterestInstanceReport() {
    return interestInstanceReport;
  }

  public void setInterestInstanceReport(BQInterestRetrieveOutputModelInterestInstanceReport interestInstanceReport) {
    this.interestInstanceReport = interestInstanceReport;
  }

  public BQInterestRetrieveOutputModel interestInstanceAnalysis(BQInterestRetrieveOutputModelInterestInstanceAnalysis interestInstanceAnalysis) {
    this.interestInstanceAnalysis = interestInstanceAnalysis;
    return this;
  }

  /**
   * Get interestInstanceAnalysis
   * @return interestInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQInterestRetrieveOutputModelInterestInstanceAnalysis getInterestInstanceAnalysis() {
    return interestInstanceAnalysis;
  }

  public void setInterestInstanceAnalysis(BQInterestRetrieveOutputModelInterestInstanceAnalysis interestInstanceAnalysis) {
    this.interestInstanceAnalysis = interestInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQInterestRetrieveOutputModel bqInterestRetrieveOutputModel = (BQInterestRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqInterestRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.interestInstanceRecord, bqInterestRetrieveOutputModel.interestInstanceRecord) &&
        Objects.equals(this.interestRetrieveActionTaskReference, bqInterestRetrieveOutputModel.interestRetrieveActionTaskReference) &&
        Objects.equals(this.interestRetrieveActionTaskRecord, bqInterestRetrieveOutputModel.interestRetrieveActionTaskRecord) &&
        Objects.equals(this.interestRetrieveActionResponse, bqInterestRetrieveOutputModel.interestRetrieveActionResponse) &&
        Objects.equals(this.interestInstanceReport, bqInterestRetrieveOutputModel.interestInstanceReport) &&
        Objects.equals(this.interestInstanceAnalysis, bqInterestRetrieveOutputModel.interestInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, interestInstanceRecord, interestRetrieveActionTaskReference, interestRetrieveActionTaskRecord, interestRetrieveActionResponse, interestInstanceReport, interestInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQInterestRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    interestInstanceRecord: ").append(toIndentedString(interestInstanceRecord)).append("\n");
    sb.append("    interestRetrieveActionTaskReference: ").append(toIndentedString(interestRetrieveActionTaskReference)).append("\n");
    sb.append("    interestRetrieveActionTaskRecord: ").append(toIndentedString(interestRetrieveActionTaskRecord)).append("\n");
    sb.append("    interestRetrieveActionResponse: ").append(toIndentedString(interestRetrieveActionResponse)).append("\n");
    sb.append("    interestInstanceReport: ").append(toIndentedString(interestInstanceReport)).append("\n");
    sb.append("    interestInstanceAnalysis: ").append(toIndentedString(interestInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

