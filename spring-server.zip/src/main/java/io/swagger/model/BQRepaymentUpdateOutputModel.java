package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRepaymentUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQRepaymentUpdateInputModelRepaymentInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentUpdateOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentUpdateOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQRepaymentUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("repaymentInstanceRecord")
  private BQRepaymentUpdateInputModelRepaymentInstanceRecord repaymentInstanceRecord = null;

  @JsonProperty("repaymentUpdateActionTaskReference")
  private String repaymentUpdateActionTaskReference = null;

  @JsonProperty("repaymentUpdateActionTaskRecord")
  private Object repaymentUpdateActionTaskRecord = null;

  @JsonProperty("updateResponseRecord")
  private Object updateResponseRecord = null;

  public BQRepaymentUpdateOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQRepaymentUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQRepaymentUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQRepaymentUpdateOutputModel repaymentInstanceRecord(BQRepaymentUpdateInputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
    return this;
  }

  /**
   * Get repaymentInstanceRecord
   * @return repaymentInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentUpdateInputModelRepaymentInstanceRecord getRepaymentInstanceRecord() {
    return repaymentInstanceRecord;
  }

  public void setRepaymentInstanceRecord(BQRepaymentUpdateInputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
  }

  public BQRepaymentUpdateOutputModel repaymentUpdateActionTaskReference(String repaymentUpdateActionTaskReference) {
    this.repaymentUpdateActionTaskReference = repaymentUpdateActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an update service call 
   * @return repaymentUpdateActionTaskReference
  **/
  @ApiModelProperty(example = "RUATR721714", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an update service call ")


  public String getRepaymentUpdateActionTaskReference() {
    return repaymentUpdateActionTaskReference;
  }

  public void setRepaymentUpdateActionTaskReference(String repaymentUpdateActionTaskReference) {
    this.repaymentUpdateActionTaskReference = repaymentUpdateActionTaskReference;
  }

  public BQRepaymentUpdateOutputModel repaymentUpdateActionTaskRecord(Object repaymentUpdateActionTaskRecord) {
    this.repaymentUpdateActionTaskRecord = repaymentUpdateActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record 
   * @return repaymentUpdateActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record ")


  public Object getRepaymentUpdateActionTaskRecord() {
    return repaymentUpdateActionTaskRecord;
  }

  public void setRepaymentUpdateActionTaskRecord(Object repaymentUpdateActionTaskRecord) {
    this.repaymentUpdateActionTaskRecord = repaymentUpdateActionTaskRecord;
  }

  public BQRepaymentUpdateOutputModel updateResponseRecord(Object updateResponseRecord) {
    this.updateResponseRecord = updateResponseRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the Update action service response 
   * @return updateResponseRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the Update action service response ")


  public Object getUpdateResponseRecord() {
    return updateResponseRecord;
  }

  public void setUpdateResponseRecord(Object updateResponseRecord) {
    this.updateResponseRecord = updateResponseRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentUpdateOutputModel bqRepaymentUpdateOutputModel = (BQRepaymentUpdateOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqRepaymentUpdateOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.repaymentInstanceRecord, bqRepaymentUpdateOutputModel.repaymentInstanceRecord) &&
        Objects.equals(this.repaymentUpdateActionTaskReference, bqRepaymentUpdateOutputModel.repaymentUpdateActionTaskReference) &&
        Objects.equals(this.repaymentUpdateActionTaskRecord, bqRepaymentUpdateOutputModel.repaymentUpdateActionTaskRecord) &&
        Objects.equals(this.updateResponseRecord, bqRepaymentUpdateOutputModel.updateResponseRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, repaymentInstanceRecord, repaymentUpdateActionTaskReference, repaymentUpdateActionTaskRecord, updateResponseRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentUpdateOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    repaymentInstanceRecord: ").append(toIndentedString(repaymentInstanceRecord)).append("\n");
    sb.append("    repaymentUpdateActionTaskReference: ").append(toIndentedString(repaymentUpdateActionTaskReference)).append("\n");
    sb.append("    repaymentUpdateActionTaskRecord: ").append(toIndentedString(repaymentUpdateActionTaskRecord)).append("\n");
    sb.append("    updateResponseRecord: ").append(toIndentedString(updateResponseRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

