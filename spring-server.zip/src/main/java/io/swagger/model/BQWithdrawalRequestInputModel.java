package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRequestInputModelRequestRecordType;
import io.swagger.model.BQWithdrawalRequestInputModelWithdrawalInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalRequestInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalRequestInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("withdrawalInstanceReference")
  private String withdrawalInstanceReference = null;

  @JsonProperty("withdrawalInstanceRecord")
  private BQWithdrawalRequestInputModelWithdrawalInstanceRecord withdrawalInstanceRecord = null;

  @JsonProperty("withdrawalRequestActionTaskRecord")
  private Object withdrawalRequestActionTaskRecord = null;

  @JsonProperty("requestRecordType")
  private BQMaintenanceRequestInputModelRequestRecordType requestRecordType = null;

  public BQWithdrawalRequestInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR790219", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQWithdrawalRequestInputModel withdrawalInstanceReference(String withdrawalInstanceReference) {
    this.withdrawalInstanceReference = withdrawalInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal instance 
   * @return withdrawalInstanceReference
  **/
  @ApiModelProperty(example = "WIR729295", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal instance ")


  public String getWithdrawalInstanceReference() {
    return withdrawalInstanceReference;
  }

  public void setWithdrawalInstanceReference(String withdrawalInstanceReference) {
    this.withdrawalInstanceReference = withdrawalInstanceReference;
  }

  public BQWithdrawalRequestInputModel withdrawalInstanceRecord(BQWithdrawalRequestInputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
    return this;
  }

  /**
   * Get withdrawalInstanceRecord
   * @return withdrawalInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalRequestInputModelWithdrawalInstanceRecord getWithdrawalInstanceRecord() {
    return withdrawalInstanceRecord;
  }

  public void setWithdrawalInstanceRecord(BQWithdrawalRequestInputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
  }

  public BQWithdrawalRequestInputModel withdrawalRequestActionTaskRecord(Object withdrawalRequestActionTaskRecord) {
    this.withdrawalRequestActionTaskRecord = withdrawalRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return withdrawalRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getWithdrawalRequestActionTaskRecord() {
    return withdrawalRequestActionTaskRecord;
  }

  public void setWithdrawalRequestActionTaskRecord(Object withdrawalRequestActionTaskRecord) {
    this.withdrawalRequestActionTaskRecord = withdrawalRequestActionTaskRecord;
  }

  public BQWithdrawalRequestInputModel requestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
    return this;
  }

  /**
   * Get requestRecordType
   * @return requestRecordType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelRequestRecordType getRequestRecordType() {
    return requestRecordType;
  }

  public void setRequestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalRequestInputModel bqWithdrawalRequestInputModel = (BQWithdrawalRequestInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqWithdrawalRequestInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.withdrawalInstanceReference, bqWithdrawalRequestInputModel.withdrawalInstanceReference) &&
        Objects.equals(this.withdrawalInstanceRecord, bqWithdrawalRequestInputModel.withdrawalInstanceRecord) &&
        Objects.equals(this.withdrawalRequestActionTaskRecord, bqWithdrawalRequestInputModel.withdrawalRequestActionTaskRecord) &&
        Objects.equals(this.requestRecordType, bqWithdrawalRequestInputModel.requestRecordType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, withdrawalInstanceReference, withdrawalInstanceRecord, withdrawalRequestActionTaskRecord, requestRecordType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalRequestInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    withdrawalInstanceReference: ").append(toIndentedString(withdrawalInstanceReference)).append("\n");
    sb.append("    withdrawalInstanceRecord: ").append(toIndentedString(withdrawalInstanceRecord)).append("\n");
    sb.append("    withdrawalRequestActionTaskRecord: ").append(toIndentedString(withdrawalRequestActionTaskRecord)).append("\n");
    sb.append("    requestRecordType: ").append(toIndentedString(requestRecordType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

