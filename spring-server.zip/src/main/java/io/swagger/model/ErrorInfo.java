package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ErrorInfo;
import io.swagger.model.ErrorInfoSourceDetails;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * This section contains information about a specific error such as a unique code to identify the error and a textual string to describe the error in more detail.
 */
@ApiModel(description = "This section contains information about a specific error such as a unique code to identify the error and a textual string to describe the error in more detail.")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class ErrorInfo   {
  @JsonProperty("code")
  private String code = null;

  @JsonProperty("causes")
  @Valid
  private List<String> causes = new ArrayList<String>();

  @JsonProperty("sourceDetails")
  private ErrorInfoSourceDetails sourceDetails = null;

  @JsonProperty("extendedDetails")
  private Object extendedDetails = null;

  @JsonProperty("correlationId")
  private String correlationId = null;

  @JsonProperty("errorStack")
  @Valid
  private List<ErrorInfo> errorStack = null;

  public ErrorInfo code(String code) {
    this.code = code;
    return this;
  }

  /**
   * The unique error code for the specific error that has occurred, e.g. COREBANKING-312.
   * @return code
  **/
  @ApiModelProperty(required = true, value = "The unique error code for the specific error that has occurred, e.g. COREBANKING-312.")
  @NotNull


  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ErrorInfo causes(List<String> causes) {
    this.causes = causes;
    return this;
  }

  public ErrorInfo addCausesItem(String causesItem) {
    this.causes.add(causesItem);
    return this;
  }

  /**
   * A description field to give more context about the error that has occurred, e.g. The account does not exist
   * @return causes
  **/
  @ApiModelProperty(required = true, value = "A description field to give more context about the error that has occurred, e.g. The account does not exist")
  @NotNull

@Size(min=1) 
  public List<String> getCauses() {
    return causes;
  }

  public void setCauses(List<String> causes) {
    this.causes = causes;
  }

  public ErrorInfo sourceDetails(ErrorInfoSourceDetails sourceDetails) {
    this.sourceDetails = sourceDetails;
    return this;
  }

  /**
   * Get sourceDetails
   * @return sourceDetails
  **/
  @ApiModelProperty(value = "")

  @Valid

  public ErrorInfoSourceDetails getSourceDetails() {
    return sourceDetails;
  }

  public void setSourceDetails(ErrorInfoSourceDetails sourceDetails) {
    this.sourceDetails = sourceDetails;
  }

  public ErrorInfo extendedDetails(Object extendedDetails) {
    this.extendedDetails = extendedDetails;
    return this;
  }

  /**
   * This object will be populated only when an API needs to provide additional enriching error information. If it is populated then an extended, backward compatible schema should describe the possible fields and how an API client should use them
   * @return extendedDetails
  **/
  @ApiModelProperty(value = "This object will be populated only when an API needs to provide additional enriching error information. If it is populated then an extended, backward compatible schema should describe the possible fields and how an API client should use them")


  public Object getExtendedDetails() {
    return extendedDetails;
  }

  public void setExtendedDetails(Object extendedDetails) {
    this.extendedDetails = extendedDetails;
  }

  public ErrorInfo correlationId(String correlationId) {
    this.correlationId = correlationId;
    return this;
  }

  /**
   * A generated UUID for the request that generated this error. Only populated if generated inside the application. CorrelationIDs sent by a provider will not usually be sent back to the API client as they already have this information
   * @return correlationId
  **/
  @ApiModelProperty(value = "A generated UUID for the request that generated this error. Only populated if generated inside the application. CorrelationIDs sent by a provider will not usually be sent back to the API client as they already have this information")


  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public ErrorInfo errorStack(List<ErrorInfo> errorStack) {
    this.errorStack = errorStack;
    return this;
  }

  public ErrorInfo addErrorStackItem(ErrorInfo errorStackItem) {
    if (this.errorStack == null) {
      this.errorStack = new ArrayList<ErrorInfo>();
    }
    this.errorStack.add(errorStackItem);
    return this;
  }

  /**
   * Get errorStack
   * @return errorStack
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ErrorInfo> getErrorStack() {
    return errorStack;
  }

  public void setErrorStack(List<ErrorInfo> errorStack) {
    this.errorStack = errorStack;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorInfo errorInfo = (ErrorInfo) o;
    return Objects.equals(this.code, errorInfo.code) &&
        Objects.equals(this.causes, errorInfo.causes) &&
        Objects.equals(this.sourceDetails, errorInfo.sourceDetails) &&
        Objects.equals(this.extendedDetails, errorInfo.extendedDetails) &&
        Objects.equals(this.correlationId, errorInfo.correlationId) &&
        Objects.equals(this.errorStack, errorInfo.errorStack);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, causes, sourceDetails, extendedDetails, correlationId, errorStack);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorInfo {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    causes: ").append(toIndentedString(causes)).append("\n");
    sb.append("    sourceDetails: ").append(toIndentedString(sourceDetails)).append("\n");
    sb.append("    extendedDetails: ").append(toIndentedString(extendedDetails)).append("\n");
    sb.append("    correlationId: ").append(toIndentedString(correlationId)).append("\n");
    sb.append("    errorStack: ").append(toIndentedString(errorStack)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

