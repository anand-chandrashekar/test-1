package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReportData")
  private String consumerLoanFulfillmentArrangementInstanceReportData = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReportType")
  private String consumerLoanFulfillmentArrangementInstanceReportType = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReport")
  private Object consumerLoanFulfillmentArrangementInstanceReport = null;

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportData(String consumerLoanFulfillmentArrangementInstanceReportData) {
    this.consumerLoanFulfillmentArrangementInstanceReportData = consumerLoanFulfillmentArrangementInstanceReportData;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected 
   * @return consumerLoanFulfillmentArrangementInstanceReportData
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected ")


  public String getConsumerLoanFulfillmentArrangementInstanceReportData() {
    return consumerLoanFulfillmentArrangementInstanceReportData;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReportData(String consumerLoanFulfillmentArrangementInstanceReportData) {
    this.consumerLoanFulfillmentArrangementInstanceReportData = consumerLoanFulfillmentArrangementInstanceReportData;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportType(String consumerLoanFulfillmentArrangementInstanceReportType) {
    this.consumerLoanFulfillmentArrangementInstanceReportType = consumerLoanFulfillmentArrangementInstanceReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available 
   * @return consumerLoanFulfillmentArrangementInstanceReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available ")


  public String getConsumerLoanFulfillmentArrangementInstanceReportType() {
    return consumerLoanFulfillmentArrangementInstanceReportType;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReportType(String consumerLoanFulfillmentArrangementInstanceReportType) {
    this.consumerLoanFulfillmentArrangementInstanceReportType = consumerLoanFulfillmentArrangementInstanceReportType;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReport(Object consumerLoanFulfillmentArrangementInstanceReport) {
    this.consumerLoanFulfillmentArrangementInstanceReport = consumerLoanFulfillmentArrangementInstanceReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate 
   * @return consumerLoanFulfillmentArrangementInstanceReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate ")


  public Object getConsumerLoanFulfillmentArrangementInstanceReport() {
    return consumerLoanFulfillmentArrangementInstanceReport;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReport(Object consumerLoanFulfillmentArrangementInstanceReport) {
    this.consumerLoanFulfillmentArrangementInstanceReport = consumerLoanFulfillmentArrangementInstanceReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord = (CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReportData, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord.consumerLoanFulfillmentArrangementInstanceReportData) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReportType, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord.consumerLoanFulfillmentArrangementInstanceReportType) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReport, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord.consumerLoanFulfillmentArrangementInstanceReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReportData, consumerLoanFulfillmentArrangementInstanceReportType, consumerLoanFulfillmentArrangementInstanceReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReportData: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReportData)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReportType: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReportType)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReport: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

