package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRestructuringExchangeInputModelRestructuringExchangeActionRequest;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringExchangeInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringExchangeInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("restructuringInstanceReference")
  private String restructuringInstanceReference = null;

  @JsonProperty("restructuringExchangeActionTaskRecord")
  private Object restructuringExchangeActionTaskRecord = null;

  @JsonProperty("restructuringExchangeActionRequest")
  private BQRestructuringExchangeInputModelRestructuringExchangeActionRequest restructuringExchangeActionRequest = null;

  public BQRestructuringExchangeInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR710244", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQRestructuringExchangeInputModel restructuringInstanceReference(String restructuringInstanceReference) {
    this.restructuringInstanceReference = restructuringInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring instance 
   * @return restructuringInstanceReference
  **/
  @ApiModelProperty(example = "RIR710827", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring instance ")


  public String getRestructuringInstanceReference() {
    return restructuringInstanceReference;
  }

  public void setRestructuringInstanceReference(String restructuringInstanceReference) {
    this.restructuringInstanceReference = restructuringInstanceReference;
  }

  public BQRestructuringExchangeInputModel restructuringExchangeActionTaskRecord(Object restructuringExchangeActionTaskRecord) {
    this.restructuringExchangeActionTaskRecord = restructuringExchangeActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The exchange service call consolidated processing record 
   * @return restructuringExchangeActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The exchange service call consolidated processing record ")


  public Object getRestructuringExchangeActionTaskRecord() {
    return restructuringExchangeActionTaskRecord;
  }

  public void setRestructuringExchangeActionTaskRecord(Object restructuringExchangeActionTaskRecord) {
    this.restructuringExchangeActionTaskRecord = restructuringExchangeActionTaskRecord;
  }

  public BQRestructuringExchangeInputModel restructuringExchangeActionRequest(BQRestructuringExchangeInputModelRestructuringExchangeActionRequest restructuringExchangeActionRequest) {
    this.restructuringExchangeActionRequest = restructuringExchangeActionRequest;
    return this;
  }

  /**
   * Get restructuringExchangeActionRequest
   * @return restructuringExchangeActionRequest
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringExchangeInputModelRestructuringExchangeActionRequest getRestructuringExchangeActionRequest() {
    return restructuringExchangeActionRequest;
  }

  public void setRestructuringExchangeActionRequest(BQRestructuringExchangeInputModelRestructuringExchangeActionRequest restructuringExchangeActionRequest) {
    this.restructuringExchangeActionRequest = restructuringExchangeActionRequest;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringExchangeInputModel bqRestructuringExchangeInputModel = (BQRestructuringExchangeInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqRestructuringExchangeInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.restructuringInstanceReference, bqRestructuringExchangeInputModel.restructuringInstanceReference) &&
        Objects.equals(this.restructuringExchangeActionTaskRecord, bqRestructuringExchangeInputModel.restructuringExchangeActionTaskRecord) &&
        Objects.equals(this.restructuringExchangeActionRequest, bqRestructuringExchangeInputModel.restructuringExchangeActionRequest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, restructuringInstanceReference, restructuringExchangeActionTaskRecord, restructuringExchangeActionRequest);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringExchangeInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    restructuringInstanceReference: ").append(toIndentedString(restructuringInstanceReference)).append("\n");
    sb.append("    restructuringExchangeActionTaskRecord: ").append(toIndentedString(restructuringExchangeActionTaskRecord)).append("\n");
    sb.append("    restructuringExchangeActionRequest: ").append(toIndentedString(restructuringExchangeActionRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

