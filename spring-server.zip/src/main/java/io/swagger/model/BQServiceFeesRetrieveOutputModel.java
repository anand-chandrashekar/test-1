package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQServiceFeesRetrieveOutputModelServiceFeesInstanceAnalysis;
import io.swagger.model.BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecord;
import io.swagger.model.BQServiceFeesRetrieveOutputModelServiceFeesInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQServiceFeesRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQServiceFeesRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("serviceFeesInstanceRecord")
  private BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecord serviceFeesInstanceRecord = null;

  @JsonProperty("serviceFeesRetrieveActionTaskReference")
  private String serviceFeesRetrieveActionTaskReference = null;

  @JsonProperty("serviceFeesRetrieveActionTaskRecord")
  private Object serviceFeesRetrieveActionTaskRecord = null;

  @JsonProperty("serviceFeesRetrieveActionResponse")
  private String serviceFeesRetrieveActionResponse = null;

  @JsonProperty("serviceFeesInstanceReport")
  private BQServiceFeesRetrieveOutputModelServiceFeesInstanceReport serviceFeesInstanceReport = null;

  @JsonProperty("serviceFeesInstanceAnalysis")
  private BQServiceFeesRetrieveOutputModelServiceFeesInstanceAnalysis serviceFeesInstanceAnalysis = null;

  public BQServiceFeesRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQServiceFeesRetrieveOutputModel serviceFeesInstanceRecord(BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecord serviceFeesInstanceRecord) {
    this.serviceFeesInstanceRecord = serviceFeesInstanceRecord;
    return this;
  }

  /**
   * Get serviceFeesInstanceRecord
   * @return serviceFeesInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecord getServiceFeesInstanceRecord() {
    return serviceFeesInstanceRecord;
  }

  public void setServiceFeesInstanceRecord(BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecord serviceFeesInstanceRecord) {
    this.serviceFeesInstanceRecord = serviceFeesInstanceRecord;
  }

  public BQServiceFeesRetrieveOutputModel serviceFeesRetrieveActionTaskReference(String serviceFeesRetrieveActionTaskReference) {
    this.serviceFeesRetrieveActionTaskReference = serviceFeesRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Service Fees instance retrieve service call 
   * @return serviceFeesRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "SFRATR713423", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Service Fees instance retrieve service call ")


  public String getServiceFeesRetrieveActionTaskReference() {
    return serviceFeesRetrieveActionTaskReference;
  }

  public void setServiceFeesRetrieveActionTaskReference(String serviceFeesRetrieveActionTaskReference) {
    this.serviceFeesRetrieveActionTaskReference = serviceFeesRetrieveActionTaskReference;
  }

  public BQServiceFeesRetrieveOutputModel serviceFeesRetrieveActionTaskRecord(Object serviceFeesRetrieveActionTaskRecord) {
    this.serviceFeesRetrieveActionTaskRecord = serviceFeesRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return serviceFeesRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getServiceFeesRetrieveActionTaskRecord() {
    return serviceFeesRetrieveActionTaskRecord;
  }

  public void setServiceFeesRetrieveActionTaskRecord(Object serviceFeesRetrieveActionTaskRecord) {
    this.serviceFeesRetrieveActionTaskRecord = serviceFeesRetrieveActionTaskRecord;
  }

  public BQServiceFeesRetrieveOutputModel serviceFeesRetrieveActionResponse(String serviceFeesRetrieveActionResponse) {
    this.serviceFeesRetrieveActionResponse = serviceFeesRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return serviceFeesRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getServiceFeesRetrieveActionResponse() {
    return serviceFeesRetrieveActionResponse;
  }

  public void setServiceFeesRetrieveActionResponse(String serviceFeesRetrieveActionResponse) {
    this.serviceFeesRetrieveActionResponse = serviceFeesRetrieveActionResponse;
  }

  public BQServiceFeesRetrieveOutputModel serviceFeesInstanceReport(BQServiceFeesRetrieveOutputModelServiceFeesInstanceReport serviceFeesInstanceReport) {
    this.serviceFeesInstanceReport = serviceFeesInstanceReport;
    return this;
  }

  /**
   * Get serviceFeesInstanceReport
   * @return serviceFeesInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQServiceFeesRetrieveOutputModelServiceFeesInstanceReport getServiceFeesInstanceReport() {
    return serviceFeesInstanceReport;
  }

  public void setServiceFeesInstanceReport(BQServiceFeesRetrieveOutputModelServiceFeesInstanceReport serviceFeesInstanceReport) {
    this.serviceFeesInstanceReport = serviceFeesInstanceReport;
  }

  public BQServiceFeesRetrieveOutputModel serviceFeesInstanceAnalysis(BQServiceFeesRetrieveOutputModelServiceFeesInstanceAnalysis serviceFeesInstanceAnalysis) {
    this.serviceFeesInstanceAnalysis = serviceFeesInstanceAnalysis;
    return this;
  }

  /**
   * Get serviceFeesInstanceAnalysis
   * @return serviceFeesInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQServiceFeesRetrieveOutputModelServiceFeesInstanceAnalysis getServiceFeesInstanceAnalysis() {
    return serviceFeesInstanceAnalysis;
  }

  public void setServiceFeesInstanceAnalysis(BQServiceFeesRetrieveOutputModelServiceFeesInstanceAnalysis serviceFeesInstanceAnalysis) {
    this.serviceFeesInstanceAnalysis = serviceFeesInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQServiceFeesRetrieveOutputModel bqServiceFeesRetrieveOutputModel = (BQServiceFeesRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqServiceFeesRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.serviceFeesInstanceRecord, bqServiceFeesRetrieveOutputModel.serviceFeesInstanceRecord) &&
        Objects.equals(this.serviceFeesRetrieveActionTaskReference, bqServiceFeesRetrieveOutputModel.serviceFeesRetrieveActionTaskReference) &&
        Objects.equals(this.serviceFeesRetrieveActionTaskRecord, bqServiceFeesRetrieveOutputModel.serviceFeesRetrieveActionTaskRecord) &&
        Objects.equals(this.serviceFeesRetrieveActionResponse, bqServiceFeesRetrieveOutputModel.serviceFeesRetrieveActionResponse) &&
        Objects.equals(this.serviceFeesInstanceReport, bqServiceFeesRetrieveOutputModel.serviceFeesInstanceReport) &&
        Objects.equals(this.serviceFeesInstanceAnalysis, bqServiceFeesRetrieveOutputModel.serviceFeesInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, serviceFeesInstanceRecord, serviceFeesRetrieveActionTaskReference, serviceFeesRetrieveActionTaskRecord, serviceFeesRetrieveActionResponse, serviceFeesInstanceReport, serviceFeesInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQServiceFeesRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    serviceFeesInstanceRecord: ").append(toIndentedString(serviceFeesInstanceRecord)).append("\n");
    sb.append("    serviceFeesRetrieveActionTaskReference: ").append(toIndentedString(serviceFeesRetrieveActionTaskReference)).append("\n");
    sb.append("    serviceFeesRetrieveActionTaskRecord: ").append(toIndentedString(serviceFeesRetrieveActionTaskRecord)).append("\n");
    sb.append("    serviceFeesRetrieveActionResponse: ").append(toIndentedString(serviceFeesRetrieveActionResponse)).append("\n");
    sb.append("    serviceFeesInstanceReport: ").append(toIndentedString(serviceFeesInstanceReport)).append("\n");
    sb.append("    serviceFeesInstanceAnalysis: ").append(toIndentedString(serviceFeesInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

