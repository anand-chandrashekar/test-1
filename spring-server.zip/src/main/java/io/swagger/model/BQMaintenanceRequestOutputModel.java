package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRequestInputModelMaintenanceInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRequestOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRequestOutputModel   {
  @JsonProperty("maintenanceInstanceRecord")
  private BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord = null;

  @JsonProperty("maintenanceRequestActionTaskReference")
  private String maintenanceRequestActionTaskReference = null;

  @JsonProperty("maintenanceRequestActionTaskRecord")
  private Object maintenanceRequestActionTaskRecord = null;

  @JsonProperty("maintenanceRequestRecordReference")
  private String maintenanceRequestRecordReference = null;

  @JsonProperty("requestResponseRecord")
  private Object requestResponseRecord = null;

  public BQMaintenanceRequestOutputModel maintenanceInstanceRecord(BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord) {
    this.maintenanceInstanceRecord = maintenanceInstanceRecord;
    return this;
  }

  /**
   * Get maintenanceInstanceRecord
   * @return maintenanceInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecord getMaintenanceInstanceRecord() {
    return maintenanceInstanceRecord;
  }

  public void setMaintenanceInstanceRecord(BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord) {
    this.maintenanceInstanceRecord = maintenanceInstanceRecord;
  }

  public BQMaintenanceRequestOutputModel maintenanceRequestActionTaskReference(String maintenanceRequestActionTaskReference) {
    this.maintenanceRequestActionTaskReference = maintenanceRequestActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Maintenance instance request service call 
   * @return maintenanceRequestActionTaskReference
  **/
  @ApiModelProperty(example = "MRATR745107", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Maintenance instance request service call ")


  public String getMaintenanceRequestActionTaskReference() {
    return maintenanceRequestActionTaskReference;
  }

  public void setMaintenanceRequestActionTaskReference(String maintenanceRequestActionTaskReference) {
    this.maintenanceRequestActionTaskReference = maintenanceRequestActionTaskReference;
  }

  public BQMaintenanceRequestOutputModel maintenanceRequestActionTaskRecord(Object maintenanceRequestActionTaskRecord) {
    this.maintenanceRequestActionTaskRecord = maintenanceRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return maintenanceRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getMaintenanceRequestActionTaskRecord() {
    return maintenanceRequestActionTaskRecord;
  }

  public void setMaintenanceRequestActionTaskRecord(Object maintenanceRequestActionTaskRecord) {
    this.maintenanceRequestActionTaskRecord = maintenanceRequestActionTaskRecord;
  }

  public BQMaintenanceRequestOutputModel maintenanceRequestRecordReference(String maintenanceRequestRecordReference) {
    this.maintenanceRequestRecordReference = maintenanceRequestRecordReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Maintenance service request record 
   * @return maintenanceRequestRecordReference
  **/
  @ApiModelProperty(example = "MRRR746772", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Maintenance service request record ")


  public String getMaintenanceRequestRecordReference() {
    return maintenanceRequestRecordReference;
  }

  public void setMaintenanceRequestRecordReference(String maintenanceRequestRecordReference) {
    this.maintenanceRequestRecordReference = maintenanceRequestRecordReference;
  }

  public BQMaintenanceRequestOutputModel requestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response 
   * @return requestResponseRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response ")


  public Object getRequestResponseRecord() {
    return requestResponseRecord;
  }

  public void setRequestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRequestOutputModel bqMaintenanceRequestOutputModel = (BQMaintenanceRequestOutputModel) o;
    return Objects.equals(this.maintenanceInstanceRecord, bqMaintenanceRequestOutputModel.maintenanceInstanceRecord) &&
        Objects.equals(this.maintenanceRequestActionTaskReference, bqMaintenanceRequestOutputModel.maintenanceRequestActionTaskReference) &&
        Objects.equals(this.maintenanceRequestActionTaskRecord, bqMaintenanceRequestOutputModel.maintenanceRequestActionTaskRecord) &&
        Objects.equals(this.maintenanceRequestRecordReference, bqMaintenanceRequestOutputModel.maintenanceRequestRecordReference) &&
        Objects.equals(this.requestResponseRecord, bqMaintenanceRequestOutputModel.requestResponseRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(maintenanceInstanceRecord, maintenanceRequestActionTaskReference, maintenanceRequestActionTaskRecord, maintenanceRequestRecordReference, requestResponseRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRequestOutputModel {\n");
    
    sb.append("    maintenanceInstanceRecord: ").append(toIndentedString(maintenanceInstanceRecord)).append("\n");
    sb.append("    maintenanceRequestActionTaskReference: ").append(toIndentedString(maintenanceRequestActionTaskReference)).append("\n");
    sb.append("    maintenanceRequestActionTaskRecord: ").append(toIndentedString(maintenanceRequestActionTaskRecord)).append("\n");
    sb.append("    maintenanceRequestRecordReference: ").append(toIndentedString(maintenanceRequestRecordReference)).append("\n");
    sb.append("    requestResponseRecord: ").append(toIndentedString(requestResponseRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

