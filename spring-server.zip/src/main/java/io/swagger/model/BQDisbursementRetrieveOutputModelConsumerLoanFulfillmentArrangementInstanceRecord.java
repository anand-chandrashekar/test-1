package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord   {
  @JsonProperty("productInstanceReference")
  private String productInstanceReference = null;

  @JsonProperty("consumerLoanNumber")
  private String consumerLoanNumber = null;

  @JsonProperty("customerReference")
  private String customerReference = null;

  @JsonProperty("partyReference")
  private String partyReference = null;

  @JsonProperty("loanOriginationDate")
  private String loanOriginationDate = null;

  @JsonProperty("loanOutstandingBalance")
  private String loanOutstandingBalance = null;

  @JsonProperty("dateType")
  private CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType = null;

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord productInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance 
   * @return productInstanceReference
  **/
  @ApiModelProperty(example = "712949", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance ")


  public String getProductInstanceReference() {
    return productInstanceReference;
  }

  public void setProductInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
  }

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format 
   * @return consumerLoanNumber
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format ")


  public String getConsumerLoanNumber() {
    return consumerLoanNumber;
  }

  public void setConsumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
  }

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerReference(String customerReference) {
    this.customerReference = customerReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner 
   * @return customerReference
  **/
  @ApiModelProperty(example = "743497", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner ")


  public String getCustomerReference() {
    return customerReference;
  }

  public void setCustomerReference(String customerReference) {
    this.customerReference = customerReference;
  }

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord partyReference(String partyReference) {
    this.partyReference = partyReference;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Party).AccountableParty  general-info: The legal entity reference for the borrower, likely to be the same as customer 
   * @return partyReference
  **/
  @ApiModelProperty(example = "728944", value = "`status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Party).AccountableParty  general-info: The legal entity reference for the borrower, likely to be the same as customer ")


  public String getPartyReference() {
    return partyReference;
  }

  public void setPartyReference(String partyReference) {
    this.partyReference = partyReference;
  }

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOriginationDate(String loanOriginationDate) {
    this.loanOriginationDate = loanOriginationDate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_Fey9AMTGEeChad0JzLk7QA_300376414  bian-reference: Loan(as Asset).EffectiveDate  general-info: The origination date for the loan 
   * @return loanOriginationDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_Fey9AMTGEeChad0JzLk7QA_300376414  bian-reference: Loan(as Asset).EffectiveDate  general-info: The origination date for the loan ")


  public String getLoanOriginationDate() {
    return loanOriginationDate;
  }

  public void setLoanOriginationDate(String loanOriginationDate) {
    this.loanOriginationDate = loanOriginationDate;
  }

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance 
   * @return loanOutstandingBalance
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance ")


  public String getLoanOutstandingBalance() {
    return loanOutstandingBalance;
  }

  public void setLoanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
  }

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord dateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
    return this;
  }

  /**
   * Get dateType
   * @return dateType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType getDateType() {
    return dateType;
  }

  public void setDateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord = (BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord) o;
    return Objects.equals(this.productInstanceReference, bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.productInstanceReference) &&
        Objects.equals(this.consumerLoanNumber, bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.consumerLoanNumber) &&
        Objects.equals(this.customerReference, bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerReference) &&
        Objects.equals(this.partyReference, bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.partyReference) &&
        Objects.equals(this.loanOriginationDate, bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOriginationDate) &&
        Objects.equals(this.loanOutstandingBalance, bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOutstandingBalance) &&
        Objects.equals(this.dateType, bqDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.dateType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productInstanceReference, consumerLoanNumber, customerReference, partyReference, loanOriginationDate, loanOutstandingBalance, dateType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord {\n");
    
    sb.append("    productInstanceReference: ").append(toIndentedString(productInstanceReference)).append("\n");
    sb.append("    consumerLoanNumber: ").append(toIndentedString(consumerLoanNumber)).append("\n");
    sb.append("    customerReference: ").append(toIndentedString(customerReference)).append("\n");
    sb.append("    partyReference: ").append(toIndentedString(partyReference)).append("\n");
    sb.append("    loanOriginationDate: ").append(toIndentedString(loanOriginationDate)).append("\n");
    sb.append("    loanOutstandingBalance: ").append(toIndentedString(loanOutstandingBalance)).append("\n");
    sb.append("    dateType: ").append(toIndentedString(dateType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

