package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis   {
  @JsonProperty("disbursementInstanceAnalysisRecord")
  private Object disbursementInstanceAnalysisRecord = null;

  @JsonProperty("disbursementInstanceAnalysisReportType")
  private String disbursementInstanceAnalysisReportType = null;

  @JsonProperty("disbursementInstanceAnalysisParameters")
  private String disbursementInstanceAnalysisParameters = null;

  @JsonProperty("disbursementInstanceAnalysisReport")
  private Object disbursementInstanceAnalysisReport = null;

  public BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis disbursementInstanceAnalysisRecord(Object disbursementInstanceAnalysisRecord) {
    this.disbursementInstanceAnalysisRecord = disbursementInstanceAnalysisRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected 
   * @return disbursementInstanceAnalysisRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected ")


  public Object getDisbursementInstanceAnalysisRecord() {
    return disbursementInstanceAnalysisRecord;
  }

  public void setDisbursementInstanceAnalysisRecord(Object disbursementInstanceAnalysisRecord) {
    this.disbursementInstanceAnalysisRecord = disbursementInstanceAnalysisRecord;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis disbursementInstanceAnalysisReportType(String disbursementInstanceAnalysisReportType) {
    this.disbursementInstanceAnalysisReportType = disbursementInstanceAnalysisReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available 
   * @return disbursementInstanceAnalysisReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available ")


  public String getDisbursementInstanceAnalysisReportType() {
    return disbursementInstanceAnalysisReportType;
  }

  public void setDisbursementInstanceAnalysisReportType(String disbursementInstanceAnalysisReportType) {
    this.disbursementInstanceAnalysisReportType = disbursementInstanceAnalysisReportType;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis disbursementInstanceAnalysisParameters(String disbursementInstanceAnalysisParameters) {
    this.disbursementInstanceAnalysisParameters = disbursementInstanceAnalysisParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) 
   * @return disbursementInstanceAnalysisParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) ")


  public String getDisbursementInstanceAnalysisParameters() {
    return disbursementInstanceAnalysisParameters;
  }

  public void setDisbursementInstanceAnalysisParameters(String disbursementInstanceAnalysisParameters) {
    this.disbursementInstanceAnalysisParameters = disbursementInstanceAnalysisParameters;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis disbursementInstanceAnalysisReport(Object disbursementInstanceAnalysisReport) {
    this.disbursementInstanceAnalysisReport = disbursementInstanceAnalysisReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate 
   * @return disbursementInstanceAnalysisReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate ")


  public Object getDisbursementInstanceAnalysisReport() {
    return disbursementInstanceAnalysisReport;
  }

  public void setDisbursementInstanceAnalysisReport(Object disbursementInstanceAnalysisReport) {
    this.disbursementInstanceAnalysisReport = disbursementInstanceAnalysisReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis bqDisbursementRetrieveOutputModelDisbursementInstanceAnalysis = (BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis) o;
    return Objects.equals(this.disbursementInstanceAnalysisRecord, bqDisbursementRetrieveOutputModelDisbursementInstanceAnalysis.disbursementInstanceAnalysisRecord) &&
        Objects.equals(this.disbursementInstanceAnalysisReportType, bqDisbursementRetrieveOutputModelDisbursementInstanceAnalysis.disbursementInstanceAnalysisReportType) &&
        Objects.equals(this.disbursementInstanceAnalysisParameters, bqDisbursementRetrieveOutputModelDisbursementInstanceAnalysis.disbursementInstanceAnalysisParameters) &&
        Objects.equals(this.disbursementInstanceAnalysisReport, bqDisbursementRetrieveOutputModelDisbursementInstanceAnalysis.disbursementInstanceAnalysisReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(disbursementInstanceAnalysisRecord, disbursementInstanceAnalysisReportType, disbursementInstanceAnalysisParameters, disbursementInstanceAnalysisReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis {\n");
    
    sb.append("    disbursementInstanceAnalysisRecord: ").append(toIndentedString(disbursementInstanceAnalysisRecord)).append("\n");
    sb.append("    disbursementInstanceAnalysisReportType: ").append(toIndentedString(disbursementInstanceAnalysisReportType)).append("\n");
    sb.append("    disbursementInstanceAnalysisParameters: ").append(toIndentedString(disbursementInstanceAnalysisParameters)).append("\n");
    sb.append("    disbursementInstanceAnalysisReport: ").append(toIndentedString(disbursementInstanceAnalysisReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

