package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRepaymentRetrieveInputModelRepaymentInstanceAnalysis;
import io.swagger.model.BQRepaymentRetrieveInputModelRepaymentInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRetrieveInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRetrieveInputModel   {
  @JsonProperty("repaymentRetrieveActionTaskRecord")
  private Object repaymentRetrieveActionTaskRecord = null;

  @JsonProperty("repaymentRetrieveActionRequest")
  private String repaymentRetrieveActionRequest = null;

  @JsonProperty("repaymentInstanceReport")
  private BQRepaymentRetrieveInputModelRepaymentInstanceReport repaymentInstanceReport = null;

  @JsonProperty("repaymentInstanceAnalysis")
  private BQRepaymentRetrieveInputModelRepaymentInstanceAnalysis repaymentInstanceAnalysis = null;

  public BQRepaymentRetrieveInputModel repaymentRetrieveActionTaskRecord(Object repaymentRetrieveActionTaskRecord) {
    this.repaymentRetrieveActionTaskRecord = repaymentRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return repaymentRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getRepaymentRetrieveActionTaskRecord() {
    return repaymentRetrieveActionTaskRecord;
  }

  public void setRepaymentRetrieveActionTaskRecord(Object repaymentRetrieveActionTaskRecord) {
    this.repaymentRetrieveActionTaskRecord = repaymentRetrieveActionTaskRecord;
  }

  public BQRepaymentRetrieveInputModel repaymentRetrieveActionRequest(String repaymentRetrieveActionRequest) {
    this.repaymentRetrieveActionRequest = repaymentRetrieveActionRequest;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) 
   * @return repaymentRetrieveActionRequest
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) ")


  public String getRepaymentRetrieveActionRequest() {
    return repaymentRetrieveActionRequest;
  }

  public void setRepaymentRetrieveActionRequest(String repaymentRetrieveActionRequest) {
    this.repaymentRetrieveActionRequest = repaymentRetrieveActionRequest;
  }

  public BQRepaymentRetrieveInputModel repaymentInstanceReport(BQRepaymentRetrieveInputModelRepaymentInstanceReport repaymentInstanceReport) {
    this.repaymentInstanceReport = repaymentInstanceReport;
    return this;
  }

  /**
   * Get repaymentInstanceReport
   * @return repaymentInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentRetrieveInputModelRepaymentInstanceReport getRepaymentInstanceReport() {
    return repaymentInstanceReport;
  }

  public void setRepaymentInstanceReport(BQRepaymentRetrieveInputModelRepaymentInstanceReport repaymentInstanceReport) {
    this.repaymentInstanceReport = repaymentInstanceReport;
  }

  public BQRepaymentRetrieveInputModel repaymentInstanceAnalysis(BQRepaymentRetrieveInputModelRepaymentInstanceAnalysis repaymentInstanceAnalysis) {
    this.repaymentInstanceAnalysis = repaymentInstanceAnalysis;
    return this;
  }

  /**
   * Get repaymentInstanceAnalysis
   * @return repaymentInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentRetrieveInputModelRepaymentInstanceAnalysis getRepaymentInstanceAnalysis() {
    return repaymentInstanceAnalysis;
  }

  public void setRepaymentInstanceAnalysis(BQRepaymentRetrieveInputModelRepaymentInstanceAnalysis repaymentInstanceAnalysis) {
    this.repaymentInstanceAnalysis = repaymentInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRetrieveInputModel bqRepaymentRetrieveInputModel = (BQRepaymentRetrieveInputModel) o;
    return Objects.equals(this.repaymentRetrieveActionTaskRecord, bqRepaymentRetrieveInputModel.repaymentRetrieveActionTaskRecord) &&
        Objects.equals(this.repaymentRetrieveActionRequest, bqRepaymentRetrieveInputModel.repaymentRetrieveActionRequest) &&
        Objects.equals(this.repaymentInstanceReport, bqRepaymentRetrieveInputModel.repaymentInstanceReport) &&
        Objects.equals(this.repaymentInstanceAnalysis, bqRepaymentRetrieveInputModel.repaymentInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repaymentRetrieveActionTaskRecord, repaymentRetrieveActionRequest, repaymentInstanceReport, repaymentInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRetrieveInputModel {\n");
    
    sb.append("    repaymentRetrieveActionTaskRecord: ").append(toIndentedString(repaymentRetrieveActionTaskRecord)).append("\n");
    sb.append("    repaymentRetrieveActionRequest: ").append(toIndentedString(repaymentRetrieveActionRequest)).append("\n");
    sb.append("    repaymentInstanceReport: ").append(toIndentedString(repaymentInstanceReport)).append("\n");
    sb.append("    repaymentInstanceAnalysis: ").append(toIndentedString(repaymentInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

