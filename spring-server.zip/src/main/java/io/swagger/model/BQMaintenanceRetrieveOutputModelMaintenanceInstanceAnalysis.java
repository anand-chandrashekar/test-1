package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis   {
  @JsonProperty("maintenanceInstanceAnalysisRecord")
  private Object maintenanceInstanceAnalysisRecord = null;

  @JsonProperty("maintenanceInstanceAnalysisReportType")
  private String maintenanceInstanceAnalysisReportType = null;

  @JsonProperty("maintenanceInstanceAnalysisParameters")
  private String maintenanceInstanceAnalysisParameters = null;

  @JsonProperty("maintenanceInstanceAnalysisReport")
  private Object maintenanceInstanceAnalysisReport = null;

  public BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysisRecord(Object maintenanceInstanceAnalysisRecord) {
    this.maintenanceInstanceAnalysisRecord = maintenanceInstanceAnalysisRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected 
   * @return maintenanceInstanceAnalysisRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected ")


  public Object getMaintenanceInstanceAnalysisRecord() {
    return maintenanceInstanceAnalysisRecord;
  }

  public void setMaintenanceInstanceAnalysisRecord(Object maintenanceInstanceAnalysisRecord) {
    this.maintenanceInstanceAnalysisRecord = maintenanceInstanceAnalysisRecord;
  }

  public BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysisReportType(String maintenanceInstanceAnalysisReportType) {
    this.maintenanceInstanceAnalysisReportType = maintenanceInstanceAnalysisReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available 
   * @return maintenanceInstanceAnalysisReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available ")


  public String getMaintenanceInstanceAnalysisReportType() {
    return maintenanceInstanceAnalysisReportType;
  }

  public void setMaintenanceInstanceAnalysisReportType(String maintenanceInstanceAnalysisReportType) {
    this.maintenanceInstanceAnalysisReportType = maintenanceInstanceAnalysisReportType;
  }

  public BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysisParameters(String maintenanceInstanceAnalysisParameters) {
    this.maintenanceInstanceAnalysisParameters = maintenanceInstanceAnalysisParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) 
   * @return maintenanceInstanceAnalysisParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) ")


  public String getMaintenanceInstanceAnalysisParameters() {
    return maintenanceInstanceAnalysisParameters;
  }

  public void setMaintenanceInstanceAnalysisParameters(String maintenanceInstanceAnalysisParameters) {
    this.maintenanceInstanceAnalysisParameters = maintenanceInstanceAnalysisParameters;
  }

  public BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysisReport(Object maintenanceInstanceAnalysisReport) {
    this.maintenanceInstanceAnalysisReport = maintenanceInstanceAnalysisReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate 
   * @return maintenanceInstanceAnalysisReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate ")


  public Object getMaintenanceInstanceAnalysisReport() {
    return maintenanceInstanceAnalysisReport;
  }

  public void setMaintenanceInstanceAnalysisReport(Object maintenanceInstanceAnalysisReport) {
    this.maintenanceInstanceAnalysisReport = maintenanceInstanceAnalysisReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis bqMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis = (BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis) o;
    return Objects.equals(this.maintenanceInstanceAnalysisRecord, bqMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis.maintenanceInstanceAnalysisRecord) &&
        Objects.equals(this.maintenanceInstanceAnalysisReportType, bqMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis.maintenanceInstanceAnalysisReportType) &&
        Objects.equals(this.maintenanceInstanceAnalysisParameters, bqMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis.maintenanceInstanceAnalysisParameters) &&
        Objects.equals(this.maintenanceInstanceAnalysisReport, bqMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis.maintenanceInstanceAnalysisReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(maintenanceInstanceAnalysisRecord, maintenanceInstanceAnalysisReportType, maintenanceInstanceAnalysisParameters, maintenanceInstanceAnalysisReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis {\n");
    
    sb.append("    maintenanceInstanceAnalysisRecord: ").append(toIndentedString(maintenanceInstanceAnalysisRecord)).append("\n");
    sb.append("    maintenanceInstanceAnalysisReportType: ").append(toIndentedString(maintenanceInstanceAnalysisReportType)).append("\n");
    sb.append("    maintenanceInstanceAnalysisParameters: ").append(toIndentedString(maintenanceInstanceAnalysisParameters)).append("\n");
    sb.append("    maintenanceInstanceAnalysisReport: ").append(toIndentedString(maintenanceInstanceAnalysisReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

