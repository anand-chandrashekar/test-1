package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRequestOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRequestOutputModel   {
  @JsonProperty("repaymentRequestActionTaskReference")
  private String repaymentRequestActionTaskReference = null;

  @JsonProperty("repaymentRequestActionTaskRecord")
  private Object repaymentRequestActionTaskRecord = null;

  @JsonProperty("repaymentRequestRecordReference")
  private String repaymentRequestRecordReference = null;

  @JsonProperty("requestResponseRecord")
  private Object requestResponseRecord = null;

  public BQRepaymentRequestOutputModel repaymentRequestActionTaskReference(String repaymentRequestActionTaskReference) {
    this.repaymentRequestActionTaskReference = repaymentRequestActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Repayment instance request service call 
   * @return repaymentRequestActionTaskReference
  **/
  @ApiModelProperty(example = "RRATR712892", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Repayment instance request service call ")


  public String getRepaymentRequestActionTaskReference() {
    return repaymentRequestActionTaskReference;
  }

  public void setRepaymentRequestActionTaskReference(String repaymentRequestActionTaskReference) {
    this.repaymentRequestActionTaskReference = repaymentRequestActionTaskReference;
  }

  public BQRepaymentRequestOutputModel repaymentRequestActionTaskRecord(Object repaymentRequestActionTaskRecord) {
    this.repaymentRequestActionTaskRecord = repaymentRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return repaymentRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getRepaymentRequestActionTaskRecord() {
    return repaymentRequestActionTaskRecord;
  }

  public void setRepaymentRequestActionTaskRecord(Object repaymentRequestActionTaskRecord) {
    this.repaymentRequestActionTaskRecord = repaymentRequestActionTaskRecord;
  }

  public BQRepaymentRequestOutputModel repaymentRequestRecordReference(String repaymentRequestRecordReference) {
    this.repaymentRequestRecordReference = repaymentRequestRecordReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment service request record 
   * @return repaymentRequestRecordReference
  **/
  @ApiModelProperty(example = "RRRR731602", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment service request record ")


  public String getRepaymentRequestRecordReference() {
    return repaymentRequestRecordReference;
  }

  public void setRepaymentRequestRecordReference(String repaymentRequestRecordReference) {
    this.repaymentRequestRecordReference = repaymentRequestRecordReference;
  }

  public BQRepaymentRequestOutputModel requestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response 
   * @return requestResponseRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response ")


  public Object getRequestResponseRecord() {
    return requestResponseRecord;
  }

  public void setRequestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRequestOutputModel bqRepaymentRequestOutputModel = (BQRepaymentRequestOutputModel) o;
    return Objects.equals(this.repaymentRequestActionTaskReference, bqRepaymentRequestOutputModel.repaymentRequestActionTaskReference) &&
        Objects.equals(this.repaymentRequestActionTaskRecord, bqRepaymentRequestOutputModel.repaymentRequestActionTaskRecord) &&
        Objects.equals(this.repaymentRequestRecordReference, bqRepaymentRequestOutputModel.repaymentRequestRecordReference) &&
        Objects.equals(this.requestResponseRecord, bqRepaymentRequestOutputModel.requestResponseRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repaymentRequestActionTaskReference, repaymentRequestActionTaskRecord, repaymentRequestRecordReference, requestResponseRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRequestOutputModel {\n");
    
    sb.append("    repaymentRequestActionTaskReference: ").append(toIndentedString(repaymentRequestActionTaskReference)).append("\n");
    sb.append("    repaymentRequestActionTaskRecord: ").append(toIndentedString(repaymentRequestActionTaskRecord)).append("\n");
    sb.append("    repaymentRequestRecordReference: ").append(toIndentedString(repaymentRequestRecordReference)).append("\n");
    sb.append("    requestResponseRecord: ").append(toIndentedString(requestResponseRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

