package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementInitiateOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementInitiateOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInitiateActionReference")
  private String consumerLoanFulfillmentArrangementInitiateActionReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInitiateActionRecord")
  private Object consumerLoanFulfillmentArrangementInitiateActionRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceStatus")
  private String consumerLoanFulfillmentArrangementInstanceStatus = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private CRConsumerLoanFulfillmentArrangementInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  public CRConsumerLoanFulfillmentArrangementInitiateOutputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR701727", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public CRConsumerLoanFulfillmentArrangementInitiateOutputModel consumerLoanFulfillmentArrangementInitiateActionReference(String consumerLoanFulfillmentArrangementInitiateActionReference) {
    this.consumerLoanFulfillmentArrangementInitiateActionReference = consumerLoanFulfillmentArrangementInitiateActionReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an Initiate service call 
   * @return consumerLoanFulfillmentArrangementInitiateActionReference
  **/
  @ApiModelProperty(example = "CLFAIAR739165", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an Initiate service call ")


  public String getConsumerLoanFulfillmentArrangementInitiateActionReference() {
    return consumerLoanFulfillmentArrangementInitiateActionReference;
  }

  public void setConsumerLoanFulfillmentArrangementInitiateActionReference(String consumerLoanFulfillmentArrangementInitiateActionReference) {
    this.consumerLoanFulfillmentArrangementInitiateActionReference = consumerLoanFulfillmentArrangementInitiateActionReference;
  }

  public CRConsumerLoanFulfillmentArrangementInitiateOutputModel consumerLoanFulfillmentArrangementInitiateActionRecord(Object consumerLoanFulfillmentArrangementInitiateActionRecord) {
    this.consumerLoanFulfillmentArrangementInitiateActionRecord = consumerLoanFulfillmentArrangementInitiateActionRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The Initiate service call input and output record 
   * @return consumerLoanFulfillmentArrangementInitiateActionRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The Initiate service call input and output record ")


  public Object getConsumerLoanFulfillmentArrangementInitiateActionRecord() {
    return consumerLoanFulfillmentArrangementInitiateActionRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInitiateActionRecord(Object consumerLoanFulfillmentArrangementInitiateActionRecord) {
    this.consumerLoanFulfillmentArrangementInitiateActionRecord = consumerLoanFulfillmentArrangementInitiateActionRecord;
  }

  public CRConsumerLoanFulfillmentArrangementInitiateOutputModel consumerLoanFulfillmentArrangementInstanceStatus(String consumerLoanFulfillmentArrangementInstanceStatus) {
    this.consumerLoanFulfillmentArrangementInstanceStatus = consumerLoanFulfillmentArrangementInstanceStatus;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The status of the Consumer Loan Fulfillment Arrangement instance (e.g. initialised, pending, active) 
   * @return consumerLoanFulfillmentArrangementInstanceStatus
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The status of the Consumer Loan Fulfillment Arrangement instance (e.g. initialised, pending, active) ")


  public String getConsumerLoanFulfillmentArrangementInstanceStatus() {
    return consumerLoanFulfillmentArrangementInstanceStatus;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceStatus(String consumerLoanFulfillmentArrangementInstanceStatus) {
    this.consumerLoanFulfillmentArrangementInstanceStatus = consumerLoanFulfillmentArrangementInstanceStatus;
  }

  public CRConsumerLoanFulfillmentArrangementInitiateOutputModel consumerLoanFulfillmentArrangementInstanceRecord(CRConsumerLoanFulfillmentArrangementInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(CRConsumerLoanFulfillmentArrangementInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementInitiateOutputModel crConsumerLoanFulfillmentArrangementInitiateOutputModel = (CRConsumerLoanFulfillmentArrangementInitiateOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, crConsumerLoanFulfillmentArrangementInitiateOutputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInitiateActionReference, crConsumerLoanFulfillmentArrangementInitiateOutputModel.consumerLoanFulfillmentArrangementInitiateActionReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInitiateActionRecord, crConsumerLoanFulfillmentArrangementInitiateOutputModel.consumerLoanFulfillmentArrangementInitiateActionRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceStatus, crConsumerLoanFulfillmentArrangementInitiateOutputModel.consumerLoanFulfillmentArrangementInstanceStatus) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, crConsumerLoanFulfillmentArrangementInitiateOutputModel.consumerLoanFulfillmentArrangementInstanceRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, consumerLoanFulfillmentArrangementInitiateActionReference, consumerLoanFulfillmentArrangementInitiateActionRecord, consumerLoanFulfillmentArrangementInstanceStatus, consumerLoanFulfillmentArrangementInstanceRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementInitiateOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInitiateActionReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInitiateActionReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInitiateActionRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInitiateActionRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceStatus: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceStatus)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

