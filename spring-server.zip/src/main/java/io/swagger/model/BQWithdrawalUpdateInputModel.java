package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQWithdrawalUpdateInputModelWithdrawalInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalUpdateInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalUpdateInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("withdrawalInstanceReference")
  private String withdrawalInstanceReference = null;

  @JsonProperty("withdrawalInstanceRecord")
  private BQWithdrawalUpdateInputModelWithdrawalInstanceRecord withdrawalInstanceRecord = null;

  @JsonProperty("withdrawalUpdateActionTaskRecord")
  private Object withdrawalUpdateActionTaskRecord = null;

  @JsonProperty("withdrawalUpdateActionRequest")
  private String withdrawalUpdateActionRequest = null;

  public BQWithdrawalUpdateInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR741304", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQWithdrawalUpdateInputModel withdrawalInstanceReference(String withdrawalInstanceReference) {
    this.withdrawalInstanceReference = withdrawalInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal instance 
   * @return withdrawalInstanceReference
  **/
  @ApiModelProperty(example = "WIR720191", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal instance ")


  public String getWithdrawalInstanceReference() {
    return withdrawalInstanceReference;
  }

  public void setWithdrawalInstanceReference(String withdrawalInstanceReference) {
    this.withdrawalInstanceReference = withdrawalInstanceReference;
  }

  public BQWithdrawalUpdateInputModel withdrawalInstanceRecord(BQWithdrawalUpdateInputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
    return this;
  }

  /**
   * Get withdrawalInstanceRecord
   * @return withdrawalInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQWithdrawalUpdateInputModelWithdrawalInstanceRecord getWithdrawalInstanceRecord() {
    return withdrawalInstanceRecord;
  }

  public void setWithdrawalInstanceRecord(BQWithdrawalUpdateInputModelWithdrawalInstanceRecord withdrawalInstanceRecord) {
    this.withdrawalInstanceRecord = withdrawalInstanceRecord;
  }

  public BQWithdrawalUpdateInputModel withdrawalUpdateActionTaskRecord(Object withdrawalUpdateActionTaskRecord) {
    this.withdrawalUpdateActionTaskRecord = withdrawalUpdateActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record 
   * @return withdrawalUpdateActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record ")


  public Object getWithdrawalUpdateActionTaskRecord() {
    return withdrawalUpdateActionTaskRecord;
  }

  public void setWithdrawalUpdateActionTaskRecord(Object withdrawalUpdateActionTaskRecord) {
    this.withdrawalUpdateActionTaskRecord = withdrawalUpdateActionTaskRecord;
  }

  public BQWithdrawalUpdateInputModel withdrawalUpdateActionRequest(String withdrawalUpdateActionRequest) {
    this.withdrawalUpdateActionRequest = withdrawalUpdateActionRequest;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the update action service request 
   * @return withdrawalUpdateActionRequest
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the update action service request ")


  public String getWithdrawalUpdateActionRequest() {
    return withdrawalUpdateActionRequest;
  }

  public void setWithdrawalUpdateActionRequest(String withdrawalUpdateActionRequest) {
    this.withdrawalUpdateActionRequest = withdrawalUpdateActionRequest;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalUpdateInputModel bqWithdrawalUpdateInputModel = (BQWithdrawalUpdateInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqWithdrawalUpdateInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.withdrawalInstanceReference, bqWithdrawalUpdateInputModel.withdrawalInstanceReference) &&
        Objects.equals(this.withdrawalInstanceRecord, bqWithdrawalUpdateInputModel.withdrawalInstanceRecord) &&
        Objects.equals(this.withdrawalUpdateActionTaskRecord, bqWithdrawalUpdateInputModel.withdrawalUpdateActionTaskRecord) &&
        Objects.equals(this.withdrawalUpdateActionRequest, bqWithdrawalUpdateInputModel.withdrawalUpdateActionRequest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, withdrawalInstanceReference, withdrawalInstanceRecord, withdrawalUpdateActionTaskRecord, withdrawalUpdateActionRequest);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalUpdateInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    withdrawalInstanceReference: ").append(toIndentedString(withdrawalInstanceReference)).append("\n");
    sb.append("    withdrawalInstanceRecord: ").append(toIndentedString(withdrawalInstanceRecord)).append("\n");
    sb.append("    withdrawalUpdateActionTaskRecord: ").append(toIndentedString(withdrawalUpdateActionTaskRecord)).append("\n");
    sb.append("    withdrawalUpdateActionRequest: ").append(toIndentedString(withdrawalUpdateActionRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

