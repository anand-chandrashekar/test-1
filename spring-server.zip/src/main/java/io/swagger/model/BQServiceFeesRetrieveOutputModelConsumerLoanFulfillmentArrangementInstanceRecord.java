package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord   {
  @JsonProperty("productInstanceReference")
  private String productInstanceReference = null;

  @JsonProperty("consumerLoanNumber")
  private String consumerLoanNumber = null;

  @JsonProperty("customerReference")
  private String customerReference = null;

  @JsonProperty("loanAccessTerms")
  private String loanAccessTerms = null;

  @JsonProperty("entitlementOptionDefinition")
  private String entitlementOptionDefinition = null;

  @JsonProperty("entitlementOptionSetting")
  private String entitlementOptionSetting = null;

  @JsonProperty("restrictionOptionDefinition")
  private String restrictionOptionDefinition = null;

  @JsonProperty("restrictionOptionSetting")
  private String restrictionOptionSetting = null;

  @JsonProperty("associations")
  private BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations associations = null;

  @JsonProperty("customerCommentary")
  private String customerCommentary = null;

  @JsonProperty("loanOutstandingBalance")
  private String loanOutstandingBalance = null;

  @JsonProperty("dateType")
  private CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType = null;

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord productInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance 
   * @return productInstanceReference
  **/
  @ApiModelProperty(example = "743618", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance ")


  public String getProductInstanceReference() {
    return productInstanceReference;
  }

  public void setProductInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format 
   * @return consumerLoanNumber
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format ")


  public String getConsumerLoanNumber() {
    return consumerLoanNumber;
  }

  public void setConsumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerReference(String customerReference) {
    this.customerReference = customerReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner 
   * @return customerReference
  **/
  @ApiModelProperty(example = "738140", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner ")


  public String getCustomerReference() {
    return customerReference;
  }

  public void setCustomerReference(String customerReference) {
    this.customerReference = customerReference;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanAccessTerms(String loanAccessTerms) {
    this.loanAccessTerms = loanAccessTerms;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.Limit `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_Fg4nt8TGEeChad0JzLk7QA_742037711  bian-reference: Loan(as Debt).PrePaymentSpeed  general-info: Access terms that apply (e.g. allowed payments/withdrawals) 
   * @return loanAccessTerms
  **/
  @ApiModelProperty(value = "`status: Provisionally Registered`  bian-reference: Loan.Limit `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_Fg4nt8TGEeChad0JzLk7QA_742037711  bian-reference: Loan(as Debt).PrePaymentSpeed  general-info: Access terms that apply (e.g. allowed payments/withdrawals) ")


  public String getLoanAccessTerms() {
    return loanAccessTerms;
  }

  public void setLoanAccessTerms(String loanAccessTerms) {
    this.loanAccessTerms = loanAccessTerms;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord entitlementOptionDefinition(String entitlementOptionDefinition) {
    this.entitlementOptionDefinition = entitlementOptionDefinition;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable entitlement option 
   * @return entitlementOptionDefinition
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable entitlement option ")


  public String getEntitlementOptionDefinition() {
    return entitlementOptionDefinition;
  }

  public void setEntitlementOptionDefinition(String entitlementOptionDefinition) {
    this.entitlementOptionDefinition = entitlementOptionDefinition;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord entitlementOptionSetting(String entitlementOptionSetting) {
    this.entitlementOptionSetting = entitlementOptionSetting;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the entitlement option 
   * @return entitlementOptionSetting
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the entitlement option ")


  public String getEntitlementOptionSetting() {
    return entitlementOptionSetting;
  }

  public void setEntitlementOptionSetting(String entitlementOptionSetting) {
    this.entitlementOptionSetting = entitlementOptionSetting;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord restrictionOptionDefinition(String restrictionOptionDefinition) {
    this.restrictionOptionDefinition = restrictionOptionDefinition;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable restriction option 
   * @return restrictionOptionDefinition
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable restriction option ")


  public String getRestrictionOptionDefinition() {
    return restrictionOptionDefinition;
  }

  public void setRestrictionOptionDefinition(String restrictionOptionDefinition) {
    this.restrictionOptionDefinition = restrictionOptionDefinition;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord restrictionOptionSetting(String restrictionOptionSetting) {
    this.restrictionOptionSetting = restrictionOptionSetting;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the restriction option 
   * @return restrictionOptionSetting
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the restriction option ")


  public String getRestrictionOptionSetting() {
    return restrictionOptionSetting;
  }

  public void setRestrictionOptionSetting(String restrictionOptionSetting) {
    this.restrictionOptionSetting = restrictionOptionSetting;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord associations(BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations associations) {
    this.associations = associations;
    return this;
  }

  /**
   * Get associations
   * @return associations
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations getAssociations() {
    return associations;
  }

  public void setAssociations(BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations associations) {
    this.associations = associations;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerCommentary(String customerCommentary) {
    this.customerCommentary = customerCommentary;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: A record of customer correspondence/feedback 
   * @return customerCommentary
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: A record of customer correspondence/feedback ")


  public String getCustomerCommentary() {
    return customerCommentary;
  }

  public void setCustomerCommentary(String customerCommentary) {
    this.customerCommentary = customerCommentary;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance 
   * @return loanOutstandingBalance
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance ")


  public String getLoanOutstandingBalance() {
    return loanOutstandingBalance;
  }

  public void setLoanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
  }

  public BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord dateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
    return this;
  }

  /**
   * Get dateType
   * @return dateType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType getDateType() {
    return dateType;
  }

  public void setDateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord = (BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord) o;
    return Objects.equals(this.productInstanceReference, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.productInstanceReference) &&
        Objects.equals(this.consumerLoanNumber, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.consumerLoanNumber) &&
        Objects.equals(this.customerReference, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerReference) &&
        Objects.equals(this.loanAccessTerms, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanAccessTerms) &&
        Objects.equals(this.entitlementOptionDefinition, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.entitlementOptionDefinition) &&
        Objects.equals(this.entitlementOptionSetting, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.entitlementOptionSetting) &&
        Objects.equals(this.restrictionOptionDefinition, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.restrictionOptionDefinition) &&
        Objects.equals(this.restrictionOptionSetting, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.restrictionOptionSetting) &&
        Objects.equals(this.associations, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.associations) &&
        Objects.equals(this.customerCommentary, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerCommentary) &&
        Objects.equals(this.loanOutstandingBalance, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOutstandingBalance) &&
        Objects.equals(this.dateType, bqServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.dateType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productInstanceReference, consumerLoanNumber, customerReference, loanAccessTerms, entitlementOptionDefinition, entitlementOptionSetting, restrictionOptionDefinition, restrictionOptionSetting, associations, customerCommentary, loanOutstandingBalance, dateType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQServiceFeesRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord {\n");
    
    sb.append("    productInstanceReference: ").append(toIndentedString(productInstanceReference)).append("\n");
    sb.append("    consumerLoanNumber: ").append(toIndentedString(consumerLoanNumber)).append("\n");
    sb.append("    customerReference: ").append(toIndentedString(customerReference)).append("\n");
    sb.append("    loanAccessTerms: ").append(toIndentedString(loanAccessTerms)).append("\n");
    sb.append("    entitlementOptionDefinition: ").append(toIndentedString(entitlementOptionDefinition)).append("\n");
    sb.append("    entitlementOptionSetting: ").append(toIndentedString(entitlementOptionSetting)).append("\n");
    sb.append("    restrictionOptionDefinition: ").append(toIndentedString(restrictionOptionDefinition)).append("\n");
    sb.append("    restrictionOptionSetting: ").append(toIndentedString(restrictionOptionSetting)).append("\n");
    sb.append("    associations: ").append(toIndentedString(associations)).append("\n");
    sb.append("    customerCommentary: ").append(toIndentedString(customerCommentary)).append("\n");
    sb.append("    loanOutstandingBalance: ").append(toIndentedString(loanOutstandingBalance)).append("\n");
    sb.append("    dateType: ").append(toIndentedString(dateType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

