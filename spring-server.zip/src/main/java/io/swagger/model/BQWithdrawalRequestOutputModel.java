package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalRequestOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalRequestOutputModel   {
  @JsonProperty("withdrawalRequestActionTaskReference")
  private String withdrawalRequestActionTaskReference = null;

  @JsonProperty("withdrawalRequestActionTaskRecord")
  private Object withdrawalRequestActionTaskRecord = null;

  @JsonProperty("withdrawalRequestRecordReference")
  private String withdrawalRequestRecordReference = null;

  @JsonProperty("requestResponseRecord")
  private Object requestResponseRecord = null;

  public BQWithdrawalRequestOutputModel withdrawalRequestActionTaskReference(String withdrawalRequestActionTaskReference) {
    this.withdrawalRequestActionTaskReference = withdrawalRequestActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Withdrawal instance request service call 
   * @return withdrawalRequestActionTaskReference
  **/
  @ApiModelProperty(example = "WRATR721337", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Withdrawal instance request service call ")


  public String getWithdrawalRequestActionTaskReference() {
    return withdrawalRequestActionTaskReference;
  }

  public void setWithdrawalRequestActionTaskReference(String withdrawalRequestActionTaskReference) {
    this.withdrawalRequestActionTaskReference = withdrawalRequestActionTaskReference;
  }

  public BQWithdrawalRequestOutputModel withdrawalRequestActionTaskRecord(Object withdrawalRequestActionTaskRecord) {
    this.withdrawalRequestActionTaskRecord = withdrawalRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return withdrawalRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getWithdrawalRequestActionTaskRecord() {
    return withdrawalRequestActionTaskRecord;
  }

  public void setWithdrawalRequestActionTaskRecord(Object withdrawalRequestActionTaskRecord) {
    this.withdrawalRequestActionTaskRecord = withdrawalRequestActionTaskRecord;
  }

  public BQWithdrawalRequestOutputModel withdrawalRequestRecordReference(String withdrawalRequestRecordReference) {
    this.withdrawalRequestRecordReference = withdrawalRequestRecordReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal service request record 
   * @return withdrawalRequestRecordReference
  **/
  @ApiModelProperty(example = "WRRR774651", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Withdrawal service request record ")


  public String getWithdrawalRequestRecordReference() {
    return withdrawalRequestRecordReference;
  }

  public void setWithdrawalRequestRecordReference(String withdrawalRequestRecordReference) {
    this.withdrawalRequestRecordReference = withdrawalRequestRecordReference;
  }

  public BQWithdrawalRequestOutputModel requestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response 
   * @return requestResponseRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the request action service response ")


  public Object getRequestResponseRecord() {
    return requestResponseRecord;
  }

  public void setRequestResponseRecord(Object requestResponseRecord) {
    this.requestResponseRecord = requestResponseRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalRequestOutputModel bqWithdrawalRequestOutputModel = (BQWithdrawalRequestOutputModel) o;
    return Objects.equals(this.withdrawalRequestActionTaskReference, bqWithdrawalRequestOutputModel.withdrawalRequestActionTaskReference) &&
        Objects.equals(this.withdrawalRequestActionTaskRecord, bqWithdrawalRequestOutputModel.withdrawalRequestActionTaskRecord) &&
        Objects.equals(this.withdrawalRequestRecordReference, bqWithdrawalRequestOutputModel.withdrawalRequestRecordReference) &&
        Objects.equals(this.requestResponseRecord, bqWithdrawalRequestOutputModel.requestResponseRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(withdrawalRequestActionTaskReference, withdrawalRequestActionTaskRecord, withdrawalRequestRecordReference, requestResponseRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalRequestOutputModel {\n");
    
    sb.append("    withdrawalRequestActionTaskReference: ").append(toIndentedString(withdrawalRequestActionTaskReference)).append("\n");
    sb.append("    withdrawalRequestActionTaskRecord: ").append(toIndentedString(withdrawalRequestActionTaskRecord)).append("\n");
    sb.append("    withdrawalRequestRecordReference: ").append(toIndentedString(withdrawalRequestRecordReference)).append("\n");
    sb.append("    requestResponseRecord: ").append(toIndentedString(requestResponseRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

