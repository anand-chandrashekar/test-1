package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRetrieveInputModelMaintenanceInstanceReport
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRetrieveInputModelMaintenanceInstanceReport   {
  @JsonProperty("maintenanceInstanceReportReference")
  private String maintenanceInstanceReportReference = null;

  public BQMaintenanceRetrieveInputModelMaintenanceInstanceReport maintenanceInstanceReportReference(String maintenanceInstanceReportReference) {
    this.maintenanceInstanceReportReference = maintenanceInstanceReportReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the control record instance report 
   * @return maintenanceInstanceReportReference
  **/
  @ApiModelProperty(example = "708236", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the control record instance report ")


  public String getMaintenanceInstanceReportReference() {
    return maintenanceInstanceReportReference;
  }

  public void setMaintenanceInstanceReportReference(String maintenanceInstanceReportReference) {
    this.maintenanceInstanceReportReference = maintenanceInstanceReportReference;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRetrieveInputModelMaintenanceInstanceReport bqMaintenanceRetrieveInputModelMaintenanceInstanceReport = (BQMaintenanceRetrieveInputModelMaintenanceInstanceReport) o;
    return Objects.equals(this.maintenanceInstanceReportReference, bqMaintenanceRetrieveInputModelMaintenanceInstanceReport.maintenanceInstanceReportReference);
  }

  @Override
  public int hashCode() {
    return Objects.hash(maintenanceInstanceReportReference);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRetrieveInputModelMaintenanceInstanceReport {\n");
    
    sb.append("    maintenanceInstanceReportReference: ").append(toIndentedString(maintenanceInstanceReportReference)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

