package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRetrieveOutputModelRepaymentInstanceReport
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRetrieveOutputModelRepaymentInstanceReport   {
  @JsonProperty("repaymentInstanceReportRecord")
  private Object repaymentInstanceReportRecord = null;

  @JsonProperty("repaymentInstanceReportType")
  private String repaymentInstanceReportType = null;

  @JsonProperty("repaymentInstanceReportParameters")
  private String repaymentInstanceReportParameters = null;

  @JsonProperty("repaymentInstanceReport")
  private Object repaymentInstanceReport = null;

  public BQRepaymentRetrieveOutputModelRepaymentInstanceReport repaymentInstanceReportRecord(Object repaymentInstanceReportRecord) {
    this.repaymentInstanceReportRecord = repaymentInstanceReportRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected 
   * @return repaymentInstanceReportRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected ")


  public Object getRepaymentInstanceReportRecord() {
    return repaymentInstanceReportRecord;
  }

  public void setRepaymentInstanceReportRecord(Object repaymentInstanceReportRecord) {
    this.repaymentInstanceReportRecord = repaymentInstanceReportRecord;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceReport repaymentInstanceReportType(String repaymentInstanceReportType) {
    this.repaymentInstanceReportType = repaymentInstanceReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available 
   * @return repaymentInstanceReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available ")


  public String getRepaymentInstanceReportType() {
    return repaymentInstanceReportType;
  }

  public void setRepaymentInstanceReportType(String repaymentInstanceReportType) {
    this.repaymentInstanceReportType = repaymentInstanceReportType;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceReport repaymentInstanceReportParameters(String repaymentInstanceReportParameters) {
    this.repaymentInstanceReportParameters = repaymentInstanceReportParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) 
   * @return repaymentInstanceReportParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) ")


  public String getRepaymentInstanceReportParameters() {
    return repaymentInstanceReportParameters;
  }

  public void setRepaymentInstanceReportParameters(String repaymentInstanceReportParameters) {
    this.repaymentInstanceReportParameters = repaymentInstanceReportParameters;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceReport repaymentInstanceReport(Object repaymentInstanceReport) {
    this.repaymentInstanceReport = repaymentInstanceReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate 
   * @return repaymentInstanceReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate ")


  public Object getRepaymentInstanceReport() {
    return repaymentInstanceReport;
  }

  public void setRepaymentInstanceReport(Object repaymentInstanceReport) {
    this.repaymentInstanceReport = repaymentInstanceReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRetrieveOutputModelRepaymentInstanceReport bqRepaymentRetrieveOutputModelRepaymentInstanceReport = (BQRepaymentRetrieveOutputModelRepaymentInstanceReport) o;
    return Objects.equals(this.repaymentInstanceReportRecord, bqRepaymentRetrieveOutputModelRepaymentInstanceReport.repaymentInstanceReportRecord) &&
        Objects.equals(this.repaymentInstanceReportType, bqRepaymentRetrieveOutputModelRepaymentInstanceReport.repaymentInstanceReportType) &&
        Objects.equals(this.repaymentInstanceReportParameters, bqRepaymentRetrieveOutputModelRepaymentInstanceReport.repaymentInstanceReportParameters) &&
        Objects.equals(this.repaymentInstanceReport, bqRepaymentRetrieveOutputModelRepaymentInstanceReport.repaymentInstanceReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repaymentInstanceReportRecord, repaymentInstanceReportType, repaymentInstanceReportParameters, repaymentInstanceReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRetrieveOutputModelRepaymentInstanceReport {\n");
    
    sb.append("    repaymentInstanceReportRecord: ").append(toIndentedString(repaymentInstanceReportRecord)).append("\n");
    sb.append("    repaymentInstanceReportType: ").append(toIndentedString(repaymentInstanceReportType)).append("\n");
    sb.append("    repaymentInstanceReportParameters: ").append(toIndentedString(repaymentInstanceReportParameters)).append("\n");
    sb.append("    repaymentInstanceReport: ").append(toIndentedString(repaymentInstanceReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

