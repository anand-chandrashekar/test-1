package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQDisbursementRetrieveOutputModelDisbursementInstanceReport
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQDisbursementRetrieveOutputModelDisbursementInstanceReport   {
  @JsonProperty("disbursementInstanceReportRecord")
  private Object disbursementInstanceReportRecord = null;

  @JsonProperty("disbursementInstanceReportType")
  private String disbursementInstanceReportType = null;

  @JsonProperty("disbursementInstanceReportParameters")
  private String disbursementInstanceReportParameters = null;

  @JsonProperty("disbursementInstanceReport")
  private Object disbursementInstanceReport = null;

  public BQDisbursementRetrieveOutputModelDisbursementInstanceReport disbursementInstanceReportRecord(Object disbursementInstanceReportRecord) {
    this.disbursementInstanceReportRecord = disbursementInstanceReportRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected 
   * @return disbursementInstanceReportRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The input information used to assemble the report that can be on-going, periodic and actual and projected ")


  public Object getDisbursementInstanceReportRecord() {
    return disbursementInstanceReportRecord;
  }

  public void setDisbursementInstanceReportRecord(Object disbursementInstanceReportRecord) {
    this.disbursementInstanceReportRecord = disbursementInstanceReportRecord;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceReport disbursementInstanceReportType(String disbursementInstanceReportType) {
    this.disbursementInstanceReportType = disbursementInstanceReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available 
   * @return disbursementInstanceReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available ")


  public String getDisbursementInstanceReportType() {
    return disbursementInstanceReportType;
  }

  public void setDisbursementInstanceReportType(String disbursementInstanceReportType) {
    this.disbursementInstanceReportType = disbursementInstanceReportType;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceReport disbursementInstanceReportParameters(String disbursementInstanceReportParameters) {
    this.disbursementInstanceReportParameters = disbursementInstanceReportParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) 
   * @return disbursementInstanceReportParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) ")


  public String getDisbursementInstanceReportParameters() {
    return disbursementInstanceReportParameters;
  }

  public void setDisbursementInstanceReportParameters(String disbursementInstanceReportParameters) {
    this.disbursementInstanceReportParameters = disbursementInstanceReportParameters;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceReport disbursementInstanceReport(Object disbursementInstanceReport) {
    this.disbursementInstanceReport = disbursementInstanceReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate 
   * @return disbursementInstanceReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external report in any suitable form including selection filters where appropriate ")


  public Object getDisbursementInstanceReport() {
    return disbursementInstanceReport;
  }

  public void setDisbursementInstanceReport(Object disbursementInstanceReport) {
    this.disbursementInstanceReport = disbursementInstanceReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQDisbursementRetrieveOutputModelDisbursementInstanceReport bqDisbursementRetrieveOutputModelDisbursementInstanceReport = (BQDisbursementRetrieveOutputModelDisbursementInstanceReport) o;
    return Objects.equals(this.disbursementInstanceReportRecord, bqDisbursementRetrieveOutputModelDisbursementInstanceReport.disbursementInstanceReportRecord) &&
        Objects.equals(this.disbursementInstanceReportType, bqDisbursementRetrieveOutputModelDisbursementInstanceReport.disbursementInstanceReportType) &&
        Objects.equals(this.disbursementInstanceReportParameters, bqDisbursementRetrieveOutputModelDisbursementInstanceReport.disbursementInstanceReportParameters) &&
        Objects.equals(this.disbursementInstanceReport, bqDisbursementRetrieveOutputModelDisbursementInstanceReport.disbursementInstanceReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(disbursementInstanceReportRecord, disbursementInstanceReportType, disbursementInstanceReportParameters, disbursementInstanceReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQDisbursementRetrieveOutputModelDisbursementInstanceReport {\n");
    
    sb.append("    disbursementInstanceReportRecord: ").append(toIndentedString(disbursementInstanceReportRecord)).append("\n");
    sb.append("    disbursementInstanceReportType: ").append(toIndentedString(disbursementInstanceReportType)).append("\n");
    sb.append("    disbursementInstanceReportParameters: ").append(toIndentedString(disbursementInstanceReportParameters)).append("\n");
    sb.append("    disbursementInstanceReport: ").append(toIndentedString(disbursementInstanceReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

