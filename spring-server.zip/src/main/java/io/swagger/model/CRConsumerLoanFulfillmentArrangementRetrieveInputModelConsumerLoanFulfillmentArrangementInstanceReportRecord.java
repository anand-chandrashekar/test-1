package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReportReference")
  private String consumerLoanFulfillmentArrangementInstanceReportReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReportType")
  private String consumerLoanFulfillmentArrangementInstanceReportType = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReportParameters")
  private String consumerLoanFulfillmentArrangementInstanceReportParameters = null;

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportReference(String consumerLoanFulfillmentArrangementInstanceReportReference) {
    this.consumerLoanFulfillmentArrangementInstanceReportReference = consumerLoanFulfillmentArrangementInstanceReportReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the control record instance report 
   * @return consumerLoanFulfillmentArrangementInstanceReportReference
  **/
  @ApiModelProperty(example = "776897", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the control record instance report ")


  public String getConsumerLoanFulfillmentArrangementInstanceReportReference() {
    return consumerLoanFulfillmentArrangementInstanceReportReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReportReference(String consumerLoanFulfillmentArrangementInstanceReportReference) {
    this.consumerLoanFulfillmentArrangementInstanceReportReference = consumerLoanFulfillmentArrangementInstanceReportReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportType(String consumerLoanFulfillmentArrangementInstanceReportType) {
    this.consumerLoanFulfillmentArrangementInstanceReportType = consumerLoanFulfillmentArrangementInstanceReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available 
   * @return consumerLoanFulfillmentArrangementInstanceReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external report available ")


  public String getConsumerLoanFulfillmentArrangementInstanceReportType() {
    return consumerLoanFulfillmentArrangementInstanceReportType;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReportType(String consumerLoanFulfillmentArrangementInstanceReportType) {
    this.consumerLoanFulfillmentArrangementInstanceReportType = consumerLoanFulfillmentArrangementInstanceReportType;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportParameters(String consumerLoanFulfillmentArrangementInstanceReportParameters) {
    this.consumerLoanFulfillmentArrangementInstanceReportParameters = consumerLoanFulfillmentArrangementInstanceReportParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) 
   * @return consumerLoanFulfillmentArrangementInstanceReportParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the report (e.g. period, content type) ")


  public String getConsumerLoanFulfillmentArrangementInstanceReportParameters() {
    return consumerLoanFulfillmentArrangementInstanceReportParameters;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReportParameters(String consumerLoanFulfillmentArrangementInstanceReportParameters) {
    this.consumerLoanFulfillmentArrangementInstanceReportParameters = consumerLoanFulfillmentArrangementInstanceReportParameters;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord = (CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReportReference, crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord.consumerLoanFulfillmentArrangementInstanceReportReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReportType, crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord.consumerLoanFulfillmentArrangementInstanceReportType) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReportParameters, crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord.consumerLoanFulfillmentArrangementInstanceReportParameters);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReportReference, consumerLoanFulfillmentArrangementInstanceReportType, consumerLoanFulfillmentArrangementInstanceReportParameters);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceReportRecord {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReportReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReportReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReportType: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReportType)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReportParameters: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReportParameters)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

