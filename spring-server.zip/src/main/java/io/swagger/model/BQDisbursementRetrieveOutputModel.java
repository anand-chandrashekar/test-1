package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis;
import io.swagger.model.BQDisbursementRetrieveOutputModelDisbursementInstanceRecord;
import io.swagger.model.BQDisbursementRetrieveOutputModelDisbursementInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQDisbursementRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQDisbursementRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("disbursementInstanceRecord")
  private BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementInstanceRecord = null;

  @JsonProperty("disbursementRetrieveActionTaskReference")
  private String disbursementRetrieveActionTaskReference = null;

  @JsonProperty("disbursementRetrieveActionTaskRecord")
  private Object disbursementRetrieveActionTaskRecord = null;

  @JsonProperty("disbursementRetrieveActionResponse")
  private String disbursementRetrieveActionResponse = null;

  @JsonProperty("disbursementInstanceReport")
  private BQDisbursementRetrieveOutputModelDisbursementInstanceReport disbursementInstanceReport = null;

  @JsonProperty("disbursementInstanceAnalysis")
  private BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis disbursementInstanceAnalysis = null;

  public BQDisbursementRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQDisbursementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQDisbursementRetrieveOutputModel disbursementInstanceRecord(BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementInstanceRecord) {
    this.disbursementInstanceRecord = disbursementInstanceRecord;
    return this;
  }

  /**
   * Get disbursementInstanceRecord
   * @return disbursementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQDisbursementRetrieveOutputModelDisbursementInstanceRecord getDisbursementInstanceRecord() {
    return disbursementInstanceRecord;
  }

  public void setDisbursementInstanceRecord(BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementInstanceRecord) {
    this.disbursementInstanceRecord = disbursementInstanceRecord;
  }

  public BQDisbursementRetrieveOutputModel disbursementRetrieveActionTaskReference(String disbursementRetrieveActionTaskReference) {
    this.disbursementRetrieveActionTaskReference = disbursementRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Disbursement instance retrieve service call 
   * @return disbursementRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "DRATR775814", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Disbursement instance retrieve service call ")


  public String getDisbursementRetrieveActionTaskReference() {
    return disbursementRetrieveActionTaskReference;
  }

  public void setDisbursementRetrieveActionTaskReference(String disbursementRetrieveActionTaskReference) {
    this.disbursementRetrieveActionTaskReference = disbursementRetrieveActionTaskReference;
  }

  public BQDisbursementRetrieveOutputModel disbursementRetrieveActionTaskRecord(Object disbursementRetrieveActionTaskRecord) {
    this.disbursementRetrieveActionTaskRecord = disbursementRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return disbursementRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getDisbursementRetrieveActionTaskRecord() {
    return disbursementRetrieveActionTaskRecord;
  }

  public void setDisbursementRetrieveActionTaskRecord(Object disbursementRetrieveActionTaskRecord) {
    this.disbursementRetrieveActionTaskRecord = disbursementRetrieveActionTaskRecord;
  }

  public BQDisbursementRetrieveOutputModel disbursementRetrieveActionResponse(String disbursementRetrieveActionResponse) {
    this.disbursementRetrieveActionResponse = disbursementRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return disbursementRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getDisbursementRetrieveActionResponse() {
    return disbursementRetrieveActionResponse;
  }

  public void setDisbursementRetrieveActionResponse(String disbursementRetrieveActionResponse) {
    this.disbursementRetrieveActionResponse = disbursementRetrieveActionResponse;
  }

  public BQDisbursementRetrieveOutputModel disbursementInstanceReport(BQDisbursementRetrieveOutputModelDisbursementInstanceReport disbursementInstanceReport) {
    this.disbursementInstanceReport = disbursementInstanceReport;
    return this;
  }

  /**
   * Get disbursementInstanceReport
   * @return disbursementInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQDisbursementRetrieveOutputModelDisbursementInstanceReport getDisbursementInstanceReport() {
    return disbursementInstanceReport;
  }

  public void setDisbursementInstanceReport(BQDisbursementRetrieveOutputModelDisbursementInstanceReport disbursementInstanceReport) {
    this.disbursementInstanceReport = disbursementInstanceReport;
  }

  public BQDisbursementRetrieveOutputModel disbursementInstanceAnalysis(BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis disbursementInstanceAnalysis) {
    this.disbursementInstanceAnalysis = disbursementInstanceAnalysis;
    return this;
  }

  /**
   * Get disbursementInstanceAnalysis
   * @return disbursementInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis getDisbursementInstanceAnalysis() {
    return disbursementInstanceAnalysis;
  }

  public void setDisbursementInstanceAnalysis(BQDisbursementRetrieveOutputModelDisbursementInstanceAnalysis disbursementInstanceAnalysis) {
    this.disbursementInstanceAnalysis = disbursementInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQDisbursementRetrieveOutputModel bqDisbursementRetrieveOutputModel = (BQDisbursementRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqDisbursementRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.disbursementInstanceRecord, bqDisbursementRetrieveOutputModel.disbursementInstanceRecord) &&
        Objects.equals(this.disbursementRetrieveActionTaskReference, bqDisbursementRetrieveOutputModel.disbursementRetrieveActionTaskReference) &&
        Objects.equals(this.disbursementRetrieveActionTaskRecord, bqDisbursementRetrieveOutputModel.disbursementRetrieveActionTaskRecord) &&
        Objects.equals(this.disbursementRetrieveActionResponse, bqDisbursementRetrieveOutputModel.disbursementRetrieveActionResponse) &&
        Objects.equals(this.disbursementInstanceReport, bqDisbursementRetrieveOutputModel.disbursementInstanceReport) &&
        Objects.equals(this.disbursementInstanceAnalysis, bqDisbursementRetrieveOutputModel.disbursementInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, disbursementInstanceRecord, disbursementRetrieveActionTaskReference, disbursementRetrieveActionTaskRecord, disbursementRetrieveActionResponse, disbursementInstanceReport, disbursementInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQDisbursementRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    disbursementInstanceRecord: ").append(toIndentedString(disbursementInstanceRecord)).append("\n");
    sb.append("    disbursementRetrieveActionTaskReference: ").append(toIndentedString(disbursementRetrieveActionTaskReference)).append("\n");
    sb.append("    disbursementRetrieveActionTaskRecord: ").append(toIndentedString(disbursementRetrieveActionTaskRecord)).append("\n");
    sb.append("    disbursementRetrieveActionResponse: ").append(toIndentedString(disbursementRetrieveActionResponse)).append("\n");
    sb.append("    disbursementInstanceReport: ").append(toIndentedString(disbursementInstanceReport)).append("\n");
    sb.append("    disbursementInstanceAnalysis: ").append(toIndentedString(disbursementInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

