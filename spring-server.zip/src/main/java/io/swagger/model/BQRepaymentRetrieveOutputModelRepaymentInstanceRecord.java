package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRetrieveOutputModelRepaymentInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRetrieveOutputModelRepaymentInstanceRecord   {
  @JsonProperty("repaymentTransactionType")
  private String repaymentTransactionType = null;

  @JsonProperty("repaymentTransactionPayerReference")
  private String repaymentTransactionPayerReference = null;

  @JsonProperty("repaymentTransactionPayerProductInstanceReference")
  private String repaymentTransactionPayerProductInstanceReference = null;

  @JsonProperty("repaymentTransactionPayerBankReference")
  private String repaymentTransactionPayerBankReference = null;

  @JsonProperty("repaymentTransactionAmount")
  private String repaymentTransactionAmount = null;

  @JsonProperty("repaymentTransactionCurrency")
  private String repaymentTransactionCurrency = null;

  @JsonProperty("repaymentTransactionValueDate")
  private String repaymentTransactionValueDate = null;

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentTransactionType(String repaymentTransactionType) {
    this.repaymentTransactionType = repaymentTransactionType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment (e.g. scheduled repayment, balloon/early termination) 
   * @return repaymentTransactionType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment (e.g. scheduled repayment, balloon/early termination) ")


  public String getRepaymentTransactionType() {
    return repaymentTransactionType;
  }

  public void setRepaymentTransactionType(String repaymentTransactionType) {
    this.repaymentTransactionType = repaymentTransactionType;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentTransactionPayerReference(String repaymentTransactionPayerReference) {
    this.repaymentTransactionPayerReference = repaymentTransactionPayerReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer 
   * @return repaymentTransactionPayerReference
  **/
  @ApiModelProperty(example = "703337", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer ")


  public String getRepaymentTransactionPayerReference() {
    return repaymentTransactionPayerReference;
  }

  public void setRepaymentTransactionPayerReference(String repaymentTransactionPayerReference) {
    this.repaymentTransactionPayerReference = repaymentTransactionPayerReference;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentTransactionPayerProductInstanceReference(String repaymentTransactionPayerProductInstanceReference) {
    this.repaymentTransactionPayerProductInstanceReference = repaymentTransactionPayerProductInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account where the payment is made from 
   * @return repaymentTransactionPayerProductInstanceReference
  **/
  @ApiModelProperty(example = "757064", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account where the payment is made from ")


  public String getRepaymentTransactionPayerProductInstanceReference() {
    return repaymentTransactionPayerProductInstanceReference;
  }

  public void setRepaymentTransactionPayerProductInstanceReference(String repaymentTransactionPayerProductInstanceReference) {
    this.repaymentTransactionPayerProductInstanceReference = repaymentTransactionPayerProductInstanceReference;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentTransactionPayerBankReference(String repaymentTransactionPayerBankReference) {
    this.repaymentTransactionPayerBankReference = repaymentTransactionPayerBankReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer's bank 
   * @return repaymentTransactionPayerBankReference
  **/
  @ApiModelProperty(example = "726848", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the payer's bank ")


  public String getRepaymentTransactionPayerBankReference() {
    return repaymentTransactionPayerBankReference;
  }

  public void setRepaymentTransactionPayerBankReference(String repaymentTransactionPayerBankReference) {
    this.repaymentTransactionPayerBankReference = repaymentTransactionPayerBankReference;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentTransactionAmount(String repaymentTransactionAmount) {
    this.repaymentTransactionAmount = repaymentTransactionAmount;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The amount of the repayment 
   * @return repaymentTransactionAmount
  **/
  @ApiModelProperty(example = "USD 250", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The amount of the repayment ")


  public String getRepaymentTransactionAmount() {
    return repaymentTransactionAmount;
  }

  public void setRepaymentTransactionAmount(String repaymentTransactionAmount) {
    this.repaymentTransactionAmount = repaymentTransactionAmount;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentTransactionCurrency(String repaymentTransactionCurrency) {
    this.repaymentTransactionCurrency = repaymentTransactionCurrency;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Currency  general-info: The currency used for the repayment 
   * @return repaymentTransactionCurrency
  **/
  @ApiModelProperty(example = "USD", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Currency  general-info: The currency used for the repayment ")


  public String getRepaymentTransactionCurrency() {
    return repaymentTransactionCurrency;
  }

  public void setRepaymentTransactionCurrency(String repaymentTransactionCurrency) {
    this.repaymentTransactionCurrency = repaymentTransactionCurrency;
  }

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentTransactionValueDate(String repaymentTransactionValueDate) {
    this.repaymentTransactionValueDate = repaymentTransactionValueDate;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The value date for the repayment transaction 
   * @return repaymentTransactionValueDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The value date for the repayment transaction ")


  public String getRepaymentTransactionValueDate() {
    return repaymentTransactionValueDate;
  }

  public void setRepaymentTransactionValueDate(String repaymentTransactionValueDate) {
    this.repaymentTransactionValueDate = repaymentTransactionValueDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRetrieveOutputModelRepaymentInstanceRecord bqRepaymentRetrieveOutputModelRepaymentInstanceRecord = (BQRepaymentRetrieveOutputModelRepaymentInstanceRecord) o;
    return Objects.equals(this.repaymentTransactionType, bqRepaymentRetrieveOutputModelRepaymentInstanceRecord.repaymentTransactionType) &&
        Objects.equals(this.repaymentTransactionPayerReference, bqRepaymentRetrieveOutputModelRepaymentInstanceRecord.repaymentTransactionPayerReference) &&
        Objects.equals(this.repaymentTransactionPayerProductInstanceReference, bqRepaymentRetrieveOutputModelRepaymentInstanceRecord.repaymentTransactionPayerProductInstanceReference) &&
        Objects.equals(this.repaymentTransactionPayerBankReference, bqRepaymentRetrieveOutputModelRepaymentInstanceRecord.repaymentTransactionPayerBankReference) &&
        Objects.equals(this.repaymentTransactionAmount, bqRepaymentRetrieveOutputModelRepaymentInstanceRecord.repaymentTransactionAmount) &&
        Objects.equals(this.repaymentTransactionCurrency, bqRepaymentRetrieveOutputModelRepaymentInstanceRecord.repaymentTransactionCurrency) &&
        Objects.equals(this.repaymentTransactionValueDate, bqRepaymentRetrieveOutputModelRepaymentInstanceRecord.repaymentTransactionValueDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repaymentTransactionType, repaymentTransactionPayerReference, repaymentTransactionPayerProductInstanceReference, repaymentTransactionPayerBankReference, repaymentTransactionAmount, repaymentTransactionCurrency, repaymentTransactionValueDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRetrieveOutputModelRepaymentInstanceRecord {\n");
    
    sb.append("    repaymentTransactionType: ").append(toIndentedString(repaymentTransactionType)).append("\n");
    sb.append("    repaymentTransactionPayerReference: ").append(toIndentedString(repaymentTransactionPayerReference)).append("\n");
    sb.append("    repaymentTransactionPayerProductInstanceReference: ").append(toIndentedString(repaymentTransactionPayerProductInstanceReference)).append("\n");
    sb.append("    repaymentTransactionPayerBankReference: ").append(toIndentedString(repaymentTransactionPayerBankReference)).append("\n");
    sb.append("    repaymentTransactionAmount: ").append(toIndentedString(repaymentTransactionAmount)).append("\n");
    sb.append("    repaymentTransactionCurrency: ").append(toIndentedString(repaymentTransactionCurrency)).append("\n");
    sb.append("    repaymentTransactionValueDate: ").append(toIndentedString(repaymentTransactionValueDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

