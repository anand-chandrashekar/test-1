package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord   {
  @JsonProperty("productInstanceReference")
  private String productInstanceReference = null;

  @JsonProperty("consumerLoanNumber")
  private String consumerLoanNumber = null;

  @JsonProperty("loanType")
  private String loanType = null;

  @JsonProperty("loanAmount")
  private String loanAmount = null;

  @JsonProperty("loanCurrency")
  private String loanCurrency = null;

  @JsonProperty("loanRateType")
  private String loanRateType = null;

  @JsonProperty("loanApplicableRate")
  private String loanApplicableRate = null;

  @JsonProperty("interestType")
  private String interestType = null;

  @JsonProperty("interestAccrualMethod")
  private String interestAccrualMethod = null;

  @JsonProperty("loanOriginationDate")
  private String loanOriginationDate = null;

  @JsonProperty("loanMaturityDate")
  private String loanMaturityDate = null;

  @JsonProperty("loanOutstandingBalance")
  private String loanOutstandingBalance = null;

  @JsonProperty("dateType")
  private CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType = null;

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord productInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance 
   * @return productInstanceReference
  **/
  @ApiModelProperty(example = "789278", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance ")


  public String getProductInstanceReference() {
    return productInstanceReference;
  }

  public void setProductInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format 
   * @return consumerLoanNumber
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format ")


  public String getConsumerLoanNumber() {
    return consumerLoanNumber;
  }

  public void setConsumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanType(String loanType) {
    this.loanType = loanType;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.LoanType  general-info: The specific type of loan (e.g. term, revolving, evergreen) 
   * @return loanType
  **/
  @ApiModelProperty(value = "`status: Provisionally Registered`  bian-reference: Loan.LoanType  general-info: The specific type of loan (e.g. term, revolving, evergreen) ")


  public String getLoanType() {
    return loanType;
  }

  public void setLoanType(String loanType) {
    this.loanType = loanType;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanAmount(String loanAmount) {
    this.loanAmount = loanAmount;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount  general-info: The amount of the loan 
   * @return loanAmount
  **/
  @ApiModelProperty(example = "USD 250", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount  general-info: The amount of the loan ")


  public String getLoanAmount() {
    return loanAmount;
  }

  public void setLoanAmount(String loanAmount) {
    this.loanAmount = loanAmount;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanCurrency(String loanCurrency) {
    this.loanCurrency = loanCurrency;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_X0hLUKRMEeO1ke9HGqKZhg  bian-reference: Loan(as Debt).PaymentCurrency  general-info: The currency for the loan account 
   * @return loanCurrency
  **/
  @ApiModelProperty(example = "USD", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_X0hLUKRMEeO1ke9HGqKZhg  bian-reference: Loan(as Debt).PaymentCurrency  general-info: The currency for the loan account ")


  public String getLoanCurrency() {
    return loanCurrency;
  }

  public void setLoanCurrency(String loanCurrency) {
    this.loanCurrency = loanCurrency;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanRateType(String loanRateType) {
    this.loanRateType = loanRateType;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Fd5lKcTGEeChad0JzLk7QA_-958104524/elements/_FeNHIMTGEeChad0JzLk7QA_-12422289  bian-reference: Loan(as Debt).NextInterest.VariableInterest.VariableRateChangeFrequency  general-info: The rate type to be applied to the loan 
   * @return loanRateType
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Fd5lKcTGEeChad0JzLk7QA_-958104524/elements/_FeNHIMTGEeChad0JzLk7QA_-12422289  bian-reference: Loan(as Debt).NextInterest.VariableInterest.VariableRateChangeFrequency  general-info: The rate type to be applied to the loan ")


  public String getLoanRateType() {
    return loanRateType;
  }

  public void setLoanRateType(String loanRateType) {
    this.loanRateType = loanRateType;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanApplicableRate(String loanApplicableRate) {
    this.loanApplicableRate = loanApplicableRate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FXWRMsTGEeChad0JzLk7QA_-398781879/elements/_FXgCNMTGEeChad0JzLk7QA_-129916673  bian-reference: Loan(as Debt).NextInterest.VariableInterest  general-info: The applicable rate for the loan 
   * @return loanApplicableRate
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FXWRMsTGEeChad0JzLk7QA_-398781879/elements/_FXgCNMTGEeChad0JzLk7QA_-129916673  bian-reference: Loan(as Debt).NextInterest.VariableInterest  general-info: The applicable rate for the loan ")


  public String getLoanApplicableRate() {
    return loanApplicableRate;
  }

  public void setLoanApplicableRate(String loanApplicableRate) {
    this.loanApplicableRate = loanApplicableRate;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord interestType(String interestType) {
    this.interestType = interestType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of interest to be applied (e.g. prime plus) 
   * @return interestType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of interest to be applied (e.g. prime plus) ")


  public String getInterestType() {
    return interestType;
  }

  public void setInterestType(String interestType) {
    this.interestType = interestType;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord interestAccrualMethod(String interestAccrualMethod) {
    this.interestAccrualMethod = interestAccrualMethod;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The accrual method applied to interest calculations 
   * @return interestAccrualMethod
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The accrual method applied to interest calculations ")


  public String getInterestAccrualMethod() {
    return interestAccrualMethod;
  }

  public void setInterestAccrualMethod(String interestAccrualMethod) {
    this.interestAccrualMethod = interestAccrualMethod;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOriginationDate(String loanOriginationDate) {
    this.loanOriginationDate = loanOriginationDate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_Fey9AMTGEeChad0JzLk7QA_300376414  bian-reference: Loan(as Asset).EffectiveDate  general-info: The origination date for the loan 
   * @return loanOriginationDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_Fey9AMTGEeChad0JzLk7QA_300376414  bian-reference: Loan(as Asset).EffectiveDate  general-info: The origination date for the loan ")


  public String getLoanOriginationDate() {
    return loanOriginationDate;
  }

  public void setLoanOriginationDate(String loanOriginationDate) {
    this.loanOriginationDate = loanOriginationDate;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanMaturityDate(String loanMaturityDate) {
    this.loanMaturityDate = loanMaturityDate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FP5lYcTGEeChad0JzLk7QA_-943816417  bian-reference: Loan(as Asset).MaturityDate  general-info: The planned maturity date of the loan 
   * @return loanMaturityDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FP5lYcTGEeChad0JzLk7QA_-943816417  bian-reference: Loan(as Asset).MaturityDate  general-info: The planned maturity date of the loan ")


  public String getLoanMaturityDate() {
    return loanMaturityDate;
  }

  public void setLoanMaturityDate(String loanMaturityDate) {
    this.loanMaturityDate = loanMaturityDate;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance 
   * @return loanOutstandingBalance
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance ")


  public String getLoanOutstandingBalance() {
    return loanOutstandingBalance;
  }

  public void setLoanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
  }

  public BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord dateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
    return this;
  }

  /**
   * Get dateType
   * @return dateType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType getDateType() {
    return dateType;
  }

  public void setDateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord = (BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord) o;
    return Objects.equals(this.productInstanceReference, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.productInstanceReference) &&
        Objects.equals(this.consumerLoanNumber, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.consumerLoanNumber) &&
        Objects.equals(this.loanType, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanType) &&
        Objects.equals(this.loanAmount, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanAmount) &&
        Objects.equals(this.loanCurrency, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanCurrency) &&
        Objects.equals(this.loanRateType, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanRateType) &&
        Objects.equals(this.loanApplicableRate, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanApplicableRate) &&
        Objects.equals(this.interestType, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.interestType) &&
        Objects.equals(this.interestAccrualMethod, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.interestAccrualMethod) &&
        Objects.equals(this.loanOriginationDate, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOriginationDate) &&
        Objects.equals(this.loanMaturityDate, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanMaturityDate) &&
        Objects.equals(this.loanOutstandingBalance, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOutstandingBalance) &&
        Objects.equals(this.dateType, bqInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.dateType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productInstanceReference, consumerLoanNumber, loanType, loanAmount, loanCurrency, loanRateType, loanApplicableRate, interestType, interestAccrualMethod, loanOriginationDate, loanMaturityDate, loanOutstandingBalance, dateType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQInterestRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord {\n");
    
    sb.append("    productInstanceReference: ").append(toIndentedString(productInstanceReference)).append("\n");
    sb.append("    consumerLoanNumber: ").append(toIndentedString(consumerLoanNumber)).append("\n");
    sb.append("    loanType: ").append(toIndentedString(loanType)).append("\n");
    sb.append("    loanAmount: ").append(toIndentedString(loanAmount)).append("\n");
    sb.append("    loanCurrency: ").append(toIndentedString(loanCurrency)).append("\n");
    sb.append("    loanRateType: ").append(toIndentedString(loanRateType)).append("\n");
    sb.append("    loanApplicableRate: ").append(toIndentedString(loanApplicableRate)).append("\n");
    sb.append("    interestType: ").append(toIndentedString(interestType)).append("\n");
    sb.append("    interestAccrualMethod: ").append(toIndentedString(interestAccrualMethod)).append("\n");
    sb.append("    loanOriginationDate: ").append(toIndentedString(loanOriginationDate)).append("\n");
    sb.append("    loanMaturityDate: ").append(toIndentedString(loanMaturityDate)).append("\n");
    sb.append("    loanOutstandingBalance: ").append(toIndentedString(loanOutstandingBalance)).append("\n");
    sb.append("    dateType: ").append(toIndentedString(dateType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

