package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanCreateInputModelConsumerLoanRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanCreateInputModelConsumerLoanRecord   {
  @JsonProperty("productInstanceReference")
  private String productInstanceReference = null;

  @JsonProperty("customerReference")
  private String customerReference = null;

  @JsonProperty("consumerLoanName")
  private String consumerLoanName = null;

  @JsonProperty("loanType")
  private String loanType = null;

  @JsonProperty("loanAmount")
  private String loanAmount = null;

  @JsonProperty("loanCurrency")
  private String loanCurrency = null;

  @JsonProperty("loanRateType")
  private String loanRateType = null;

  @JsonProperty("loanApplicableRate")
  private String loanApplicableRate = null;

  public CRConsumerLoanCreateInputModelConsumerLoanRecord productInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance 
   * @return productInstanceReference
  **/
  @ApiModelProperty(example = "787535", required = true, value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance ")
  @NotNull


  public String getProductInstanceReference() {
    return productInstanceReference;
  }

  public void setProductInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
  }

  public CRConsumerLoanCreateInputModelConsumerLoanRecord customerReference(String customerReference) {
    this.customerReference = customerReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner 
   * @return customerReference
  **/
  @ApiModelProperty(example = "727556", required = true, value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner ")
  @NotNull


  public String getCustomerReference() {
    return customerReference;
  }

  public void setCustomerReference(String customerReference) {
    this.customerReference = customerReference;
  }

  public CRConsumerLoanCreateInputModelConsumerLoanRecord consumerLoanName(String consumerLoanName) {
    this.consumerLoanName = consumerLoanName;
    return this;
  }

  /**
   * general-info: A custom name specified for the loan (e.g. Appliance Loan, Holiday Loan) 
   * @return consumerLoanName
  **/
  @ApiModelProperty(example = "Appliance Loan", required = true, value = "general-info: A custom name specified for the loan (e.g. Appliance Loan, Holiday Loan) ")
  @NotNull


  public String getConsumerLoanName() {
    return consumerLoanName;
  }

  public void setConsumerLoanName(String consumerLoanName) {
    this.consumerLoanName = consumerLoanName;
  }

  public CRConsumerLoanCreateInputModelConsumerLoanRecord loanType(String loanType) {
    this.loanType = loanType;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.LoanType  general-info: The specific type of loan (e.g. term, revolving, evergreen) 
   * @return loanType
  **/
  @ApiModelProperty(required = true, value = "`status: Provisionally Registered`  bian-reference: Loan.LoanType  general-info: The specific type of loan (e.g. term, revolving, evergreen) ")
  @NotNull


  public String getLoanType() {
    return loanType;
  }

  public void setLoanType(String loanType) {
    this.loanType = loanType;
  }

  public CRConsumerLoanCreateInputModelConsumerLoanRecord loanAmount(String loanAmount) {
    this.loanAmount = loanAmount;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount  general-info: The amount of the loan 
   * @return loanAmount
  **/
  @ApiModelProperty(example = "USD 250", required = true, value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount  general-info: The amount of the loan ")
  @NotNull


  public String getLoanAmount() {
    return loanAmount;
  }

  public void setLoanAmount(String loanAmount) {
    this.loanAmount = loanAmount;
  }

  public CRConsumerLoanCreateInputModelConsumerLoanRecord loanCurrency(String loanCurrency) {
    this.loanCurrency = loanCurrency;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_X0hLUKRMEeO1ke9HGqKZhg  bian-reference: Loan(as Debt).PaymentCurrency  general-info: The currency for the loan account 
   * @return loanCurrency
  **/
  @ApiModelProperty(example = "USD", required = true, value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_X0hLUKRMEeO1ke9HGqKZhg  bian-reference: Loan(as Debt).PaymentCurrency  general-info: The currency for the loan account ")
  @NotNull


  public String getLoanCurrency() {
    return loanCurrency;
  }

  public void setLoanCurrency(String loanCurrency) {
    this.loanCurrency = loanCurrency;
  }

  public CRConsumerLoanCreateInputModelConsumerLoanRecord loanRateType(String loanRateType) {
    this.loanRateType = loanRateType;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Fd5lKcTGEeChad0JzLk7QA_-958104524/elements/_FeNHIMTGEeChad0JzLk7QA_-12422289  bian-reference: Loan(as Debt).NextInterest.VariableInterest.VariableRateChangeFrequency  general-info: The rate type to be applied to the loan 
   * @return loanRateType
  **/
  @ApiModelProperty(required = true, value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Fd5lKcTGEeChad0JzLk7QA_-958104524/elements/_FeNHIMTGEeChad0JzLk7QA_-12422289  bian-reference: Loan(as Debt).NextInterest.VariableInterest.VariableRateChangeFrequency  general-info: The rate type to be applied to the loan ")
  @NotNull


  public String getLoanRateType() {
    return loanRateType;
  }

  public void setLoanRateType(String loanRateType) {
    this.loanRateType = loanRateType;
  }

  public CRConsumerLoanCreateInputModelConsumerLoanRecord loanApplicableRate(String loanApplicableRate) {
    this.loanApplicableRate = loanApplicableRate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FXWRMsTGEeChad0JzLk7QA_-398781879/elements/_FXgCNMTGEeChad0JzLk7QA_-129916673  bian-reference: Loan(as Debt).NextInterest.VariableInterest  general-info: The applicable rate for the loan 
   * @return loanApplicableRate
  **/
  @ApiModelProperty(required = true, value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FXWRMsTGEeChad0JzLk7QA_-398781879/elements/_FXgCNMTGEeChad0JzLk7QA_-129916673  bian-reference: Loan(as Debt).NextInterest.VariableInterest  general-info: The applicable rate for the loan ")
  @NotNull


  public String getLoanApplicableRate() {
    return loanApplicableRate;
  }

  public void setLoanApplicableRate(String loanApplicableRate) {
    this.loanApplicableRate = loanApplicableRate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanCreateInputModelConsumerLoanRecord crConsumerLoanCreateInputModelConsumerLoanRecord = (CRConsumerLoanCreateInputModelConsumerLoanRecord) o;
    return Objects.equals(this.productInstanceReference, crConsumerLoanCreateInputModelConsumerLoanRecord.productInstanceReference) &&
        Objects.equals(this.customerReference, crConsumerLoanCreateInputModelConsumerLoanRecord.customerReference) &&
        Objects.equals(this.consumerLoanName, crConsumerLoanCreateInputModelConsumerLoanRecord.consumerLoanName) &&
        Objects.equals(this.loanType, crConsumerLoanCreateInputModelConsumerLoanRecord.loanType) &&
        Objects.equals(this.loanAmount, crConsumerLoanCreateInputModelConsumerLoanRecord.loanAmount) &&
        Objects.equals(this.loanCurrency, crConsumerLoanCreateInputModelConsumerLoanRecord.loanCurrency) &&
        Objects.equals(this.loanRateType, crConsumerLoanCreateInputModelConsumerLoanRecord.loanRateType) &&
        Objects.equals(this.loanApplicableRate, crConsumerLoanCreateInputModelConsumerLoanRecord.loanApplicableRate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productInstanceReference, customerReference, consumerLoanName, loanType, loanAmount, loanCurrency, loanRateType, loanApplicableRate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanCreateInputModelConsumerLoanRecord {\n");
    
    sb.append("    productInstanceReference: ").append(toIndentedString(productInstanceReference)).append("\n");
    sb.append("    customerReference: ").append(toIndentedString(customerReference)).append("\n");
    sb.append("    consumerLoanName: ").append(toIndentedString(consumerLoanName)).append("\n");
    sb.append("    loanType: ").append(toIndentedString(loanType)).append("\n");
    sb.append("    loanAmount: ").append(toIndentedString(loanAmount)).append("\n");
    sb.append("    loanCurrency: ").append(toIndentedString(loanCurrency)).append("\n");
    sb.append("    loanRateType: ").append(toIndentedString(loanRateType)).append("\n");
    sb.append("    loanApplicableRate: ").append(toIndentedString(loanApplicableRate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

