package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRequestInputModelMaintenanceInstanceRecord;
import io.swagger.model.BQMaintenanceRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis;
import io.swagger.model.BQMaintenanceRetrieveOutputModelMaintenanceInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQMaintenanceRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("maintenanceInstanceRecord")
  private BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord = null;

  @JsonProperty("maintenanceRetrieveActionTaskReference")
  private String maintenanceRetrieveActionTaskReference = null;

  @JsonProperty("maintenanceRetrieveActionTaskRecord")
  private Object maintenanceRetrieveActionTaskRecord = null;

  @JsonProperty("maintenanceRetrieveActionResponse")
  private String maintenanceRetrieveActionResponse = null;

  @JsonProperty("maintenanceInstanceReport")
  private BQMaintenanceRetrieveOutputModelMaintenanceInstanceReport maintenanceInstanceReport = null;

  @JsonProperty("maintenanceInstanceAnalysis")
  private BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysis = null;

  public BQMaintenanceRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQMaintenanceRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQMaintenanceRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQMaintenanceRetrieveOutputModel maintenanceInstanceRecord(BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord) {
    this.maintenanceInstanceRecord = maintenanceInstanceRecord;
    return this;
  }

  /**
   * Get maintenanceInstanceRecord
   * @return maintenanceInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecord getMaintenanceInstanceRecord() {
    return maintenanceInstanceRecord;
  }

  public void setMaintenanceInstanceRecord(BQMaintenanceRequestInputModelMaintenanceInstanceRecord maintenanceInstanceRecord) {
    this.maintenanceInstanceRecord = maintenanceInstanceRecord;
  }

  public BQMaintenanceRetrieveOutputModel maintenanceRetrieveActionTaskReference(String maintenanceRetrieveActionTaskReference) {
    this.maintenanceRetrieveActionTaskReference = maintenanceRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Maintenance instance retrieve service call 
   * @return maintenanceRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "MRATR715116", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Maintenance instance retrieve service call ")


  public String getMaintenanceRetrieveActionTaskReference() {
    return maintenanceRetrieveActionTaskReference;
  }

  public void setMaintenanceRetrieveActionTaskReference(String maintenanceRetrieveActionTaskReference) {
    this.maintenanceRetrieveActionTaskReference = maintenanceRetrieveActionTaskReference;
  }

  public BQMaintenanceRetrieveOutputModel maintenanceRetrieveActionTaskRecord(Object maintenanceRetrieveActionTaskRecord) {
    this.maintenanceRetrieveActionTaskRecord = maintenanceRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return maintenanceRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getMaintenanceRetrieveActionTaskRecord() {
    return maintenanceRetrieveActionTaskRecord;
  }

  public void setMaintenanceRetrieveActionTaskRecord(Object maintenanceRetrieveActionTaskRecord) {
    this.maintenanceRetrieveActionTaskRecord = maintenanceRetrieveActionTaskRecord;
  }

  public BQMaintenanceRetrieveOutputModel maintenanceRetrieveActionResponse(String maintenanceRetrieveActionResponse) {
    this.maintenanceRetrieveActionResponse = maintenanceRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return maintenanceRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getMaintenanceRetrieveActionResponse() {
    return maintenanceRetrieveActionResponse;
  }

  public void setMaintenanceRetrieveActionResponse(String maintenanceRetrieveActionResponse) {
    this.maintenanceRetrieveActionResponse = maintenanceRetrieveActionResponse;
  }

  public BQMaintenanceRetrieveOutputModel maintenanceInstanceReport(BQMaintenanceRetrieveOutputModelMaintenanceInstanceReport maintenanceInstanceReport) {
    this.maintenanceInstanceReport = maintenanceInstanceReport;
    return this;
  }

  /**
   * Get maintenanceInstanceReport
   * @return maintenanceInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRetrieveOutputModelMaintenanceInstanceReport getMaintenanceInstanceReport() {
    return maintenanceInstanceReport;
  }

  public void setMaintenanceInstanceReport(BQMaintenanceRetrieveOutputModelMaintenanceInstanceReport maintenanceInstanceReport) {
    this.maintenanceInstanceReport = maintenanceInstanceReport;
  }

  public BQMaintenanceRetrieveOutputModel maintenanceInstanceAnalysis(BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysis) {
    this.maintenanceInstanceAnalysis = maintenanceInstanceAnalysis;
    return this;
  }

  /**
   * Get maintenanceInstanceAnalysis
   * @return maintenanceInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis getMaintenanceInstanceAnalysis() {
    return maintenanceInstanceAnalysis;
  }

  public void setMaintenanceInstanceAnalysis(BQMaintenanceRetrieveOutputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysis) {
    this.maintenanceInstanceAnalysis = maintenanceInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRetrieveOutputModel bqMaintenanceRetrieveOutputModel = (BQMaintenanceRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqMaintenanceRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.maintenanceInstanceRecord, bqMaintenanceRetrieveOutputModel.maintenanceInstanceRecord) &&
        Objects.equals(this.maintenanceRetrieveActionTaskReference, bqMaintenanceRetrieveOutputModel.maintenanceRetrieveActionTaskReference) &&
        Objects.equals(this.maintenanceRetrieveActionTaskRecord, bqMaintenanceRetrieveOutputModel.maintenanceRetrieveActionTaskRecord) &&
        Objects.equals(this.maintenanceRetrieveActionResponse, bqMaintenanceRetrieveOutputModel.maintenanceRetrieveActionResponse) &&
        Objects.equals(this.maintenanceInstanceReport, bqMaintenanceRetrieveOutputModel.maintenanceInstanceReport) &&
        Objects.equals(this.maintenanceInstanceAnalysis, bqMaintenanceRetrieveOutputModel.maintenanceInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, maintenanceInstanceRecord, maintenanceRetrieveActionTaskReference, maintenanceRetrieveActionTaskRecord, maintenanceRetrieveActionResponse, maintenanceInstanceReport, maintenanceInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    maintenanceInstanceRecord: ").append(toIndentedString(maintenanceInstanceRecord)).append("\n");
    sb.append("    maintenanceRetrieveActionTaskReference: ").append(toIndentedString(maintenanceRetrieveActionTaskReference)).append("\n");
    sb.append("    maintenanceRetrieveActionTaskRecord: ").append(toIndentedString(maintenanceRetrieveActionTaskRecord)).append("\n");
    sb.append("    maintenanceRetrieveActionResponse: ").append(toIndentedString(maintenanceRetrieveActionResponse)).append("\n");
    sb.append("    maintenanceInstanceReport: ").append(toIndentedString(maintenanceInstanceReport)).append("\n");
    sb.append("    maintenanceInstanceAnalysis: ").append(toIndentedString(maintenanceInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

