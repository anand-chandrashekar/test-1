package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction   {
  @JsonProperty("paymentTransactionType")
  private String paymentTransactionType = null;

  @JsonProperty("paymentTransactionPayeeReference")
  private String paymentTransactionPayeeReference = null;

  @JsonProperty("paymentTransactionPayeeAccountReference")
  private String paymentTransactionPayeeAccountReference = null;

  @JsonProperty("paymentTransactionPayeeBankReference")
  private String paymentTransactionPayeeBankReference = null;

  @JsonProperty("paymentTransactionAmount")
  private String paymentTransactionAmount = null;

  @JsonProperty("paymentTransactionFeeType")
  private String paymentTransactionFeeType = null;

  @JsonProperty("paymentTransactionFeeCharge")
  private String paymentTransactionFeeCharge = null;

  @JsonProperty("paymentTransactionDate")
  private String paymentTransactionDate = null;

  @JsonProperty("paymentTransactionPaymentMechanism")
  private String paymentTransactionPaymentMechanism = null;

  @JsonProperty("paymentTransactionPaymentPurpose")
  private String paymentTransactionPaymentPurpose = null;

  @JsonProperty("paymentTransactionBankBranchLocationReference")
  private String paymentTransactionBankBranchLocationReference = null;

  @JsonProperty("paymentTransactionStatus")
  private String paymentTransactionStatus = null;

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionType(String paymentTransactionType) {
    this.paymentTransactionType = paymentTransactionType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of payment transaction (e.g. customer payment, standing order, direct debit, bill pay) 
   * @return paymentTransactionType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of payment transaction (e.g. customer payment, standing order, direct debit, bill pay) ")


  public String getPaymentTransactionType() {
    return paymentTransactionType;
  }

  public void setPaymentTransactionType(String paymentTransactionType) {
    this.paymentTransactionType = paymentTransactionType;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionPayeeReference(String paymentTransactionPayeeReference) {
    this.paymentTransactionPayeeReference = paymentTransactionPayeeReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the party to whom the payment is made 
   * @return paymentTransactionPayeeReference
  **/
  @ApiModelProperty(example = "753795", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the party to whom the payment is made ")


  public String getPaymentTransactionPayeeReference() {
    return paymentTransactionPayeeReference;
  }

  public void setPaymentTransactionPayeeReference(String paymentTransactionPayeeReference) {
    this.paymentTransactionPayeeReference = paymentTransactionPayeeReference;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionPayeeAccountReference(String paymentTransactionPayeeAccountReference) {
    this.paymentTransactionPayeeAccountReference = paymentTransactionPayeeAccountReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account to which the payment is made 
   * @return paymentTransactionPayeeAccountReference
  **/
  @ApiModelProperty(example = "766675", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account to which the payment is made ")


  public String getPaymentTransactionPayeeAccountReference() {
    return paymentTransactionPayeeAccountReference;
  }

  public void setPaymentTransactionPayeeAccountReference(String paymentTransactionPayeeAccountReference) {
    this.paymentTransactionPayeeAccountReference = paymentTransactionPayeeAccountReference;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionPayeeBankReference(String paymentTransactionPayeeBankReference) {
    this.paymentTransactionPayeeBankReference = paymentTransactionPayeeBankReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the bank where the payee account is held 
   * @return paymentTransactionPayeeBankReference
  **/
  @ApiModelProperty(example = "771178", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the bank where the payee account is held ")


  public String getPaymentTransactionPayeeBankReference() {
    return paymentTransactionPayeeBankReference;
  }

  public void setPaymentTransactionPayeeBankReference(String paymentTransactionPayeeBankReference) {
    this.paymentTransactionPayeeBankReference = paymentTransactionPayeeBankReference;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionAmount(String paymentTransactionAmount) {
    this.paymentTransactionAmount = paymentTransactionAmount;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The amount (and currency if applicable) of the payment 
   * @return paymentTransactionAmount
  **/
  @ApiModelProperty(example = "USD 250", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The amount (and currency if applicable) of the payment ")


  public String getPaymentTransactionAmount() {
    return paymentTransactionAmount;
  }

  public void setPaymentTransactionAmount(String paymentTransactionAmount) {
    this.paymentTransactionAmount = paymentTransactionAmount;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionFeeType(String paymentTransactionFeeType) {
    this.paymentTransactionFeeType = paymentTransactionFeeType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The fee type applied to the payment transaction 
   * @return paymentTransactionFeeType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The fee type applied to the payment transaction ")


  public String getPaymentTransactionFeeType() {
    return paymentTransactionFeeType;
  }

  public void setPaymentTransactionFeeType(String paymentTransactionFeeType) {
    this.paymentTransactionFeeType = paymentTransactionFeeType;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionFeeCharge(String paymentTransactionFeeCharge) {
    this.paymentTransactionFeeCharge = paymentTransactionFeeCharge;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The fee charge applied to the transaction 
   * @return paymentTransactionFeeCharge
  **/
  @ApiModelProperty(example = "USD 250", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The fee charge applied to the transaction ")


  public String getPaymentTransactionFeeCharge() {
    return paymentTransactionFeeCharge;
  }

  public void setPaymentTransactionFeeCharge(String paymentTransactionFeeCharge) {
    this.paymentTransactionFeeCharge = paymentTransactionFeeCharge;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionDate(String paymentTransactionDate) {
    this.paymentTransactionDate = paymentTransactionDate;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The various key dates and times associated with the payment transaction 
   * @return paymentTransactionDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The various key dates and times associated with the payment transaction ")


  public String getPaymentTransactionDate() {
    return paymentTransactionDate;
  }

  public void setPaymentTransactionDate(String paymentTransactionDate) {
    this.paymentTransactionDate = paymentTransactionDate;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionPaymentMechanism(String paymentTransactionPaymentMechanism) {
    this.paymentTransactionPaymentMechanism = paymentTransactionPaymentMechanism;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Requested payment mechanism (e.g. Wire, ACH) 
   * @return paymentTransactionPaymentMechanism
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Requested payment mechanism (e.g. Wire, ACH) ")


  public String getPaymentTransactionPaymentMechanism() {
    return paymentTransactionPaymentMechanism;
  }

  public void setPaymentTransactionPaymentMechanism(String paymentTransactionPaymentMechanism) {
    this.paymentTransactionPaymentMechanism = paymentTransactionPaymentMechanism;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionPaymentPurpose(String paymentTransactionPaymentPurpose) {
    this.paymentTransactionPaymentPurpose = paymentTransactionPaymentPurpose;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Description of the purpose including any external reference to the transaction 
   * @return paymentTransactionPaymentPurpose
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Description of the purpose including any external reference to the transaction ")


  public String getPaymentTransactionPaymentPurpose() {
    return paymentTransactionPaymentPurpose;
  }

  public void setPaymentTransactionPaymentPurpose(String paymentTransactionPaymentPurpose) {
    this.paymentTransactionPaymentPurpose = paymentTransactionPaymentPurpose;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionBankBranchLocationReference(String paymentTransactionBankBranchLocationReference) {
    this.paymentTransactionBankBranchLocationReference = paymentTransactionBankBranchLocationReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the location the payment transaction is initiated from  
   * @return paymentTransactionBankBranchLocationReference
  **/
  @ApiModelProperty(example = "795725", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the location the payment transaction is initiated from  ")


  public String getPaymentTransactionBankBranchLocationReference() {
    return paymentTransactionBankBranchLocationReference;
  }

  public void setPaymentTransactionBankBranchLocationReference(String paymentTransactionBankBranchLocationReference) {
    this.paymentTransactionBankBranchLocationReference = paymentTransactionBankBranchLocationReference;
  }

  public BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction paymentTransactionStatus(String paymentTransactionStatus) {
    this.paymentTransactionStatus = paymentTransactionStatus;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The processing status of the transaction (e.g. captured, approved, initiated, confirmed, settled) 
   * @return paymentTransactionStatus
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The processing status of the transaction (e.g. captured, approved, initiated, confirmed, settled) ")


  public String getPaymentTransactionStatus() {
    return paymentTransactionStatus;
  }

  public void setPaymentTransactionStatus(String paymentTransactionStatus) {
    this.paymentTransactionStatus = paymentTransactionStatus;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction = (BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction) o;
    return Objects.equals(this.paymentTransactionType, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionType) &&
        Objects.equals(this.paymentTransactionPayeeReference, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionPayeeReference) &&
        Objects.equals(this.paymentTransactionPayeeAccountReference, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionPayeeAccountReference) &&
        Objects.equals(this.paymentTransactionPayeeBankReference, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionPayeeBankReference) &&
        Objects.equals(this.paymentTransactionAmount, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionAmount) &&
        Objects.equals(this.paymentTransactionFeeType, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionFeeType) &&
        Objects.equals(this.paymentTransactionFeeCharge, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionFeeCharge) &&
        Objects.equals(this.paymentTransactionDate, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionDate) &&
        Objects.equals(this.paymentTransactionPaymentMechanism, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionPaymentMechanism) &&
        Objects.equals(this.paymentTransactionPaymentPurpose, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionPaymentPurpose) &&
        Objects.equals(this.paymentTransactionBankBranchLocationReference, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionBankBranchLocationReference) &&
        Objects.equals(this.paymentTransactionStatus, bqWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction.paymentTransactionStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(paymentTransactionType, paymentTransactionPayeeReference, paymentTransactionPayeeAccountReference, paymentTransactionPayeeBankReference, paymentTransactionAmount, paymentTransactionFeeType, paymentTransactionFeeCharge, paymentTransactionDate, paymentTransactionPaymentMechanism, paymentTransactionPaymentPurpose, paymentTransactionBankBranchLocationReference, paymentTransactionStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalExecuteInputModelWithdrawalInstanceRecordPaymentTransaction {\n");
    
    sb.append("    paymentTransactionType: ").append(toIndentedString(paymentTransactionType)).append("\n");
    sb.append("    paymentTransactionPayeeReference: ").append(toIndentedString(paymentTransactionPayeeReference)).append("\n");
    sb.append("    paymentTransactionPayeeAccountReference: ").append(toIndentedString(paymentTransactionPayeeAccountReference)).append("\n");
    sb.append("    paymentTransactionPayeeBankReference: ").append(toIndentedString(paymentTransactionPayeeBankReference)).append("\n");
    sb.append("    paymentTransactionAmount: ").append(toIndentedString(paymentTransactionAmount)).append("\n");
    sb.append("    paymentTransactionFeeType: ").append(toIndentedString(paymentTransactionFeeType)).append("\n");
    sb.append("    paymentTransactionFeeCharge: ").append(toIndentedString(paymentTransactionFeeCharge)).append("\n");
    sb.append("    paymentTransactionDate: ").append(toIndentedString(paymentTransactionDate)).append("\n");
    sb.append("    paymentTransactionPaymentMechanism: ").append(toIndentedString(paymentTransactionPaymentMechanism)).append("\n");
    sb.append("    paymentTransactionPaymentPurpose: ").append(toIndentedString(paymentTransactionPaymentPurpose)).append("\n");
    sb.append("    paymentTransactionBankBranchLocationReference: ").append(toIndentedString(paymentTransactionBankBranchLocationReference)).append("\n");
    sb.append("    paymentTransactionStatus: ").append(toIndentedString(paymentTransactionStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

