package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQRepaymentRetrieveOutputModelRepaymentInstanceAnalysis;
import io.swagger.model.BQRepaymentRetrieveOutputModelRepaymentInstanceRecord;
import io.swagger.model.BQRepaymentRetrieveOutputModelRepaymentInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("repaymentInstanceRecord")
  private BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentInstanceRecord = null;

  @JsonProperty("repaymentRetrieveActionTaskReference")
  private String repaymentRetrieveActionTaskReference = null;

  @JsonProperty("repaymentRetrieveActionTaskRecord")
  private Object repaymentRetrieveActionTaskRecord = null;

  @JsonProperty("repaymentRetrieveActionResponse")
  private String repaymentRetrieveActionResponse = null;

  @JsonProperty("repaymentInstanceReport")
  private BQRepaymentRetrieveOutputModelRepaymentInstanceReport repaymentInstanceReport = null;

  @JsonProperty("repaymentInstanceAnalysis")
  private BQRepaymentRetrieveOutputModelRepaymentInstanceAnalysis repaymentInstanceAnalysis = null;

  public BQRepaymentRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQRepaymentRetrieveOutputModel repaymentInstanceRecord(BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
    return this;
  }

  /**
   * Get repaymentInstanceRecord
   * @return repaymentInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentRetrieveOutputModelRepaymentInstanceRecord getRepaymentInstanceRecord() {
    return repaymentInstanceRecord;
  }

  public void setRepaymentInstanceRecord(BQRepaymentRetrieveOutputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
  }

  public BQRepaymentRetrieveOutputModel repaymentRetrieveActionTaskReference(String repaymentRetrieveActionTaskReference) {
    this.repaymentRetrieveActionTaskReference = repaymentRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Repayment instance retrieve service call 
   * @return repaymentRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "RRATR737534", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Repayment instance retrieve service call ")


  public String getRepaymentRetrieveActionTaskReference() {
    return repaymentRetrieveActionTaskReference;
  }

  public void setRepaymentRetrieveActionTaskReference(String repaymentRetrieveActionTaskReference) {
    this.repaymentRetrieveActionTaskReference = repaymentRetrieveActionTaskReference;
  }

  public BQRepaymentRetrieveOutputModel repaymentRetrieveActionTaskRecord(Object repaymentRetrieveActionTaskRecord) {
    this.repaymentRetrieveActionTaskRecord = repaymentRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return repaymentRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getRepaymentRetrieveActionTaskRecord() {
    return repaymentRetrieveActionTaskRecord;
  }

  public void setRepaymentRetrieveActionTaskRecord(Object repaymentRetrieveActionTaskRecord) {
    this.repaymentRetrieveActionTaskRecord = repaymentRetrieveActionTaskRecord;
  }

  public BQRepaymentRetrieveOutputModel repaymentRetrieveActionResponse(String repaymentRetrieveActionResponse) {
    this.repaymentRetrieveActionResponse = repaymentRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return repaymentRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getRepaymentRetrieveActionResponse() {
    return repaymentRetrieveActionResponse;
  }

  public void setRepaymentRetrieveActionResponse(String repaymentRetrieveActionResponse) {
    this.repaymentRetrieveActionResponse = repaymentRetrieveActionResponse;
  }

  public BQRepaymentRetrieveOutputModel repaymentInstanceReport(BQRepaymentRetrieveOutputModelRepaymentInstanceReport repaymentInstanceReport) {
    this.repaymentInstanceReport = repaymentInstanceReport;
    return this;
  }

  /**
   * Get repaymentInstanceReport
   * @return repaymentInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentRetrieveOutputModelRepaymentInstanceReport getRepaymentInstanceReport() {
    return repaymentInstanceReport;
  }

  public void setRepaymentInstanceReport(BQRepaymentRetrieveOutputModelRepaymentInstanceReport repaymentInstanceReport) {
    this.repaymentInstanceReport = repaymentInstanceReport;
  }

  public BQRepaymentRetrieveOutputModel repaymentInstanceAnalysis(BQRepaymentRetrieveOutputModelRepaymentInstanceAnalysis repaymentInstanceAnalysis) {
    this.repaymentInstanceAnalysis = repaymentInstanceAnalysis;
    return this;
  }

  /**
   * Get repaymentInstanceAnalysis
   * @return repaymentInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentRetrieveOutputModelRepaymentInstanceAnalysis getRepaymentInstanceAnalysis() {
    return repaymentInstanceAnalysis;
  }

  public void setRepaymentInstanceAnalysis(BQRepaymentRetrieveOutputModelRepaymentInstanceAnalysis repaymentInstanceAnalysis) {
    this.repaymentInstanceAnalysis = repaymentInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRetrieveOutputModel bqRepaymentRetrieveOutputModel = (BQRepaymentRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqRepaymentRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.repaymentInstanceRecord, bqRepaymentRetrieveOutputModel.repaymentInstanceRecord) &&
        Objects.equals(this.repaymentRetrieveActionTaskReference, bqRepaymentRetrieveOutputModel.repaymentRetrieveActionTaskReference) &&
        Objects.equals(this.repaymentRetrieveActionTaskRecord, bqRepaymentRetrieveOutputModel.repaymentRetrieveActionTaskRecord) &&
        Objects.equals(this.repaymentRetrieveActionResponse, bqRepaymentRetrieveOutputModel.repaymentRetrieveActionResponse) &&
        Objects.equals(this.repaymentInstanceReport, bqRepaymentRetrieveOutputModel.repaymentInstanceReport) &&
        Objects.equals(this.repaymentInstanceAnalysis, bqRepaymentRetrieveOutputModel.repaymentInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, repaymentInstanceRecord, repaymentRetrieveActionTaskReference, repaymentRetrieveActionTaskRecord, repaymentRetrieveActionResponse, repaymentInstanceReport, repaymentInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    repaymentInstanceRecord: ").append(toIndentedString(repaymentInstanceRecord)).append("\n");
    sb.append("    repaymentRetrieveActionTaskReference: ").append(toIndentedString(repaymentRetrieveActionTaskReference)).append("\n");
    sb.append("    repaymentRetrieveActionTaskRecord: ").append(toIndentedString(repaymentRetrieveActionTaskRecord)).append("\n");
    sb.append("    repaymentRetrieveActionResponse: ").append(toIndentedString(repaymentRetrieveActionResponse)).append("\n");
    sb.append("    repaymentInstanceReport: ").append(toIndentedString(repaymentInstanceReport)).append("\n");
    sb.append("    repaymentInstanceAnalysis: ").append(toIndentedString(repaymentInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

