package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRepaymentExecuteInputModelRepaymentInstanceRecord;
import io.swagger.model.BQServiceFeesExecuteInputModelExecuteRecordType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentExecuteInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentExecuteInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("repaymentInstanceReference")
  private String repaymentInstanceReference = null;

  @JsonProperty("repaymentInstanceRecord")
  private BQRepaymentExecuteInputModelRepaymentInstanceRecord repaymentInstanceRecord = null;

  @JsonProperty("repaymentExecuteActionTaskRecord")
  private Object repaymentExecuteActionTaskRecord = null;

  @JsonProperty("executeRecordType")
  private BQServiceFeesExecuteInputModelExecuteRecordType executeRecordType = null;

  public BQRepaymentExecuteInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR733299", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQRepaymentExecuteInputModel repaymentInstanceReference(String repaymentInstanceReference) {
    this.repaymentInstanceReference = repaymentInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment instance 
   * @return repaymentInstanceReference
  **/
  @ApiModelProperty(example = "RIR736854", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment instance ")


  public String getRepaymentInstanceReference() {
    return repaymentInstanceReference;
  }

  public void setRepaymentInstanceReference(String repaymentInstanceReference) {
    this.repaymentInstanceReference = repaymentInstanceReference;
  }

  public BQRepaymentExecuteInputModel repaymentInstanceRecord(BQRepaymentExecuteInputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
    return this;
  }

  /**
   * Get repaymentInstanceRecord
   * @return repaymentInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentExecuteInputModelRepaymentInstanceRecord getRepaymentInstanceRecord() {
    return repaymentInstanceRecord;
  }

  public void setRepaymentInstanceRecord(BQRepaymentExecuteInputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
  }

  public BQRepaymentExecuteInputModel repaymentExecuteActionTaskRecord(Object repaymentExecuteActionTaskRecord) {
    this.repaymentExecuteActionTaskRecord = repaymentExecuteActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The execute service call consolidated processing record 
   * @return repaymentExecuteActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The execute service call consolidated processing record ")


  public Object getRepaymentExecuteActionTaskRecord() {
    return repaymentExecuteActionTaskRecord;
  }

  public void setRepaymentExecuteActionTaskRecord(Object repaymentExecuteActionTaskRecord) {
    this.repaymentExecuteActionTaskRecord = repaymentExecuteActionTaskRecord;
  }

  public BQRepaymentExecuteInputModel executeRecordType(BQServiceFeesExecuteInputModelExecuteRecordType executeRecordType) {
    this.executeRecordType = executeRecordType;
    return this;
  }

  /**
   * Get executeRecordType
   * @return executeRecordType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQServiceFeesExecuteInputModelExecuteRecordType getExecuteRecordType() {
    return executeRecordType;
  }

  public void setExecuteRecordType(BQServiceFeesExecuteInputModelExecuteRecordType executeRecordType) {
    this.executeRecordType = executeRecordType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentExecuteInputModel bqRepaymentExecuteInputModel = (BQRepaymentExecuteInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqRepaymentExecuteInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.repaymentInstanceReference, bqRepaymentExecuteInputModel.repaymentInstanceReference) &&
        Objects.equals(this.repaymentInstanceRecord, bqRepaymentExecuteInputModel.repaymentInstanceRecord) &&
        Objects.equals(this.repaymentExecuteActionTaskRecord, bqRepaymentExecuteInputModel.repaymentExecuteActionTaskRecord) &&
        Objects.equals(this.executeRecordType, bqRepaymentExecuteInputModel.executeRecordType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, repaymentInstanceReference, repaymentInstanceRecord, repaymentExecuteActionTaskRecord, executeRecordType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentExecuteInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    repaymentInstanceReference: ").append(toIndentedString(repaymentInstanceReference)).append("\n");
    sb.append("    repaymentInstanceRecord: ").append(toIndentedString(repaymentInstanceRecord)).append("\n");
    sb.append("    repaymentExecuteActionTaskRecord: ").append(toIndentedString(repaymentExecuteActionTaskRecord)).append("\n");
    sb.append("    executeRecordType: ").append(toIndentedString(executeRecordType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

