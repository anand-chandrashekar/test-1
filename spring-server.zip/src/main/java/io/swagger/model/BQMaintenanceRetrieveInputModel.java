package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRetrieveInputModelMaintenanceInstanceAnalysis;
import io.swagger.model.BQMaintenanceRetrieveInputModelMaintenanceInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRetrieveInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRetrieveInputModel   {
  @JsonProperty("maintenanceRetrieveActionTaskRecord")
  private Object maintenanceRetrieveActionTaskRecord = null;

  @JsonProperty("maintenanceRetrieveActionRequest")
  private String maintenanceRetrieveActionRequest = null;

  @JsonProperty("maintenanceInstanceReport")
  private BQMaintenanceRetrieveInputModelMaintenanceInstanceReport maintenanceInstanceReport = null;

  @JsonProperty("maintenanceInstanceAnalysis")
  private BQMaintenanceRetrieveInputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysis = null;

  public BQMaintenanceRetrieveInputModel maintenanceRetrieveActionTaskRecord(Object maintenanceRetrieveActionTaskRecord) {
    this.maintenanceRetrieveActionTaskRecord = maintenanceRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return maintenanceRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getMaintenanceRetrieveActionTaskRecord() {
    return maintenanceRetrieveActionTaskRecord;
  }

  public void setMaintenanceRetrieveActionTaskRecord(Object maintenanceRetrieveActionTaskRecord) {
    this.maintenanceRetrieveActionTaskRecord = maintenanceRetrieveActionTaskRecord;
  }

  public BQMaintenanceRetrieveInputModel maintenanceRetrieveActionRequest(String maintenanceRetrieveActionRequest) {
    this.maintenanceRetrieveActionRequest = maintenanceRetrieveActionRequest;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) 
   * @return maintenanceRetrieveActionRequest
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) ")


  public String getMaintenanceRetrieveActionRequest() {
    return maintenanceRetrieveActionRequest;
  }

  public void setMaintenanceRetrieveActionRequest(String maintenanceRetrieveActionRequest) {
    this.maintenanceRetrieveActionRequest = maintenanceRetrieveActionRequest;
  }

  public BQMaintenanceRetrieveInputModel maintenanceInstanceReport(BQMaintenanceRetrieveInputModelMaintenanceInstanceReport maintenanceInstanceReport) {
    this.maintenanceInstanceReport = maintenanceInstanceReport;
    return this;
  }

  /**
   * Get maintenanceInstanceReport
   * @return maintenanceInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRetrieveInputModelMaintenanceInstanceReport getMaintenanceInstanceReport() {
    return maintenanceInstanceReport;
  }

  public void setMaintenanceInstanceReport(BQMaintenanceRetrieveInputModelMaintenanceInstanceReport maintenanceInstanceReport) {
    this.maintenanceInstanceReport = maintenanceInstanceReport;
  }

  public BQMaintenanceRetrieveInputModel maintenanceInstanceAnalysis(BQMaintenanceRetrieveInputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysis) {
    this.maintenanceInstanceAnalysis = maintenanceInstanceAnalysis;
    return this;
  }

  /**
   * Get maintenanceInstanceAnalysis
   * @return maintenanceInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRetrieveInputModelMaintenanceInstanceAnalysis getMaintenanceInstanceAnalysis() {
    return maintenanceInstanceAnalysis;
  }

  public void setMaintenanceInstanceAnalysis(BQMaintenanceRetrieveInputModelMaintenanceInstanceAnalysis maintenanceInstanceAnalysis) {
    this.maintenanceInstanceAnalysis = maintenanceInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRetrieveInputModel bqMaintenanceRetrieveInputModel = (BQMaintenanceRetrieveInputModel) o;
    return Objects.equals(this.maintenanceRetrieveActionTaskRecord, bqMaintenanceRetrieveInputModel.maintenanceRetrieveActionTaskRecord) &&
        Objects.equals(this.maintenanceRetrieveActionRequest, bqMaintenanceRetrieveInputModel.maintenanceRetrieveActionRequest) &&
        Objects.equals(this.maintenanceInstanceReport, bqMaintenanceRetrieveInputModel.maintenanceInstanceReport) &&
        Objects.equals(this.maintenanceInstanceAnalysis, bqMaintenanceRetrieveInputModel.maintenanceInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(maintenanceRetrieveActionTaskRecord, maintenanceRetrieveActionRequest, maintenanceInstanceReport, maintenanceInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRetrieveInputModel {\n");
    
    sb.append("    maintenanceRetrieveActionTaskRecord: ").append(toIndentedString(maintenanceRetrieveActionTaskRecord)).append("\n");
    sb.append("    maintenanceRetrieveActionRequest: ").append(toIndentedString(maintenanceRetrieveActionRequest)).append("\n");
    sb.append("    maintenanceInstanceReport: ").append(toIndentedString(maintenanceInstanceReport)).append("\n");
    sb.append("    maintenanceInstanceAnalysis: ").append(toIndentedString(maintenanceInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

