package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQDisbursementRetrieveOutputModelDisbursementInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQDisbursementRetrieveOutputModelDisbursementInstanceRecord   {
  @JsonProperty("disbursementPayeeReference")
  private String disbursementPayeeReference = null;

  @JsonProperty("disbursementPayeeProductInstanceReference")
  private String disbursementPayeeProductInstanceReference = null;

  @JsonProperty("disbursementPayeeBankReference")
  private String disbursementPayeeBankReference = null;

  @JsonProperty("disbursementAmount")
  private String disbursementAmount = null;

  @JsonProperty("disbursementCurrency")
  private String disbursementCurrency = null;

  @JsonProperty("disbursementValueDate")
  private String disbursementValueDate = null;

  public BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementPayeeReference(String disbursementPayeeReference) {
    this.disbursementPayeeReference = disbursementPayeeReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the party to whom the payment is made 
   * @return disbursementPayeeReference
  **/
  @ApiModelProperty(example = "700160", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the party to whom the payment is made ")


  public String getDisbursementPayeeReference() {
    return disbursementPayeeReference;
  }

  public void setDisbursementPayeeReference(String disbursementPayeeReference) {
    this.disbursementPayeeReference = disbursementPayeeReference;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementPayeeProductInstanceReference(String disbursementPayeeProductInstanceReference) {
    this.disbursementPayeeProductInstanceReference = disbursementPayeeProductInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account to which the payment is made 
   * @return disbursementPayeeProductInstanceReference
  **/
  @ApiModelProperty(example = "770515", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the account to which the payment is made ")


  public String getDisbursementPayeeProductInstanceReference() {
    return disbursementPayeeProductInstanceReference;
  }

  public void setDisbursementPayeeProductInstanceReference(String disbursementPayeeProductInstanceReference) {
    this.disbursementPayeeProductInstanceReference = disbursementPayeeProductInstanceReference;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementPayeeBankReference(String disbursementPayeeBankReference) {
    this.disbursementPayeeBankReference = disbursementPayeeBankReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the bank where the payee account is held 
   * @return disbursementPayeeBankReference
  **/
  @ApiModelProperty(example = "760328", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the bank where the payee account is held ")


  public String getDisbursementPayeeBankReference() {
    return disbursementPayeeBankReference;
  }

  public void setDisbursementPayeeBankReference(String disbursementPayeeBankReference) {
    this.disbursementPayeeBankReference = disbursementPayeeBankReference;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementAmount(String disbursementAmount) {
    this.disbursementAmount = disbursementAmount;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The amount of the payment 
   * @return disbursementAmount
  **/
  @ApiModelProperty(example = "USD 250", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The amount of the payment ")


  public String getDisbursementAmount() {
    return disbursementAmount;
  }

  public void setDisbursementAmount(String disbursementAmount) {
    this.disbursementAmount = disbursementAmount;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementCurrency(String disbursementCurrency) {
    this.disbursementCurrency = disbursementCurrency;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Currency  general-info: The currency of the payment 
   * @return disbursementCurrency
  **/
  @ApiModelProperty(example = "USD", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Currency  general-info: The currency of the payment ")


  public String getDisbursementCurrency() {
    return disbursementCurrency;
  }

  public void setDisbursementCurrency(String disbursementCurrency) {
    this.disbursementCurrency = disbursementCurrency;
  }

  public BQDisbursementRetrieveOutputModelDisbursementInstanceRecord disbursementValueDate(String disbursementValueDate) {
    this.disbursementValueDate = disbursementValueDate;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The value date for the payment transaction 
   * @return disbursementValueDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::DateTime  general-info: The value date for the payment transaction ")


  public String getDisbursementValueDate() {
    return disbursementValueDate;
  }

  public void setDisbursementValueDate(String disbursementValueDate) {
    this.disbursementValueDate = disbursementValueDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQDisbursementRetrieveOutputModelDisbursementInstanceRecord bqDisbursementRetrieveOutputModelDisbursementInstanceRecord = (BQDisbursementRetrieveOutputModelDisbursementInstanceRecord) o;
    return Objects.equals(this.disbursementPayeeReference, bqDisbursementRetrieveOutputModelDisbursementInstanceRecord.disbursementPayeeReference) &&
        Objects.equals(this.disbursementPayeeProductInstanceReference, bqDisbursementRetrieveOutputModelDisbursementInstanceRecord.disbursementPayeeProductInstanceReference) &&
        Objects.equals(this.disbursementPayeeBankReference, bqDisbursementRetrieveOutputModelDisbursementInstanceRecord.disbursementPayeeBankReference) &&
        Objects.equals(this.disbursementAmount, bqDisbursementRetrieveOutputModelDisbursementInstanceRecord.disbursementAmount) &&
        Objects.equals(this.disbursementCurrency, bqDisbursementRetrieveOutputModelDisbursementInstanceRecord.disbursementCurrency) &&
        Objects.equals(this.disbursementValueDate, bqDisbursementRetrieveOutputModelDisbursementInstanceRecord.disbursementValueDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(disbursementPayeeReference, disbursementPayeeProductInstanceReference, disbursementPayeeBankReference, disbursementAmount, disbursementCurrency, disbursementValueDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQDisbursementRetrieveOutputModelDisbursementInstanceRecord {\n");
    
    sb.append("    disbursementPayeeReference: ").append(toIndentedString(disbursementPayeeReference)).append("\n");
    sb.append("    disbursementPayeeProductInstanceReference: ").append(toIndentedString(disbursementPayeeProductInstanceReference)).append("\n");
    sb.append("    disbursementPayeeBankReference: ").append(toIndentedString(disbursementPayeeBankReference)).append("\n");
    sb.append("    disbursementAmount: ").append(toIndentedString(disbursementAmount)).append("\n");
    sb.append("    disbursementCurrency: ").append(toIndentedString(disbursementCurrency)).append("\n");
    sb.append("    disbursementValueDate: ").append(toIndentedString(disbursementValueDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

