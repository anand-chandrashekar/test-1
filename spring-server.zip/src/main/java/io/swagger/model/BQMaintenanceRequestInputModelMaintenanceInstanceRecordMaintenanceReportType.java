package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType   {
  @JsonProperty("loanTaxReport")
  private Object loanTaxReport = null;

  @JsonProperty("loanFeeType")
  private String loanFeeType = null;

  @JsonProperty("loanFees")
  private String loanFees = null;

  @JsonProperty("penalties")
  private String penalties = null;

  @JsonProperty("collateralValuation")
  private String collateralValuation = null;

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType loanTaxReport(Object loanTaxReport) {
    this.loanTaxReport = loanTaxReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: A report summarizing tax considerations 
   * @return loanTaxReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: A report summarizing tax considerations ")


  public Object getLoanTaxReport() {
    return loanTaxReport;
  }

  public void setLoanTaxReport(Object loanTaxReport) {
    this.loanTaxReport = loanTaxReport;
  }

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType loanFeeType(String loanFeeType) {
    this.loanFeeType = loanFeeType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of fee applied 
   * @return loanFeeType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of fee applied ")


  public String getLoanFeeType() {
    return loanFeeType;
  }

  public void setLoanFeeType(String loanFeeType) {
    this.loanFeeType = loanFeeType;
  }

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType loanFees(String loanFees) {
    this.loanFees = loanFees;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.LoanAccount(as Account).Adjustment(as Charges) `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FMBK9sTGEeChad0JzLk7QA_-398781908  bian-reference: Loan.LoanAccount(as Account).Adjustment(as Charges)  general-info: A report detailing fees applied to the loan account (range of fees possible for different actions) 
   * @return loanFees
  **/
  @ApiModelProperty(value = "`status: Provisionally Registered`  bian-reference: Loan.LoanAccount(as Account).Adjustment(as Charges) `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FMBK9sTGEeChad0JzLk7QA_-398781908  bian-reference: Loan.LoanAccount(as Account).Adjustment(as Charges)  general-info: A report detailing fees applied to the loan account (range of fees possible for different actions) ")


  public String getLoanFees() {
    return loanFees;
  }

  public void setLoanFees(String loanFees) {
    this.loanFees = loanFees;
  }

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType penalties(String penalties) {
    this.penalties = penalties;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.LoanAccount(as Account).Adjustment (as Penalty) `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_eEiTMHRkEeKIFpWttHerUA_-261419352  bian-reference: Loan.LoanAccount(as Account).Adjustment (as Penalty)  general-info: A report detailing penalties incurred as booked against loan account 
   * @return penalties
  **/
  @ApiModelProperty(value = "`status: Provisionally Registered`  bian-reference: Loan.LoanAccount(as Account).Adjustment (as Penalty) `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_eEiTMHRkEeKIFpWttHerUA_-261419352  bian-reference: Loan.LoanAccount(as Account).Adjustment (as Penalty)  general-info: A report detailing penalties incurred as booked against loan account ")


  public String getPenalties() {
    return penalties;
  }

  public void setPenalties(String penalties) {
    this.penalties = penalties;
  }

  public BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType collateralValuation(String collateralValuation) {
    this.collateralValuation = collateralValuation;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FLlGEcTGEeChad0JzLk7QA_1826831344/elements/_AAYPOmIjEeGD28DQaMef-g  bian-reference: LoanAgreement(as MasterAgreement).GovernedContract(as CollateralAgreement).Collateral.Valuation  general-info: A report detailing the current applied collateral valuation (value confirmed as of date) 
   * @return collateralValuation
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FLlGEcTGEeChad0JzLk7QA_1826831344/elements/_AAYPOmIjEeGD28DQaMef-g  bian-reference: LoanAgreement(as MasterAgreement).GovernedContract(as CollateralAgreement).Collateral.Valuation  general-info: A report detailing the current applied collateral valuation (value confirmed as of date) ")


  public String getCollateralValuation() {
    return collateralValuation;
  }

  public void setCollateralValuation(String collateralValuation) {
    this.collateralValuation = collateralValuation;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType bqMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType = (BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType) o;
    return Objects.equals(this.loanTaxReport, bqMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType.loanTaxReport) &&
        Objects.equals(this.loanFeeType, bqMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType.loanFeeType) &&
        Objects.equals(this.loanFees, bqMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType.loanFees) &&
        Objects.equals(this.penalties, bqMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType.penalties) &&
        Objects.equals(this.collateralValuation, bqMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType.collateralValuation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(loanTaxReport, loanFeeType, loanFees, penalties, collateralValuation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQMaintenanceRequestInputModelMaintenanceInstanceRecordMaintenanceReportType {\n");
    
    sb.append("    loanTaxReport: ").append(toIndentedString(loanTaxReport)).append("\n");
    sb.append("    loanFeeType: ").append(toIndentedString(loanFeeType)).append("\n");
    sb.append("    loanFees: ").append(toIndentedString(loanFees)).append("\n");
    sb.append("    penalties: ").append(toIndentedString(penalties)).append("\n");
    sb.append("    collateralValuation: ").append(toIndentedString(collateralValuation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

