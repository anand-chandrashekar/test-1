package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQMaintenanceRequestInputModelRequestRecordType;
import io.swagger.model.BQRepaymentRequestInputModelRepaymentInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRequestInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRequestInputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("repaymentInstanceReference")
  private String repaymentInstanceReference = null;

  @JsonProperty("repaymentInstanceRecord")
  private BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentInstanceRecord = null;

  @JsonProperty("repaymentRequestActionTaskRecord")
  private Object repaymentRequestActionTaskRecord = null;

  @JsonProperty("requestRecordType")
  private BQMaintenanceRequestInputModelRequestRecordType requestRecordType = null;

  public BQRepaymentRequestInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR759135", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the parent Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public BQRepaymentRequestInputModel repaymentInstanceReference(String repaymentInstanceReference) {
    this.repaymentInstanceReference = repaymentInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment instance 
   * @return repaymentInstanceReference
  **/
  @ApiModelProperty(example = "RIR708353", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment instance ")


  public String getRepaymentInstanceReference() {
    return repaymentInstanceReference;
  }

  public void setRepaymentInstanceReference(String repaymentInstanceReference) {
    this.repaymentInstanceReference = repaymentInstanceReference;
  }

  public BQRepaymentRequestInputModel repaymentInstanceRecord(BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
    return this;
  }

  /**
   * Get repaymentInstanceRecord
   * @return repaymentInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRepaymentRequestInputModelRepaymentInstanceRecord getRepaymentInstanceRecord() {
    return repaymentInstanceRecord;
  }

  public void setRepaymentInstanceRecord(BQRepaymentRequestInputModelRepaymentInstanceRecord repaymentInstanceRecord) {
    this.repaymentInstanceRecord = repaymentInstanceRecord;
  }

  public BQRepaymentRequestInputModel repaymentRequestActionTaskRecord(Object repaymentRequestActionTaskRecord) {
    this.repaymentRequestActionTaskRecord = repaymentRequestActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record 
   * @return repaymentRequestActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The request service call consolidated processing record ")


  public Object getRepaymentRequestActionTaskRecord() {
    return repaymentRequestActionTaskRecord;
  }

  public void setRepaymentRequestActionTaskRecord(Object repaymentRequestActionTaskRecord) {
    this.repaymentRequestActionTaskRecord = repaymentRequestActionTaskRecord;
  }

  public BQRepaymentRequestInputModel requestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
    return this;
  }

  /**
   * Get requestRecordType
   * @return requestRecordType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQMaintenanceRequestInputModelRequestRecordType getRequestRecordType() {
    return requestRecordType;
  }

  public void setRequestRecordType(BQMaintenanceRequestInputModelRequestRecordType requestRecordType) {
    this.requestRecordType = requestRecordType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRequestInputModel bqRepaymentRequestInputModel = (BQRepaymentRequestInputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, bqRepaymentRequestInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.repaymentInstanceReference, bqRepaymentRequestInputModel.repaymentInstanceReference) &&
        Objects.equals(this.repaymentInstanceRecord, bqRepaymentRequestInputModel.repaymentInstanceRecord) &&
        Objects.equals(this.repaymentRequestActionTaskRecord, bqRepaymentRequestInputModel.repaymentRequestActionTaskRecord) &&
        Objects.equals(this.requestRecordType, bqRepaymentRequestInputModel.requestRecordType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceReference, repaymentInstanceReference, repaymentInstanceRecord, repaymentRequestActionTaskRecord, requestRecordType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRequestInputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    repaymentInstanceReference: ").append(toIndentedString(repaymentInstanceReference)).append("\n");
    sb.append("    repaymentInstanceRecord: ").append(toIndentedString(repaymentInstanceRecord)).append("\n");
    sb.append("    repaymentRequestActionTaskRecord: ").append(toIndentedString(repaymentRequestActionTaskRecord)).append("\n");
    sb.append("    requestRecordType: ").append(toIndentedString(requestRecordType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

