package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementUpdateInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementUpdateInputModel   {
  @JsonProperty("consumerLoanServicingSessionReference")
  private String consumerLoanServicingSessionReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private CRConsumerLoanFulfillmentArrangementUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementUpdateActionTaskRecord")
  private Object consumerLoanFulfillmentArrangementUpdateActionTaskRecord = null;

  @JsonProperty("updateActionRequest")
  private String updateActionRequest = null;

  public CRConsumerLoanFulfillmentArrangementUpdateInputModel consumerLoanServicingSessionReference(String consumerLoanServicingSessionReference) {
    this.consumerLoanServicingSessionReference = consumerLoanServicingSessionReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the active servicing session 
   * @return consumerLoanServicingSessionReference
  **/
  @ApiModelProperty(example = "CLSSR712509", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the active servicing session ")


  public String getConsumerLoanServicingSessionReference() {
    return consumerLoanServicingSessionReference;
  }

  public void setConsumerLoanServicingSessionReference(String consumerLoanServicingSessionReference) {
    this.consumerLoanServicingSessionReference = consumerLoanServicingSessionReference;
  }

  public CRConsumerLoanFulfillmentArrangementUpdateInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR737825", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public CRConsumerLoanFulfillmentArrangementUpdateInputModel consumerLoanFulfillmentArrangementInstanceRecord(CRConsumerLoanFulfillmentArrangementUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(CRConsumerLoanFulfillmentArrangementUpdateInputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public CRConsumerLoanFulfillmentArrangementUpdateInputModel consumerLoanFulfillmentArrangementUpdateActionTaskRecord(Object consumerLoanFulfillmentArrangementUpdateActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementUpdateActionTaskRecord = consumerLoanFulfillmentArrangementUpdateActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record 
   * @return consumerLoanFulfillmentArrangementUpdateActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The update service call consolidated processing record ")


  public Object getConsumerLoanFulfillmentArrangementUpdateActionTaskRecord() {
    return consumerLoanFulfillmentArrangementUpdateActionTaskRecord;
  }

  public void setConsumerLoanFulfillmentArrangementUpdateActionTaskRecord(Object consumerLoanFulfillmentArrangementUpdateActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementUpdateActionTaskRecord = consumerLoanFulfillmentArrangementUpdateActionTaskRecord;
  }

  public CRConsumerLoanFulfillmentArrangementUpdateInputModel updateActionRequest(String updateActionRequest) {
    this.updateActionRequest = updateActionRequest;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the update action service request 
   * @return updateActionRequest
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the update action service request ")


  public String getUpdateActionRequest() {
    return updateActionRequest;
  }

  public void setUpdateActionRequest(String updateActionRequest) {
    this.updateActionRequest = updateActionRequest;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementUpdateInputModel crConsumerLoanFulfillmentArrangementUpdateInputModel = (CRConsumerLoanFulfillmentArrangementUpdateInputModel) o;
    return Objects.equals(this.consumerLoanServicingSessionReference, crConsumerLoanFulfillmentArrangementUpdateInputModel.consumerLoanServicingSessionReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, crConsumerLoanFulfillmentArrangementUpdateInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, crConsumerLoanFulfillmentArrangementUpdateInputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementUpdateActionTaskRecord, crConsumerLoanFulfillmentArrangementUpdateInputModel.consumerLoanFulfillmentArrangementUpdateActionTaskRecord) &&
        Objects.equals(this.updateActionRequest, crConsumerLoanFulfillmentArrangementUpdateInputModel.updateActionRequest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanServicingSessionReference, consumerLoanFulfillmentArrangementInstanceReference, consumerLoanFulfillmentArrangementInstanceRecord, consumerLoanFulfillmentArrangementUpdateActionTaskRecord, updateActionRequest);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementUpdateInputModel {\n");
    
    sb.append("    consumerLoanServicingSessionReference: ").append(toIndentedString(consumerLoanServicingSessionReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementUpdateActionTaskRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementUpdateActionTaskRecord)).append("\n");
    sb.append("    updateActionRequest: ").append(toIndentedString(updateActionRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

