package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentExecuteOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentExecuteOutputModel   {
  @JsonProperty("repaymentExecuteActionTaskReference")
  private String repaymentExecuteActionTaskReference = null;

  @JsonProperty("repaymentExecuteActionTaskRecord")
  private Object repaymentExecuteActionTaskRecord = null;

  @JsonProperty("repaymentExecuteRecordReference")
  private String repaymentExecuteRecordReference = null;

  @JsonProperty("executeResponseRecord")
  private Object executeResponseRecord = null;

  public BQRepaymentExecuteOutputModel repaymentExecuteActionTaskReference(String repaymentExecuteActionTaskReference) {
    this.repaymentExecuteActionTaskReference = repaymentExecuteActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Repayment instance execute service call 
   * @return repaymentExecuteActionTaskReference
  **/
  @ApiModelProperty(example = "REATR734947", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Repayment instance execute service call ")


  public String getRepaymentExecuteActionTaskReference() {
    return repaymentExecuteActionTaskReference;
  }

  public void setRepaymentExecuteActionTaskReference(String repaymentExecuteActionTaskReference) {
    this.repaymentExecuteActionTaskReference = repaymentExecuteActionTaskReference;
  }

  public BQRepaymentExecuteOutputModel repaymentExecuteActionTaskRecord(Object repaymentExecuteActionTaskRecord) {
    this.repaymentExecuteActionTaskRecord = repaymentExecuteActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The execute service call consolidated processing record 
   * @return repaymentExecuteActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The execute service call consolidated processing record ")


  public Object getRepaymentExecuteActionTaskRecord() {
    return repaymentExecuteActionTaskRecord;
  }

  public void setRepaymentExecuteActionTaskRecord(Object repaymentExecuteActionTaskRecord) {
    this.repaymentExecuteActionTaskRecord = repaymentExecuteActionTaskRecord;
  }

  public BQRepaymentExecuteOutputModel repaymentExecuteRecordReference(String repaymentExecuteRecordReference) {
    this.repaymentExecuteRecordReference = repaymentExecuteRecordReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment execute transaction/record 
   * @return repaymentExecuteRecordReference
  **/
  @ApiModelProperty(example = "RERR718935", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Repayment execute transaction/record ")


  public String getRepaymentExecuteRecordReference() {
    return repaymentExecuteRecordReference;
  }

  public void setRepaymentExecuteRecordReference(String repaymentExecuteRecordReference) {
    this.repaymentExecuteRecordReference = repaymentExecuteRecordReference;
  }

  public BQRepaymentExecuteOutputModel executeResponseRecord(Object executeResponseRecord) {
    this.executeResponseRecord = executeResponseRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the execute action service response 
   * @return executeResponseRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: Details of the execute action service response ")


  public Object getExecuteResponseRecord() {
    return executeResponseRecord;
  }

  public void setExecuteResponseRecord(Object executeResponseRecord) {
    this.executeResponseRecord = executeResponseRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentExecuteOutputModel bqRepaymentExecuteOutputModel = (BQRepaymentExecuteOutputModel) o;
    return Objects.equals(this.repaymentExecuteActionTaskReference, bqRepaymentExecuteOutputModel.repaymentExecuteActionTaskReference) &&
        Objects.equals(this.repaymentExecuteActionTaskRecord, bqRepaymentExecuteOutputModel.repaymentExecuteActionTaskRecord) &&
        Objects.equals(this.repaymentExecuteRecordReference, bqRepaymentExecuteOutputModel.repaymentExecuteRecordReference) &&
        Objects.equals(this.executeResponseRecord, bqRepaymentExecuteOutputModel.executeResponseRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repaymentExecuteActionTaskReference, repaymentExecuteActionTaskRecord, repaymentExecuteRecordReference, executeResponseRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentExecuteOutputModel {\n");
    
    sb.append("    repaymentExecuteActionTaskReference: ").append(toIndentedString(repaymentExecuteActionTaskReference)).append("\n");
    sb.append("    repaymentExecuteActionTaskRecord: ").append(toIndentedString(repaymentExecuteActionTaskRecord)).append("\n");
    sb.append("    repaymentExecuteRecordReference: ").append(toIndentedString(repaymentExecuteRecordReference)).append("\n");
    sb.append("    executeResponseRecord: ").append(toIndentedString(executeResponseRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

