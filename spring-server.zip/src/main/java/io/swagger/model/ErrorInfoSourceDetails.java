package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * A set of data that helps identify the application that generated the error
 */
@ApiModel(description = "A set of data that helps identify the application that generated the error")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class ErrorInfoSourceDetails   {
  @JsonProperty("applicationId")
  private Integer applicationId = null;

  @JsonProperty("applicationName")
  private String applicationName = null;

  @JsonProperty("transactionName")
  private String transactionName = null;

  /**
   * Identifies the layer in the architecture that generated the error (API or back-end system).
   */
  public enum LayerEnum {
    SYSTEM_API("SYSTEM_API"),
    
    PROCESS_API("PROCESS_API"),
    
    EXPERIENCE_API("EXPERIENCE_API"),
    
    API("API"),
    
    BACKEND_SYSTEM("BACKEND_SYSTEM");

    private String value;

    LayerEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static LayerEnum fromValue(String text) {
      for (LayerEnum b : LayerEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  @JsonProperty("layer")
  private LayerEnum layer = null;

  public ErrorInfoSourceDetails applicationId(Integer applicationId) {
    this.applicationId = applicationId;
    return this;
  }

  /**
   * The instance Id of the back-end system that generated the error, e.g. 897707.
   * @return applicationId
  **/
  @ApiModelProperty(value = "The instance Id of the back-end system that generated the error, e.g. 897707.")


  public Integer getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(Integer applicationId) {
    this.applicationId = applicationId;
  }

  public ErrorInfoSourceDetails applicationName(String applicationName) {
    this.applicationName = applicationName;
    return this;
  }

  /**
   * The name of the application (API or back-end system) that generated the error.
   * @return applicationName
  **/
  @ApiModelProperty(required = true, value = "The name of the application (API or back-end system) that generated the error.")
  @NotNull


  public String getApplicationName() {
    return applicationName;
  }

  public void setApplicationName(String applicationName) {
    this.applicationName = applicationName;
  }

  public ErrorInfoSourceDetails transactionName(String transactionName) {
    this.transactionName = transactionName;
    return this;
  }

  /**
   * The name of the back-end transaction that generated the error.  Only relevant when a back-end system generates the error.
   * @return transactionName
  **/
  @ApiModelProperty(value = "The name of the back-end transaction that generated the error.  Only relevant when a back-end system generates the error.")


  public String getTransactionName() {
    return transactionName;
  }

  public void setTransactionName(String transactionName) {
    this.transactionName = transactionName;
  }

  public ErrorInfoSourceDetails layer(LayerEnum layer) {
    this.layer = layer;
    return this;
  }

  /**
   * Identifies the layer in the architecture that generated the error (API or back-end system).
   * @return layer
  **/
  @ApiModelProperty(required = true, value = "Identifies the layer in the architecture that generated the error (API or back-end system).")
  @NotNull


  public LayerEnum getLayer() {
    return layer;
  }

  public void setLayer(LayerEnum layer) {
    this.layer = layer;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorInfoSourceDetails errorInfoSourceDetails = (ErrorInfoSourceDetails) o;
    return Objects.equals(this.applicationId, errorInfoSourceDetails.applicationId) &&
        Objects.equals(this.applicationName, errorInfoSourceDetails.applicationName) &&
        Objects.equals(this.transactionName, errorInfoSourceDetails.transactionName) &&
        Objects.equals(this.layer, errorInfoSourceDetails.layer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(applicationId, applicationName, transactionName, layer);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorInfoSourceDetails {\n");
    
    sb.append("    applicationId: ").append(toIndentedString(applicationId)).append("\n");
    sb.append("    applicationName: ").append(toIndentedString(applicationName)).append("\n");
    sb.append("    transactionName: ").append(toIndentedString(transactionName)).append("\n");
    sb.append("    layer: ").append(toIndentedString(layer)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

