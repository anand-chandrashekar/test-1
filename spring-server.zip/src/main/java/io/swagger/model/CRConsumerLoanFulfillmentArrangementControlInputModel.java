package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementControlInputModelConsumerLoanFulfillmentArrangementControlActionRequest;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementControlInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementControlInputModel   {
  @JsonProperty("consumerLoanServicingSessionReference")
  private String consumerLoanServicingSessionReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReference")
  private String consumerLoanFulfillmentArrangementInstanceReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementControlActionTaskRecord")
  private Object consumerLoanFulfillmentArrangementControlActionTaskRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementControlActionRequest")
  private CRConsumerLoanFulfillmentArrangementControlInputModelConsumerLoanFulfillmentArrangementControlActionRequest consumerLoanFulfillmentArrangementControlActionRequest = null;

  public CRConsumerLoanFulfillmentArrangementControlInputModel consumerLoanServicingSessionReference(String consumerLoanServicingSessionReference) {
    this.consumerLoanServicingSessionReference = consumerLoanServicingSessionReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the active servicing session 
   * @return consumerLoanServicingSessionReference
  **/
  @ApiModelProperty(example = "CLSSR757591", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the active servicing session ")


  public String getConsumerLoanServicingSessionReference() {
    return consumerLoanServicingSessionReference;
  }

  public void setConsumerLoanServicingSessionReference(String consumerLoanServicingSessionReference) {
    this.consumerLoanServicingSessionReference = consumerLoanServicingSessionReference;
  }

  public CRConsumerLoanFulfillmentArrangementControlInputModel consumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Consumer Loan Fulfillment Arrangement instance 
   * @return consumerLoanFulfillmentArrangementInstanceReference
  **/
  @ApiModelProperty(example = "CLFAIR713755", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Consumer Loan Fulfillment Arrangement instance ")


  public String getConsumerLoanFulfillmentArrangementInstanceReference() {
    return consumerLoanFulfillmentArrangementInstanceReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReference(String consumerLoanFulfillmentArrangementInstanceReference) {
    this.consumerLoanFulfillmentArrangementInstanceReference = consumerLoanFulfillmentArrangementInstanceReference;
  }

  public CRConsumerLoanFulfillmentArrangementControlInputModel consumerLoanFulfillmentArrangementControlActionTaskRecord(Object consumerLoanFulfillmentArrangementControlActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementControlActionTaskRecord = consumerLoanFulfillmentArrangementControlActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The processing control service call consolidated processing record 
   * @return consumerLoanFulfillmentArrangementControlActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The processing control service call consolidated processing record ")


  public Object getConsumerLoanFulfillmentArrangementControlActionTaskRecord() {
    return consumerLoanFulfillmentArrangementControlActionTaskRecord;
  }

  public void setConsumerLoanFulfillmentArrangementControlActionTaskRecord(Object consumerLoanFulfillmentArrangementControlActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementControlActionTaskRecord = consumerLoanFulfillmentArrangementControlActionTaskRecord;
  }

  public CRConsumerLoanFulfillmentArrangementControlInputModel consumerLoanFulfillmentArrangementControlActionRequest(CRConsumerLoanFulfillmentArrangementControlInputModelConsumerLoanFulfillmentArrangementControlActionRequest consumerLoanFulfillmentArrangementControlActionRequest) {
    this.consumerLoanFulfillmentArrangementControlActionRequest = consumerLoanFulfillmentArrangementControlActionRequest;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementControlActionRequest
   * @return consumerLoanFulfillmentArrangementControlActionRequest
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementControlInputModelConsumerLoanFulfillmentArrangementControlActionRequest getConsumerLoanFulfillmentArrangementControlActionRequest() {
    return consumerLoanFulfillmentArrangementControlActionRequest;
  }

  public void setConsumerLoanFulfillmentArrangementControlActionRequest(CRConsumerLoanFulfillmentArrangementControlInputModelConsumerLoanFulfillmentArrangementControlActionRequest consumerLoanFulfillmentArrangementControlActionRequest) {
    this.consumerLoanFulfillmentArrangementControlActionRequest = consumerLoanFulfillmentArrangementControlActionRequest;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementControlInputModel crConsumerLoanFulfillmentArrangementControlInputModel = (CRConsumerLoanFulfillmentArrangementControlInputModel) o;
    return Objects.equals(this.consumerLoanServicingSessionReference, crConsumerLoanFulfillmentArrangementControlInputModel.consumerLoanServicingSessionReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReference, crConsumerLoanFulfillmentArrangementControlInputModel.consumerLoanFulfillmentArrangementInstanceReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementControlActionTaskRecord, crConsumerLoanFulfillmentArrangementControlInputModel.consumerLoanFulfillmentArrangementControlActionTaskRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementControlActionRequest, crConsumerLoanFulfillmentArrangementControlInputModel.consumerLoanFulfillmentArrangementControlActionRequest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanServicingSessionReference, consumerLoanFulfillmentArrangementInstanceReference, consumerLoanFulfillmentArrangementControlActionTaskRecord, consumerLoanFulfillmentArrangementControlActionRequest);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementControlInputModel {\n");
    
    sb.append("    consumerLoanServicingSessionReference: ").append(toIndentedString(consumerLoanServicingSessionReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementControlActionTaskRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementControlActionTaskRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementControlActionRequest: ").append(toIndentedString(consumerLoanFulfillmentArrangementControlActionRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

