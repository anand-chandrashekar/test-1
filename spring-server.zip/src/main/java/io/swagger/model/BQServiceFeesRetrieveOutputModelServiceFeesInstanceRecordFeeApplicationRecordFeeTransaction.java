package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction   {
  @JsonProperty("transactionDescription")
  private String transactionDescription = null;

  @JsonProperty("transactionFeeType")
  private String transactionFeeType = null;

  @JsonProperty("transactionFeeCharge")
  private String transactionFeeCharge = null;

  public BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction transactionDescription(String transactionDescription) {
    this.transactionDescription = transactionDescription;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: General description of the fee or penalty transaction 
   * @return transactionDescription
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: General description of the fee or penalty transaction ")


  public String getTransactionDescription() {
    return transactionDescription;
  }

  public void setTransactionDescription(String transactionDescription) {
    this.transactionDescription = transactionDescription;
  }

  public BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction transactionFeeType(String transactionFeeType) {
    this.transactionFeeType = transactionFeeType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The fee or penalty type applied 
   * @return transactionFeeType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The fee or penalty type applied ")


  public String getTransactionFeeType() {
    return transactionFeeType;
  }

  public void setTransactionFeeType(String transactionFeeType) {
    this.transactionFeeType = transactionFeeType;
  }

  public BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction transactionFeeCharge(String transactionFeeCharge) {
    this.transactionFeeCharge = transactionFeeCharge;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The derived fee or penalty amount applied 
   * @return transactionFeeCharge
  **/
  @ApiModelProperty(example = "USD 250", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Amount  general-info: The derived fee or penalty amount applied ")


  public String getTransactionFeeCharge() {
    return transactionFeeCharge;
  }

  public void setTransactionFeeCharge(String transactionFeeCharge) {
    this.transactionFeeCharge = transactionFeeCharge;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction bqServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction = (BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction) o;
    return Objects.equals(this.transactionDescription, bqServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction.transactionDescription) &&
        Objects.equals(this.transactionFeeType, bqServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction.transactionFeeType) &&
        Objects.equals(this.transactionFeeCharge, bqServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction.transactionFeeCharge);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactionDescription, transactionFeeType, transactionFeeCharge);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQServiceFeesRetrieveOutputModelServiceFeesInstanceRecordFeeApplicationRecordFeeTransaction {\n");
    
    sb.append("    transactionDescription: ").append(toIndentedString(transactionDescription)).append("\n");
    sb.append("    transactionFeeType: ").append(toIndentedString(transactionFeeType)).append("\n");
    sb.append("    transactionFeeCharge: ").append(toIndentedString(transactionFeeCharge)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

