package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile   {
  @JsonProperty("feeType")
  private String feeType = null;

  public BQServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile feeType(String feeType) {
    this.feeType = feeType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The fee or penalty type applied 
   * @return feeType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The fee or penalty type applied ")


  public String getFeeType() {
    return feeType;
  }

  public void setFeeType(String feeType) {
    this.feeType = feeType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile bqServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile = (BQServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile) o;
    return Objects.equals(this.feeType, bqServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile.feeType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(feeType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQServiceFeesExecuteInputModelServiceFeesInstanceRecordFeeConfigurationProfile {\n");
    
    sb.append("    feeType: ").append(toIndentedString(feeType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

