package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord   {
  @JsonProperty("productInstanceReference")
  private String productInstanceReference = null;

  @JsonProperty("consumerLoanNumber")
  private String consumerLoanNumber = null;

  @JsonProperty("customerReference")
  private String customerReference = null;

  @JsonProperty("partyReference")
  private String partyReference = null;

  @JsonProperty("customerAgreementReference")
  private String customerAgreementReference = null;

  @JsonProperty("customerCreditAssessmentReference")
  private String customerCreditAssessmentReference = null;

  @JsonProperty("insuranceReference")
  private String insuranceReference = null;

  @JsonProperty("delinquencyCollectionReference")
  private String delinquencyCollectionReference = null;

  @JsonProperty("bankBranchLocationReference")
  private String bankBranchLocationReference = null;

  @JsonProperty("bankAccountingUnitReference")
  private String bankAccountingUnitReference = null;

  @JsonProperty("loanType")
  private String loanType = null;

  @JsonProperty("loanAmount")
  private String loanAmount = null;

  @JsonProperty("loanCurrency")
  private String loanCurrency = null;

  @JsonProperty("loanRateType")
  private String loanRateType = null;

  @JsonProperty("loanApplicableRate")
  private String loanApplicableRate = null;

  @JsonProperty("repaymentType")
  private String repaymentType = null;

  @JsonProperty("interestType")
  private String interestType = null;

  @JsonProperty("interestAccrualMethod")
  private String interestAccrualMethod = null;

  @JsonProperty("loanOriginationDate")
  private String loanOriginationDate = null;

  @JsonProperty("loanMaturityDate")
  private String loanMaturityDate = null;

  @JsonProperty("collateralReference")
  private String collateralReference = null;

  @JsonProperty("collateralAllocation")
  private String collateralAllocation = null;

  @JsonProperty("taxReference")
  private String taxReference = null;

  @JsonProperty("loanAccessTerms")
  private String loanAccessTerms = null;

  @JsonProperty("entitlementOptionDefinition")
  private String entitlementOptionDefinition = null;

  @JsonProperty("entitlementOptionSetting")
  private String entitlementOptionSetting = null;

  @JsonProperty("restrictionOptionDefinition")
  private String restrictionOptionDefinition = null;

  @JsonProperty("restrictionOptionSetting")
  private String restrictionOptionSetting = null;

  @JsonProperty("associations")
  private CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations associations = null;

  @JsonProperty("loanRepaymentSchedule")
  private String loanRepaymentSchedule = null;

  @JsonProperty("stagedRepaymentStatement")
  private String stagedRepaymentStatement = null;

  @JsonProperty("customerCommentary")
  private String customerCommentary = null;

  @JsonProperty("loanOutstandingBalance")
  private String loanOutstandingBalance = null;

  @JsonProperty("dateType")
  private CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType = null;

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord productInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance 
   * @return productInstanceReference
  **/
  @ApiModelProperty(example = "787535", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance ")


  public String getProductInstanceReference() {
    return productInstanceReference;
  }

  public void setProductInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format 
   * @return consumerLoanNumber
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format ")


  public String getConsumerLoanNumber() {
    return consumerLoanNumber;
  }

  public void setConsumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerReference(String customerReference) {
    this.customerReference = customerReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner 
   * @return customerReference
  **/
  @ApiModelProperty(example = "739115", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner ")


  public String getCustomerReference() {
    return customerReference;
  }

  public void setCustomerReference(String customerReference) {
    this.customerReference = customerReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord partyReference(String partyReference) {
    this.partyReference = partyReference;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Party).AccountableParty  general-info: The legal entity reference for the borrower, likely to be the same as customer 
   * @return partyReference
  **/
  @ApiModelProperty(example = "708755", value = "`status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Party).AccountableParty  general-info: The legal entity reference for the borrower, likely to be the same as customer ")


  public String getPartyReference() {
    return partyReference;
  }

  public void setPartyReference(String partyReference) {
    this.partyReference = partyReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerAgreementReference(String customerAgreementReference) {
    this.customerAgreementReference = customerAgreementReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the associated customer agreement 
   * @return customerAgreementReference
  **/
  @ApiModelProperty(example = "777496", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the associated customer agreement ")


  public String getCustomerAgreementReference() {
    return customerAgreementReference;
  }

  public void setCustomerAgreementReference(String customerAgreementReference) {
    this.customerAgreementReference = customerAgreementReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerCreditAssessmentReference(String customerCreditAssessmentReference) {
    this.customerCreditAssessmentReference = customerCreditAssessmentReference;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.CreditCheck  general-info: Reference to an associated credit assessment 
   * @return customerCreditAssessmentReference
  **/
  @ApiModelProperty(example = "713628", value = "`status: Provisionally Registered`  bian-reference: Loan.CreditCheck  general-info: Reference to an associated credit assessment ")


  public String getCustomerCreditAssessmentReference() {
    return customerCreditAssessmentReference;
  }

  public void setCustomerCreditAssessmentReference(String customerCreditAssessmentReference) {
    this.customerCreditAssessmentReference = customerCreditAssessmentReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord insuranceReference(String insuranceReference) {
    this.insuranceReference = insuranceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to applicable insurance arrangements 
   * @return insuranceReference
  **/
  @ApiModelProperty(example = "718877", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to applicable insurance arrangements ")


  public String getInsuranceReference() {
    return insuranceReference;
  }

  public void setInsuranceReference(String insuranceReference) {
    this.insuranceReference = insuranceReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord delinquencyCollectionReference(String delinquencyCollectionReference) {
    this.delinquencyCollectionReference = delinquencyCollectionReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to collections/delinquency processing made against the loan 
   * @return delinquencyCollectionReference
  **/
  @ApiModelProperty(example = "734161", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to collections/delinquency processing made against the loan ")


  public String getDelinquencyCollectionReference() {
    return delinquencyCollectionReference;
  }

  public void setDelinquencyCollectionReference(String delinquencyCollectionReference) {
    this.delinquencyCollectionReference = delinquencyCollectionReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord bankBranchLocationReference(String bankBranchLocationReference) {
    this.bankBranchLocationReference = bankBranchLocationReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633/elements/_z2I6YGx5EeKmZJ0Ago--9g_239738909  bian-reference: LoanAgreement.TradePartyRole(as Lender)(as Role).Player(as Party).Location  general-info: Bank branch associated with the account for booking purposes 
   * @return bankBranchLocationReference
  **/
  @ApiModelProperty(example = "754492", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633/elements/_z2I6YGx5EeKmZJ0Ago--9g_239738909  bian-reference: LoanAgreement.TradePartyRole(as Lender)(as Role).Player(as Party).Location  general-info: Bank branch associated with the account for booking purposes ")


  public String getBankBranchLocationReference() {
    return bankBranchLocationReference;
  }

  public void setBankBranchLocationReference(String bankBranchLocationReference) {
    this.bankBranchLocationReference = bankBranchLocationReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord bankAccountingUnitReference(String bankAccountingUnitReference) {
    this.bankAccountingUnitReference = bankAccountingUnitReference;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Organisation).BusinessUnit  general-info: Bank accounting unit associated with the account for booking purposes 
   * @return bankAccountingUnitReference
  **/
  @ApiModelProperty(example = "705364", value = "`status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Organisation).BusinessUnit  general-info: Bank accounting unit associated with the account for booking purposes ")


  public String getBankAccountingUnitReference() {
    return bankAccountingUnitReference;
  }

  public void setBankAccountingUnitReference(String bankAccountingUnitReference) {
    this.bankAccountingUnitReference = bankAccountingUnitReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanType(String loanType) {
    this.loanType = loanType;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.LoanType  general-info: The specific type of loan (e.g. term, revolving, evergreen) 
   * @return loanType
  **/
  @ApiModelProperty(value = "`status: Provisionally Registered`  bian-reference: Loan.LoanType  general-info: The specific type of loan (e.g. term, revolving, evergreen) ")


  public String getLoanType() {
    return loanType;
  }

  public void setLoanType(String loanType) {
    this.loanType = loanType;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanAmount(String loanAmount) {
    this.loanAmount = loanAmount;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount  general-info: The amount of the loan 
   * @return loanAmount
  **/
  @ApiModelProperty(example = "USD 250", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount  general-info: The amount of the loan ")


  public String getLoanAmount() {
    return loanAmount;
  }

  public void setLoanAmount(String loanAmount) {
    this.loanAmount = loanAmount;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanCurrency(String loanCurrency) {
    this.loanCurrency = loanCurrency;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_X0hLUKRMEeO1ke9HGqKZhg  bian-reference: Loan(as Debt).PaymentCurrency  general-info: The currency for the loan account 
   * @return loanCurrency
  **/
  @ApiModelProperty(example = "USD", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FepzGcTGEeChad0JzLk7QA_298530288  bian-reference: Loan(as Asset).InvestmentAmount `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_X0hLUKRMEeO1ke9HGqKZhg  bian-reference: Loan(as Debt).PaymentCurrency  general-info: The currency for the loan account ")


  public String getLoanCurrency() {
    return loanCurrency;
  }

  public void setLoanCurrency(String loanCurrency) {
    this.loanCurrency = loanCurrency;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanRateType(String loanRateType) {
    this.loanRateType = loanRateType;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Fd5lKcTGEeChad0JzLk7QA_-958104524/elements/_FeNHIMTGEeChad0JzLk7QA_-12422289  bian-reference: Loan(as Debt).NextInterest.VariableInterest.VariableRateChangeFrequency  general-info: The rate type to be applied to the loan 
   * @return loanRateType
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Fd5lKcTGEeChad0JzLk7QA_-958104524/elements/_FeNHIMTGEeChad0JzLk7QA_-12422289  bian-reference: Loan(as Debt).NextInterest.VariableInterest.VariableRateChangeFrequency  general-info: The rate type to be applied to the loan ")


  public String getLoanRateType() {
    return loanRateType;
  }

  public void setLoanRateType(String loanRateType) {
    this.loanRateType = loanRateType;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanApplicableRate(String loanApplicableRate) {
    this.loanApplicableRate = loanApplicableRate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FXWRMsTGEeChad0JzLk7QA_-398781879/elements/_FXgCNMTGEeChad0JzLk7QA_-129916673  bian-reference: Loan(as Debt).NextInterest.VariableInterest  general-info: The applicable rate for the loan 
   * @return loanApplicableRate
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FXWRMsTGEeChad0JzLk7QA_-398781879/elements/_FXgCNMTGEeChad0JzLk7QA_-129916673  bian-reference: Loan(as Debt).NextInterest.VariableInterest  general-info: The applicable rate for the loan ")


  public String getLoanApplicableRate() {
    return loanApplicableRate;
  }

  public void setLoanApplicableRate(String loanApplicableRate) {
    this.loanApplicableRate = loanApplicableRate;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord repaymentType(String repaymentType) {
    this.repaymentType = repaymentType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment arrangement in place (e.g. structured) 
   * @return repaymentType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment arrangement in place (e.g. structured) ")


  public String getRepaymentType() {
    return repaymentType;
  }

  public void setRepaymentType(String repaymentType) {
    this.repaymentType = repaymentType;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord interestType(String interestType) {
    this.interestType = interestType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of interest to be applied (e.g. prime plus) 
   * @return interestType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of interest to be applied (e.g. prime plus) ")


  public String getInterestType() {
    return interestType;
  }

  public void setInterestType(String interestType) {
    this.interestType = interestType;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord interestAccrualMethod(String interestAccrualMethod) {
    this.interestAccrualMethod = interestAccrualMethod;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The accrual method applied to interest calculations 
   * @return interestAccrualMethod
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The accrual method applied to interest calculations ")


  public String getInterestAccrualMethod() {
    return interestAccrualMethod;
  }

  public void setInterestAccrualMethod(String interestAccrualMethod) {
    this.interestAccrualMethod = interestAccrualMethod;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOriginationDate(String loanOriginationDate) {
    this.loanOriginationDate = loanOriginationDate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_Fey9AMTGEeChad0JzLk7QA_300376414  bian-reference: Loan(as Asset).EffectiveDate  general-info: The origination date for the loan 
   * @return loanOriginationDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_Fey9AMTGEeChad0JzLk7QA_300376414  bian-reference: Loan(as Asset).EffectiveDate  general-info: The origination date for the loan ")


  public String getLoanOriginationDate() {
    return loanOriginationDate;
  }

  public void setLoanOriginationDate(String loanOriginationDate) {
    this.loanOriginationDate = loanOriginationDate;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanMaturityDate(String loanMaturityDate) {
    this.loanMaturityDate = loanMaturityDate;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FP5lYcTGEeChad0JzLk7QA_-943816417  bian-reference: Loan(as Asset).MaturityDate  general-info: The planned maturity date of the loan 
   * @return loanMaturityDate
  **/
  @ApiModelProperty(example = "09-22-2018", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FPv0acTGEeChad0JzLk7QA_-150026816/elements/_FP5lYcTGEeChad0JzLk7QA_-943816417  bian-reference: Loan(as Asset).MaturityDate  general-info: The planned maturity date of the loan ")


  public String getLoanMaturityDate() {
    return loanMaturityDate;
  }

  public void setLoanMaturityDate(String loanMaturityDate) {
    this.loanMaturityDate = loanMaturityDate;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord collateralReference(String collateralReference) {
    this.collateralReference = collateralReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E6vNtsTGEeChad0JzLk7QA_393174175/elements/_lrcFQC1hEeGp2Zpvgj9Dtw_-638405304  bian-reference: LoanAgreement(as MasterAgreement).CollateralAgreement.Collateral  general-info: Reference to allocated collateral 
   * @return collateralReference
  **/
  @ApiModelProperty(example = "779767", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E6vNtsTGEeChad0JzLk7QA_393174175/elements/_lrcFQC1hEeGp2Zpvgj9Dtw_-638405304  bian-reference: LoanAgreement(as MasterAgreement).CollateralAgreement.Collateral  general-info: Reference to allocated collateral ")


  public String getCollateralReference() {
    return collateralReference;
  }

  public void setCollateralReference(String collateralReference) {
    this.collateralReference = collateralReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord collateralAllocation(String collateralAllocation) {
    this.collateralAllocation = collateralAllocation;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FLlGEcTGEeChad0JzLk7QA_1826831344/elements/_AAYPOmIjEeGD28DQaMef-g  bian-reference: LoanAgreement(as MasterAgreement).CollateralAgreement.Collateral.Valuation  general-info: The collateral value applied to the loan 
   * @return collateralAllocation
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FLlGEcTGEeChad0JzLk7QA_1826831344/elements/_AAYPOmIjEeGD28DQaMef-g  bian-reference: LoanAgreement(as MasterAgreement).CollateralAgreement.Collateral.Valuation  general-info: The collateral value applied to the loan ")


  public String getCollateralAllocation() {
    return collateralAllocation;
  }

  public void setCollateralAllocation(String collateralAllocation) {
    this.collateralAllocation = collateralAllocation;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord taxReference(String taxReference) {
    this.taxReference = taxReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FEHzNMTGEeChad0JzLk7QA_-1382123937/elements/_FEHzNcTGEeChad0JzLk7QA_-1792766550  bian-reference: LoanAgreement.TradePartyRole(as Borrower).Player(as Party).Identification.TaxIdentificationNumber  general-info: Reference identifier linking the account to appropriate tax handling 
   * @return taxReference
  **/
  @ApiModelProperty(example = "721038", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FEHzNMTGEeChad0JzLk7QA_-1382123937/elements/_FEHzNcTGEeChad0JzLk7QA_-1792766550  bian-reference: LoanAgreement.TradePartyRole(as Borrower).Player(as Party).Identification.TaxIdentificationNumber  general-info: Reference identifier linking the account to appropriate tax handling ")


  public String getTaxReference() {
    return taxReference;
  }

  public void setTaxReference(String taxReference) {
    this.taxReference = taxReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanAccessTerms(String loanAccessTerms) {
    this.loanAccessTerms = loanAccessTerms;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.Limit `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_Fg4nt8TGEeChad0JzLk7QA_742037711  bian-reference: Loan(as Debt).PrePaymentSpeed  general-info: Access terms that apply (e.g. allowed payments/withdrawals) 
   * @return loanAccessTerms
  **/
  @ApiModelProperty(value = "`status: Provisionally Registered`  bian-reference: Loan.Limit `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_Fg4nt8TGEeChad0JzLk7QA_742037711  bian-reference: Loan(as Debt).PrePaymentSpeed  general-info: Access terms that apply (e.g. allowed payments/withdrawals) ")


  public String getLoanAccessTerms() {
    return loanAccessTerms;
  }

  public void setLoanAccessTerms(String loanAccessTerms) {
    this.loanAccessTerms = loanAccessTerms;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord entitlementOptionDefinition(String entitlementOptionDefinition) {
    this.entitlementOptionDefinition = entitlementOptionDefinition;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable entitlement option 
   * @return entitlementOptionDefinition
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable entitlement option ")


  public String getEntitlementOptionDefinition() {
    return entitlementOptionDefinition;
  }

  public void setEntitlementOptionDefinition(String entitlementOptionDefinition) {
    this.entitlementOptionDefinition = entitlementOptionDefinition;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord entitlementOptionSetting(String entitlementOptionSetting) {
    this.entitlementOptionSetting = entitlementOptionSetting;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the entitlement option 
   * @return entitlementOptionSetting
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the entitlement option ")


  public String getEntitlementOptionSetting() {
    return entitlementOptionSetting;
  }

  public void setEntitlementOptionSetting(String entitlementOptionSetting) {
    this.entitlementOptionSetting = entitlementOptionSetting;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord restrictionOptionDefinition(String restrictionOptionDefinition) {
    this.restrictionOptionDefinition = restrictionOptionDefinition;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable restriction option 
   * @return restrictionOptionDefinition
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable restriction option ")


  public String getRestrictionOptionDefinition() {
    return restrictionOptionDefinition;
  }

  public void setRestrictionOptionDefinition(String restrictionOptionDefinition) {
    this.restrictionOptionDefinition = restrictionOptionDefinition;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord restrictionOptionSetting(String restrictionOptionSetting) {
    this.restrictionOptionSetting = restrictionOptionSetting;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the restriction option 
   * @return restrictionOptionSetting
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the restriction option ")


  public String getRestrictionOptionSetting() {
    return restrictionOptionSetting;
  }

  public void setRestrictionOptionSetting(String restrictionOptionSetting) {
    this.restrictionOptionSetting = restrictionOptionSetting;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord associations(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations associations) {
    this.associations = associations;
    return this;
  }

  /**
   * Get associations
   * @return associations
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations getAssociations() {
    return associations;
  }

  public void setAssociations(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecordAssociations associations) {
    this.associations = associations;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanRepaymentSchedule(String loanRepaymentSchedule) {
    this.loanRepaymentSchedule = loanRepaymentSchedule;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_jF5agJh7EeOUgsYi4EbJBw/elements/_AcedgZh9EeORjJTqwAvaiQ  bian-reference: Loan.InterestPaymentsSchedule.PaymentPeriod `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_jF5agJh7EeOUgsYi4EbJBw/elements/_AcedgZh9EeORjJTqwAvaiQ  bian-reference: Loan.PrincipalPaymentsSchedule.PaymentPeriod  general-info: The schedule for loan repayments 
   * @return loanRepaymentSchedule
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_jF5agJh7EeOUgsYi4EbJBw/elements/_AcedgZh9EeORjJTqwAvaiQ  bian-reference: Loan.InterestPaymentsSchedule.PaymentPeriod `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_jF5agJh7EeOUgsYi4EbJBw/elements/_AcedgZh9EeORjJTqwAvaiQ  bian-reference: Loan.PrincipalPaymentsSchedule.PaymentPeriod  general-info: The schedule for loan repayments ")


  public String getLoanRepaymentSchedule() {
    return loanRepaymentSchedule;
  }

  public void setLoanRepaymentSchedule(String loanRepaymentSchedule) {
    this.loanRepaymentSchedule = loanRepaymentSchedule;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord stagedRepaymentStatement(String stagedRepaymentStatement) {
    this.stagedRepaymentStatement = stagedRepaymentStatement;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FDPCYMTGEeChad0JzLk7QA_-1131921749/elements/_FDPCacTGEeChad0JzLk7QA_-72272631  bian-reference: Loan.InterestPaymentsSchedule.RelatedPaymentObligation.PaymentOffset `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FDPCYMTGEeChad0JzLk7QA_-1131921749/elements/_FDPCacTGEeChad0JzLk7QA_-72272632  bian-reference: Loan.PrincipalPaymentsSchedule.RelatedPaymentObligation.PaymentOffset  general-info: A statement maintained tracking repayments 
   * @return stagedRepaymentStatement
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FDPCYMTGEeChad0JzLk7QA_-1131921749/elements/_FDPCacTGEeChad0JzLk7QA_-72272631  bian-reference: Loan.InterestPaymentsSchedule.RelatedPaymentObligation.PaymentOffset `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FDPCYMTGEeChad0JzLk7QA_-1131921749/elements/_FDPCacTGEeChad0JzLk7QA_-72272632  bian-reference: Loan.PrincipalPaymentsSchedule.RelatedPaymentObligation.PaymentOffset  general-info: A statement maintained tracking repayments ")


  public String getStagedRepaymentStatement() {
    return stagedRepaymentStatement;
  }

  public void setStagedRepaymentStatement(String stagedRepaymentStatement) {
    this.stagedRepaymentStatement = stagedRepaymentStatement;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerCommentary(String customerCommentary) {
    this.customerCommentary = customerCommentary;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: A record of customer correspondence/feedback 
   * @return customerCommentary
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: A record of customer correspondence/feedback ")


  public String getCustomerCommentary() {
    return customerCommentary;
  }

  public void setCustomerCommentary(String customerCommentary) {
    this.customerCommentary = customerCommentary;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance 
   * @return loanOutstandingBalance
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance ")


  public String getLoanOutstandingBalance() {
    return loanOutstandingBalance;
  }

  public void setLoanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord dateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
    return this;
  }

  /**
   * Get dateType
   * @return dateType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType getDateType() {
    return dateType;
  }

  public void setDateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord = (CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord) o;
    return Objects.equals(this.productInstanceReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.productInstanceReference) &&
        Objects.equals(this.consumerLoanNumber, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.consumerLoanNumber) &&
        Objects.equals(this.customerReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerReference) &&
        Objects.equals(this.partyReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.partyReference) &&
        Objects.equals(this.customerAgreementReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerAgreementReference) &&
        Objects.equals(this.customerCreditAssessmentReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerCreditAssessmentReference) &&
        Objects.equals(this.insuranceReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.insuranceReference) &&
        Objects.equals(this.delinquencyCollectionReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.delinquencyCollectionReference) &&
        Objects.equals(this.bankBranchLocationReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.bankBranchLocationReference) &&
        Objects.equals(this.bankAccountingUnitReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.bankAccountingUnitReference) &&
        Objects.equals(this.loanType, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanType) &&
        Objects.equals(this.loanAmount, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanAmount) &&
        Objects.equals(this.loanCurrency, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanCurrency) &&
        Objects.equals(this.loanRateType, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanRateType) &&
        Objects.equals(this.loanApplicableRate, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanApplicableRate) &&
        Objects.equals(this.repaymentType, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.repaymentType) &&
        Objects.equals(this.interestType, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.interestType) &&
        Objects.equals(this.interestAccrualMethod, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.interestAccrualMethod) &&
        Objects.equals(this.loanOriginationDate, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOriginationDate) &&
        Objects.equals(this.loanMaturityDate, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanMaturityDate) &&
        Objects.equals(this.collateralReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.collateralReference) &&
        Objects.equals(this.collateralAllocation, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.collateralAllocation) &&
        Objects.equals(this.taxReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.taxReference) &&
        Objects.equals(this.loanAccessTerms, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanAccessTerms) &&
        Objects.equals(this.entitlementOptionDefinition, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.entitlementOptionDefinition) &&
        Objects.equals(this.entitlementOptionSetting, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.entitlementOptionSetting) &&
        Objects.equals(this.restrictionOptionDefinition, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.restrictionOptionDefinition) &&
        Objects.equals(this.restrictionOptionSetting, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.restrictionOptionSetting) &&
        Objects.equals(this.associations, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.associations) &&
        Objects.equals(this.loanRepaymentSchedule, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanRepaymentSchedule) &&
        Objects.equals(this.stagedRepaymentStatement, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.stagedRepaymentStatement) &&
        Objects.equals(this.customerCommentary, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerCommentary) &&
        Objects.equals(this.loanOutstandingBalance, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOutstandingBalance) &&
        Objects.equals(this.dateType, crConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.dateType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productInstanceReference, consumerLoanNumber, customerReference, partyReference, customerAgreementReference, customerCreditAssessmentReference, insuranceReference, delinquencyCollectionReference, bankBranchLocationReference, bankAccountingUnitReference, loanType, loanAmount, loanCurrency, loanRateType, loanApplicableRate, repaymentType, interestType, interestAccrualMethod, loanOriginationDate, loanMaturityDate, collateralReference, collateralAllocation, taxReference, loanAccessTerms, entitlementOptionDefinition, entitlementOptionSetting, restrictionOptionDefinition, restrictionOptionSetting, associations, loanRepaymentSchedule, stagedRepaymentStatement, customerCommentary, loanOutstandingBalance, dateType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord {\n");
    
    sb.append("    productInstanceReference: ").append(toIndentedString(productInstanceReference)).append("\n");
    sb.append("    consumerLoanNumber: ").append(toIndentedString(consumerLoanNumber)).append("\n");
    sb.append("    customerReference: ").append(toIndentedString(customerReference)).append("\n");
    sb.append("    partyReference: ").append(toIndentedString(partyReference)).append("\n");
    sb.append("    customerAgreementReference: ").append(toIndentedString(customerAgreementReference)).append("\n");
    sb.append("    customerCreditAssessmentReference: ").append(toIndentedString(customerCreditAssessmentReference)).append("\n");
    sb.append("    insuranceReference: ").append(toIndentedString(insuranceReference)).append("\n");
    sb.append("    delinquencyCollectionReference: ").append(toIndentedString(delinquencyCollectionReference)).append("\n");
    sb.append("    bankBranchLocationReference: ").append(toIndentedString(bankBranchLocationReference)).append("\n");
    sb.append("    bankAccountingUnitReference: ").append(toIndentedString(bankAccountingUnitReference)).append("\n");
    sb.append("    loanType: ").append(toIndentedString(loanType)).append("\n");
    sb.append("    loanAmount: ").append(toIndentedString(loanAmount)).append("\n");
    sb.append("    loanCurrency: ").append(toIndentedString(loanCurrency)).append("\n");
    sb.append("    loanRateType: ").append(toIndentedString(loanRateType)).append("\n");
    sb.append("    loanApplicableRate: ").append(toIndentedString(loanApplicableRate)).append("\n");
    sb.append("    repaymentType: ").append(toIndentedString(repaymentType)).append("\n");
    sb.append("    interestType: ").append(toIndentedString(interestType)).append("\n");
    sb.append("    interestAccrualMethod: ").append(toIndentedString(interestAccrualMethod)).append("\n");
    sb.append("    loanOriginationDate: ").append(toIndentedString(loanOriginationDate)).append("\n");
    sb.append("    loanMaturityDate: ").append(toIndentedString(loanMaturityDate)).append("\n");
    sb.append("    collateralReference: ").append(toIndentedString(collateralReference)).append("\n");
    sb.append("    collateralAllocation: ").append(toIndentedString(collateralAllocation)).append("\n");
    sb.append("    taxReference: ").append(toIndentedString(taxReference)).append("\n");
    sb.append("    loanAccessTerms: ").append(toIndentedString(loanAccessTerms)).append("\n");
    sb.append("    entitlementOptionDefinition: ").append(toIndentedString(entitlementOptionDefinition)).append("\n");
    sb.append("    entitlementOptionSetting: ").append(toIndentedString(entitlementOptionSetting)).append("\n");
    sb.append("    restrictionOptionDefinition: ").append(toIndentedString(restrictionOptionDefinition)).append("\n");
    sb.append("    restrictionOptionSetting: ").append(toIndentedString(restrictionOptionSetting)).append("\n");
    sb.append("    associations: ").append(toIndentedString(associations)).append("\n");
    sb.append("    loanRepaymentSchedule: ").append(toIndentedString(loanRepaymentSchedule)).append("\n");
    sb.append("    stagedRepaymentStatement: ").append(toIndentedString(stagedRepaymentStatement)).append("\n");
    sb.append("    customerCommentary: ").append(toIndentedString(customerCommentary)).append("\n");
    sb.append("    loanOutstandingBalance: ").append(toIndentedString(loanOutstandingBalance)).append("\n");
    sb.append("    dateType: ").append(toIndentedString(dateType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

