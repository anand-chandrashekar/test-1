package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceAnalysis;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementRetrieveActionTaskReference")
  private String consumerLoanFulfillmentArrangementRetrieveActionTaskReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementRetrieveActionTaskRecord")
  private Object consumerLoanFulfillmentArrangementRetrieveActionTaskRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementRetrieveActionResponse")
  private String consumerLoanFulfillmentArrangementRetrieveActionResponse = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceReportRecord")
  private CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportRecord = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceAnalysis")
  private CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysis = null;

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModel consumerLoanFulfillmentArrangementRetrieveActionTaskReference(String consumerLoanFulfillmentArrangementRetrieveActionTaskReference) {
    this.consumerLoanFulfillmentArrangementRetrieveActionTaskReference = consumerLoanFulfillmentArrangementRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Consumer Loan Fulfillment Arrangement instance retrieve service call 
   * @return consumerLoanFulfillmentArrangementRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "CLFARATR751295", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Consumer Loan Fulfillment Arrangement instance retrieve service call ")


  public String getConsumerLoanFulfillmentArrangementRetrieveActionTaskReference() {
    return consumerLoanFulfillmentArrangementRetrieveActionTaskReference;
  }

  public void setConsumerLoanFulfillmentArrangementRetrieveActionTaskReference(String consumerLoanFulfillmentArrangementRetrieveActionTaskReference) {
    this.consumerLoanFulfillmentArrangementRetrieveActionTaskReference = consumerLoanFulfillmentArrangementRetrieveActionTaskReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModel consumerLoanFulfillmentArrangementRetrieveActionTaskRecord(Object consumerLoanFulfillmentArrangementRetrieveActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord = consumerLoanFulfillmentArrangementRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return consumerLoanFulfillmentArrangementRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getConsumerLoanFulfillmentArrangementRetrieveActionTaskRecord() {
    return consumerLoanFulfillmentArrangementRetrieveActionTaskRecord;
  }

  public void setConsumerLoanFulfillmentArrangementRetrieveActionTaskRecord(Object consumerLoanFulfillmentArrangementRetrieveActionTaskRecord) {
    this.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord = consumerLoanFulfillmentArrangementRetrieveActionTaskRecord;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModel consumerLoanFulfillmentArrangementRetrieveActionResponse(String consumerLoanFulfillmentArrangementRetrieveActionResponse) {
    this.consumerLoanFulfillmentArrangementRetrieveActionResponse = consumerLoanFulfillmentArrangementRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return consumerLoanFulfillmentArrangementRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getConsumerLoanFulfillmentArrangementRetrieveActionResponse() {
    return consumerLoanFulfillmentArrangementRetrieveActionResponse;
  }

  public void setConsumerLoanFulfillmentArrangementRetrieveActionResponse(String consumerLoanFulfillmentArrangementRetrieveActionResponse) {
    this.consumerLoanFulfillmentArrangementRetrieveActionResponse = consumerLoanFulfillmentArrangementRetrieveActionResponse;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceReportRecord(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportRecord) {
    this.consumerLoanFulfillmentArrangementInstanceReportRecord = consumerLoanFulfillmentArrangementInstanceReportRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceReportRecord
   * @return consumerLoanFulfillmentArrangementInstanceReportRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord getConsumerLoanFulfillmentArrangementInstanceReportRecord() {
    return consumerLoanFulfillmentArrangementInstanceReportRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceReportRecord(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceReportRecord consumerLoanFulfillmentArrangementInstanceReportRecord) {
    this.consumerLoanFulfillmentArrangementInstanceReportRecord = consumerLoanFulfillmentArrangementInstanceReportRecord;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceAnalysis(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysis) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysis = consumerLoanFulfillmentArrangementInstanceAnalysis;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceAnalysis
   * @return consumerLoanFulfillmentArrangementInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceAnalysis getConsumerLoanFulfillmentArrangementInstanceAnalysis() {
    return consumerLoanFulfillmentArrangementInstanceAnalysis;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceAnalysis(CRConsumerLoanFulfillmentArrangementRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysis) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysis = consumerLoanFulfillmentArrangementInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementRetrieveOutputModel crConsumerLoanFulfillmentArrangementRetrieveOutputModel = (CRConsumerLoanFulfillmentArrangementRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, crConsumerLoanFulfillmentArrangementRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementRetrieveActionTaskReference, crConsumerLoanFulfillmentArrangementRetrieveOutputModel.consumerLoanFulfillmentArrangementRetrieveActionTaskReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord, crConsumerLoanFulfillmentArrangementRetrieveOutputModel.consumerLoanFulfillmentArrangementRetrieveActionTaskRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementRetrieveActionResponse, crConsumerLoanFulfillmentArrangementRetrieveOutputModel.consumerLoanFulfillmentArrangementRetrieveActionResponse) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceReportRecord, crConsumerLoanFulfillmentArrangementRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceReportRecord) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceAnalysis, crConsumerLoanFulfillmentArrangementRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, consumerLoanFulfillmentArrangementRetrieveActionTaskReference, consumerLoanFulfillmentArrangementRetrieveActionTaskRecord, consumerLoanFulfillmentArrangementRetrieveActionResponse, consumerLoanFulfillmentArrangementInstanceReportRecord, consumerLoanFulfillmentArrangementInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementRetrieveActionTaskReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementRetrieveActionTaskReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementRetrieveActionTaskRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementRetrieveActionTaskRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementRetrieveActionResponse: ").append(toIndentedString(consumerLoanFulfillmentArrangementRetrieveActionResponse)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceReportRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceReportRecord)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceAnalysis: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

