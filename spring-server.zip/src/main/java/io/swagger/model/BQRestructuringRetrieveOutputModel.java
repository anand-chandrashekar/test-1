package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRestructuringInitiateOutputModelRestructuringInstanceRecord;
import io.swagger.model.BQRestructuringRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis;
import io.swagger.model.BQRestructuringRetrieveOutputModelRestructuringInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringRetrieveOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringRetrieveOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQRestructuringRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("restructuringInstanceRecord")
  private BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord = null;

  @JsonProperty("restructuringRetrieveActionTaskReference")
  private String restructuringRetrieveActionTaskReference = null;

  @JsonProperty("restructuringRetrieveActionTaskRecord")
  private Object restructuringRetrieveActionTaskRecord = null;

  @JsonProperty("restructuringRetrieveActionResponse")
  private String restructuringRetrieveActionResponse = null;

  @JsonProperty("restructuringInstanceReport")
  private BQRestructuringRetrieveOutputModelRestructuringInstanceReport restructuringInstanceReport = null;

  @JsonProperty("restructuringInstanceAnalysis")
  private BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis restructuringInstanceAnalysis = null;

  public BQRestructuringRetrieveOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQRestructuringRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQRestructuringRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQRestructuringRetrieveOutputModel restructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
    return this;
  }

  /**
   * Get restructuringInstanceRecord
   * @return restructuringInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringInitiateOutputModelRestructuringInstanceRecord getRestructuringInstanceRecord() {
    return restructuringInstanceRecord;
  }

  public void setRestructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
  }

  public BQRestructuringRetrieveOutputModel restructuringRetrieveActionTaskReference(String restructuringRetrieveActionTaskReference) {
    this.restructuringRetrieveActionTaskReference = restructuringRetrieveActionTaskReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Restructuring instance retrieve service call 
   * @return restructuringRetrieveActionTaskReference
  **/
  @ApiModelProperty(example = "RRATR798316", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to a Restructuring instance retrieve service call ")


  public String getRestructuringRetrieveActionTaskReference() {
    return restructuringRetrieveActionTaskReference;
  }

  public void setRestructuringRetrieveActionTaskReference(String restructuringRetrieveActionTaskReference) {
    this.restructuringRetrieveActionTaskReference = restructuringRetrieveActionTaskReference;
  }

  public BQRestructuringRetrieveOutputModel restructuringRetrieveActionTaskRecord(Object restructuringRetrieveActionTaskRecord) {
    this.restructuringRetrieveActionTaskRecord = restructuringRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return restructuringRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getRestructuringRetrieveActionTaskRecord() {
    return restructuringRetrieveActionTaskRecord;
  }

  public void setRestructuringRetrieveActionTaskRecord(Object restructuringRetrieveActionTaskRecord) {
    this.restructuringRetrieveActionTaskRecord = restructuringRetrieveActionTaskRecord;
  }

  public BQRestructuringRetrieveOutputModel restructuringRetrieveActionResponse(String restructuringRetrieveActionResponse) {
    this.restructuringRetrieveActionResponse = restructuringRetrieveActionResponse;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) 
   * @return restructuringRetrieveActionResponse
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service response (lists returned reports) ")


  public String getRestructuringRetrieveActionResponse() {
    return restructuringRetrieveActionResponse;
  }

  public void setRestructuringRetrieveActionResponse(String restructuringRetrieveActionResponse) {
    this.restructuringRetrieveActionResponse = restructuringRetrieveActionResponse;
  }

  public BQRestructuringRetrieveOutputModel restructuringInstanceReport(BQRestructuringRetrieveOutputModelRestructuringInstanceReport restructuringInstanceReport) {
    this.restructuringInstanceReport = restructuringInstanceReport;
    return this;
  }

  /**
   * Get restructuringInstanceReport
   * @return restructuringInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringRetrieveOutputModelRestructuringInstanceReport getRestructuringInstanceReport() {
    return restructuringInstanceReport;
  }

  public void setRestructuringInstanceReport(BQRestructuringRetrieveOutputModelRestructuringInstanceReport restructuringInstanceReport) {
    this.restructuringInstanceReport = restructuringInstanceReport;
  }

  public BQRestructuringRetrieveOutputModel restructuringInstanceAnalysis(BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis restructuringInstanceAnalysis) {
    this.restructuringInstanceAnalysis = restructuringInstanceAnalysis;
    return this;
  }

  /**
   * Get restructuringInstanceAnalysis
   * @return restructuringInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis getRestructuringInstanceAnalysis() {
    return restructuringInstanceAnalysis;
  }

  public void setRestructuringInstanceAnalysis(BQRestructuringRetrieveOutputModelRestructuringInstanceAnalysis restructuringInstanceAnalysis) {
    this.restructuringInstanceAnalysis = restructuringInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringRetrieveOutputModel bqRestructuringRetrieveOutputModel = (BQRestructuringRetrieveOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqRestructuringRetrieveOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.restructuringInstanceRecord, bqRestructuringRetrieveOutputModel.restructuringInstanceRecord) &&
        Objects.equals(this.restructuringRetrieveActionTaskReference, bqRestructuringRetrieveOutputModel.restructuringRetrieveActionTaskReference) &&
        Objects.equals(this.restructuringRetrieveActionTaskRecord, bqRestructuringRetrieveOutputModel.restructuringRetrieveActionTaskRecord) &&
        Objects.equals(this.restructuringRetrieveActionResponse, bqRestructuringRetrieveOutputModel.restructuringRetrieveActionResponse) &&
        Objects.equals(this.restructuringInstanceReport, bqRestructuringRetrieveOutputModel.restructuringInstanceReport) &&
        Objects.equals(this.restructuringInstanceAnalysis, bqRestructuringRetrieveOutputModel.restructuringInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, restructuringInstanceRecord, restructuringRetrieveActionTaskReference, restructuringRetrieveActionTaskRecord, restructuringRetrieveActionResponse, restructuringInstanceReport, restructuringInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringRetrieveOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    restructuringInstanceRecord: ").append(toIndentedString(restructuringInstanceRecord)).append("\n");
    sb.append("    restructuringRetrieveActionTaskReference: ").append(toIndentedString(restructuringRetrieveActionTaskReference)).append("\n");
    sb.append("    restructuringRetrieveActionTaskRecord: ").append(toIndentedString(restructuringRetrieveActionTaskRecord)).append("\n");
    sb.append("    restructuringRetrieveActionResponse: ").append(toIndentedString(restructuringRetrieveActionResponse)).append("\n");
    sb.append("    restructuringInstanceReport: ").append(toIndentedString(restructuringInstanceReport)).append("\n");
    sb.append("    restructuringInstanceAnalysis: ").append(toIndentedString(restructuringInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

