package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQRestructuringInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord;
import io.swagger.model.BQRestructuringInitiateOutputModelRestructuringInstanceRecord;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRestructuringInitiateOutputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRestructuringInitiateOutputModel   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceRecord")
  private BQRestructuringInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord = null;

  @JsonProperty("restructuringInstanceReference")
  private String restructuringInstanceReference = null;

  @JsonProperty("restructuringInitiateActionReference")
  private String restructuringInitiateActionReference = null;

  @JsonProperty("restructuringInitiateActionRecord")
  private Object restructuringInitiateActionRecord = null;

  @JsonProperty("restructuringInstanceStatus")
  private String restructuringInstanceStatus = null;

  @JsonProperty("restructuringInstanceRecord")
  private BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord = null;

  public BQRestructuringInitiateOutputModel consumerLoanFulfillmentArrangementInstanceRecord(BQRestructuringInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
    return this;
  }

  /**
   * Get consumerLoanFulfillmentArrangementInstanceRecord
   * @return consumerLoanFulfillmentArrangementInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord getConsumerLoanFulfillmentArrangementInstanceRecord() {
    return consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceRecord(BQRestructuringInitiateOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanFulfillmentArrangementInstanceRecord) {
    this.consumerLoanFulfillmentArrangementInstanceRecord = consumerLoanFulfillmentArrangementInstanceRecord;
  }

  public BQRestructuringInitiateOutputModel restructuringInstanceReference(String restructuringInstanceReference) {
    this.restructuringInstanceReference = restructuringInstanceReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring instance 
   * @return restructuringInstanceReference
  **/
  @ApiModelProperty(example = "RIR731688", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the Restructuring instance ")


  public String getRestructuringInstanceReference() {
    return restructuringInstanceReference;
  }

  public void setRestructuringInstanceReference(String restructuringInstanceReference) {
    this.restructuringInstanceReference = restructuringInstanceReference;
  }

  public BQRestructuringInitiateOutputModel restructuringInitiateActionReference(String restructuringInitiateActionReference) {
    this.restructuringInitiateActionReference = restructuringInitiateActionReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an Initiate service call 
   * @return restructuringInitiateActionReference
  **/
  @ApiModelProperty(example = "RIAR737902", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to an Initiate service call ")


  public String getRestructuringInitiateActionReference() {
    return restructuringInitiateActionReference;
  }

  public void setRestructuringInitiateActionReference(String restructuringInitiateActionReference) {
    this.restructuringInitiateActionReference = restructuringInitiateActionReference;
  }

  public BQRestructuringInitiateOutputModel restructuringInitiateActionRecord(Object restructuringInitiateActionRecord) {
    this.restructuringInitiateActionRecord = restructuringInitiateActionRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The Initiate service call input and output record 
   * @return restructuringInitiateActionRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The Initiate service call input and output record ")


  public Object getRestructuringInitiateActionRecord() {
    return restructuringInitiateActionRecord;
  }

  public void setRestructuringInitiateActionRecord(Object restructuringInitiateActionRecord) {
    this.restructuringInitiateActionRecord = restructuringInitiateActionRecord;
  }

  public BQRestructuringInitiateOutputModel restructuringInstanceStatus(String restructuringInstanceStatus) {
    this.restructuringInstanceStatus = restructuringInstanceStatus;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The status of the Restructuring instance (e.g. initialised, pending, active) 
   * @return restructuringInstanceStatus
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The status of the Restructuring instance (e.g. initialised, pending, active) ")


  public String getRestructuringInstanceStatus() {
    return restructuringInstanceStatus;
  }

  public void setRestructuringInstanceStatus(String restructuringInstanceStatus) {
    this.restructuringInstanceStatus = restructuringInstanceStatus;
  }

  public BQRestructuringInitiateOutputModel restructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
    return this;
  }

  /**
   * Get restructuringInstanceRecord
   * @return restructuringInstanceRecord
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQRestructuringInitiateOutputModelRestructuringInstanceRecord getRestructuringInstanceRecord() {
    return restructuringInstanceRecord;
  }

  public void setRestructuringInstanceRecord(BQRestructuringInitiateOutputModelRestructuringInstanceRecord restructuringInstanceRecord) {
    this.restructuringInstanceRecord = restructuringInstanceRecord;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRestructuringInitiateOutputModel bqRestructuringInitiateOutputModel = (BQRestructuringInitiateOutputModel) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceRecord, bqRestructuringInitiateOutputModel.consumerLoanFulfillmentArrangementInstanceRecord) &&
        Objects.equals(this.restructuringInstanceReference, bqRestructuringInitiateOutputModel.restructuringInstanceReference) &&
        Objects.equals(this.restructuringInitiateActionReference, bqRestructuringInitiateOutputModel.restructuringInitiateActionReference) &&
        Objects.equals(this.restructuringInitiateActionRecord, bqRestructuringInitiateOutputModel.restructuringInitiateActionRecord) &&
        Objects.equals(this.restructuringInstanceStatus, bqRestructuringInitiateOutputModel.restructuringInstanceStatus) &&
        Objects.equals(this.restructuringInstanceRecord, bqRestructuringInitiateOutputModel.restructuringInstanceRecord);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceRecord, restructuringInstanceReference, restructuringInitiateActionReference, restructuringInitiateActionRecord, restructuringInstanceStatus, restructuringInstanceRecord);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRestructuringInitiateOutputModel {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceRecord: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceRecord)).append("\n");
    sb.append("    restructuringInstanceReference: ").append(toIndentedString(restructuringInstanceReference)).append("\n");
    sb.append("    restructuringInitiateActionReference: ").append(toIndentedString(restructuringInitiateActionReference)).append("\n");
    sb.append("    restructuringInitiateActionRecord: ").append(toIndentedString(restructuringInitiateActionRecord)).append("\n");
    sb.append("    restructuringInstanceStatus: ").append(toIndentedString(restructuringInstanceStatus)).append("\n");
    sb.append("    restructuringInstanceRecord: ").append(toIndentedString(restructuringInstanceRecord)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

