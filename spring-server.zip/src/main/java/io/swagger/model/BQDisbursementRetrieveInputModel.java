package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.BQDisbursementRetrieveInputModelDisbursementInstanceAnalysis;
import io.swagger.model.BQDisbursementRetrieveInputModelDisbursementInstanceReport;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQDisbursementRetrieveInputModel
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQDisbursementRetrieveInputModel   {
  @JsonProperty("disbursementRetrieveActionTaskRecord")
  private Object disbursementRetrieveActionTaskRecord = null;

  @JsonProperty("disbursementRetrieveActionRequest")
  private String disbursementRetrieveActionRequest = null;

  @JsonProperty("disbursementInstanceReport")
  private BQDisbursementRetrieveInputModelDisbursementInstanceReport disbursementInstanceReport = null;

  @JsonProperty("disbursementInstanceAnalysis")
  private BQDisbursementRetrieveInputModelDisbursementInstanceAnalysis disbursementInstanceAnalysis = null;

  public BQDisbursementRetrieveInputModel disbursementRetrieveActionTaskRecord(Object disbursementRetrieveActionTaskRecord) {
    this.disbursementRetrieveActionTaskRecord = disbursementRetrieveActionTaskRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record 
   * @return disbursementRetrieveActionTaskRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The retrieve service call consolidated processing record ")


  public Object getDisbursementRetrieveActionTaskRecord() {
    return disbursementRetrieveActionTaskRecord;
  }

  public void setDisbursementRetrieveActionTaskRecord(Object disbursementRetrieveActionTaskRecord) {
    this.disbursementRetrieveActionTaskRecord = disbursementRetrieveActionTaskRecord;
  }

  public BQDisbursementRetrieveInputModel disbursementRetrieveActionRequest(String disbursementRetrieveActionRequest) {
    this.disbursementRetrieveActionRequest = disbursementRetrieveActionRequest;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) 
   * @return disbursementRetrieveActionRequest
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: Details of the retrieve action service request (lists requested reports) ")


  public String getDisbursementRetrieveActionRequest() {
    return disbursementRetrieveActionRequest;
  }

  public void setDisbursementRetrieveActionRequest(String disbursementRetrieveActionRequest) {
    this.disbursementRetrieveActionRequest = disbursementRetrieveActionRequest;
  }

  public BQDisbursementRetrieveInputModel disbursementInstanceReport(BQDisbursementRetrieveInputModelDisbursementInstanceReport disbursementInstanceReport) {
    this.disbursementInstanceReport = disbursementInstanceReport;
    return this;
  }

  /**
   * Get disbursementInstanceReport
   * @return disbursementInstanceReport
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQDisbursementRetrieveInputModelDisbursementInstanceReport getDisbursementInstanceReport() {
    return disbursementInstanceReport;
  }

  public void setDisbursementInstanceReport(BQDisbursementRetrieveInputModelDisbursementInstanceReport disbursementInstanceReport) {
    this.disbursementInstanceReport = disbursementInstanceReport;
  }

  public BQDisbursementRetrieveInputModel disbursementInstanceAnalysis(BQDisbursementRetrieveInputModelDisbursementInstanceAnalysis disbursementInstanceAnalysis) {
    this.disbursementInstanceAnalysis = disbursementInstanceAnalysis;
    return this;
  }

  /**
   * Get disbursementInstanceAnalysis
   * @return disbursementInstanceAnalysis
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BQDisbursementRetrieveInputModelDisbursementInstanceAnalysis getDisbursementInstanceAnalysis() {
    return disbursementInstanceAnalysis;
  }

  public void setDisbursementInstanceAnalysis(BQDisbursementRetrieveInputModelDisbursementInstanceAnalysis disbursementInstanceAnalysis) {
    this.disbursementInstanceAnalysis = disbursementInstanceAnalysis;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQDisbursementRetrieveInputModel bqDisbursementRetrieveInputModel = (BQDisbursementRetrieveInputModel) o;
    return Objects.equals(this.disbursementRetrieveActionTaskRecord, bqDisbursementRetrieveInputModel.disbursementRetrieveActionTaskRecord) &&
        Objects.equals(this.disbursementRetrieveActionRequest, bqDisbursementRetrieveInputModel.disbursementRetrieveActionRequest) &&
        Objects.equals(this.disbursementInstanceReport, bqDisbursementRetrieveInputModel.disbursementInstanceReport) &&
        Objects.equals(this.disbursementInstanceAnalysis, bqDisbursementRetrieveInputModel.disbursementInstanceAnalysis);
  }

  @Override
  public int hashCode() {
    return Objects.hash(disbursementRetrieveActionTaskRecord, disbursementRetrieveActionRequest, disbursementInstanceReport, disbursementInstanceAnalysis);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQDisbursementRetrieveInputModel {\n");
    
    sb.append("    disbursementRetrieveActionTaskRecord: ").append(toIndentedString(disbursementRetrieveActionTaskRecord)).append("\n");
    sb.append("    disbursementRetrieveActionRequest: ").append(toIndentedString(disbursementRetrieveActionRequest)).append("\n");
    sb.append("    disbursementInstanceReport: ").append(toIndentedString(disbursementInstanceReport)).append("\n");
    sb.append("    disbursementInstanceAnalysis: ").append(toIndentedString(disbursementInstanceAnalysis)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

