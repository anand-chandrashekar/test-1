package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord   {
  @JsonProperty("productInstanceReference")
  private String productInstanceReference = null;

  @JsonProperty("consumerLoanNumber")
  private String consumerLoanNumber = null;

  @JsonProperty("customerReference")
  private String customerReference = null;

  @JsonProperty("partyReference")
  private String partyReference = null;

  @JsonProperty("repaymentType")
  private String repaymentType = null;

  @JsonProperty("loanAccessTerms")
  private String loanAccessTerms = null;

  @JsonProperty("entitlementOptionDefinition")
  private String entitlementOptionDefinition = null;

  @JsonProperty("entitlementOptionSetting")
  private String entitlementOptionSetting = null;

  @JsonProperty("restrictionOptionDefinition")
  private String restrictionOptionDefinition = null;

  @JsonProperty("restrictionOptionSetting")
  private String restrictionOptionSetting = null;

  @JsonProperty("loanOutstandingBalance")
  private String loanOutstandingBalance = null;

  @JsonProperty("dateType")
  private CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType = null;

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord productInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance 
   * @return productInstanceReference
  **/
  @ApiModelProperty(example = "726045", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_E1rHgsTGEeChad0JzLk7QA_-1068889728/elements/_E1rHhcTGEeChad0JzLk7QA_-755813725  bian-reference: Loan.LoanAccount(as Account).Identification  general-info: Reference to the loan product instance ")


  public String getProductInstanceReference() {
    return productInstanceReference;
  }

  public void setProductInstanceReference(String productInstanceReference) {
    this.productInstanceReference = productInstanceReference;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord consumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format 
   * @return consumerLoanNumber
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The associated loan account number in any suitable format ")


  public String getConsumerLoanNumber() {
    return consumerLoanNumber;
  }

  public void setConsumerLoanNumber(String consumerLoanNumber) {
    this.consumerLoanNumber = consumerLoanNumber;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord customerReference(String customerReference) {
    this.customerReference = customerReference;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner 
   * @return customerReference
  **/
  @ApiModelProperty(example = "721269", value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_FNqJt8TGEeChad0JzLk7QA_-1317971633  bian-reference: Loan.Agreement.TradePartyRole(as Borrower)(as Role).Player(as Party)  general-info: Reference to the account primary party/owner ")


  public String getCustomerReference() {
    return customerReference;
  }

  public void setCustomerReference(String customerReference) {
    this.customerReference = customerReference;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord partyReference(String partyReference) {
    this.partyReference = partyReference;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Party).AccountableParty  general-info: The legal entity reference for the borrower, likely to be the same as customer 
   * @return partyReference
  **/
  @ApiModelProperty(example = "729022", value = "`status: Provisionally Registered`  bian-reference: LoanAgreement.TradePartyRole(as Borrower)(as Role).Player(as Party).AccountableParty  general-info: The legal entity reference for the borrower, likely to be the same as customer ")


  public String getPartyReference() {
    return partyReference;
  }

  public void setPartyReference(String partyReference) {
    this.partyReference = partyReference;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord repaymentType(String repaymentType) {
    this.repaymentType = repaymentType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment arrangement in place (e.g. structured) 
   * @return repaymentType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The type of repayment arrangement in place (e.g. structured) ")


  public String getRepaymentType() {
    return repaymentType;
  }

  public void setRepaymentType(String repaymentType) {
    this.repaymentType = repaymentType;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanAccessTerms(String loanAccessTerms) {
    this.loanAccessTerms = loanAccessTerms;
    return this;
  }

  /**
   * `status: Provisionally Registered`  bian-reference: Loan.Limit `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_Fg4nt8TGEeChad0JzLk7QA_742037711  bian-reference: Loan(as Debt).PrePaymentSpeed  general-info: Access terms that apply (e.g. allowed payments/withdrawals) 
   * @return loanAccessTerms
  **/
  @ApiModelProperty(value = "`status: Provisionally Registered`  bian-reference: Loan.Limit `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_Ff_P1MTGEeChad0JzLk7QA_-1514166912/elements/_Fg4nt8TGEeChad0JzLk7QA_742037711  bian-reference: Loan(as Debt).PrePaymentSpeed  general-info: Access terms that apply (e.g. allowed payments/withdrawals) ")


  public String getLoanAccessTerms() {
    return loanAccessTerms;
  }

  public void setLoanAccessTerms(String loanAccessTerms) {
    this.loanAccessTerms = loanAccessTerms;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord entitlementOptionDefinition(String entitlementOptionDefinition) {
    this.entitlementOptionDefinition = entitlementOptionDefinition;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable entitlement option 
   * @return entitlementOptionDefinition
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable entitlement option ")


  public String getEntitlementOptionDefinition() {
    return entitlementOptionDefinition;
  }

  public void setEntitlementOptionDefinition(String entitlementOptionDefinition) {
    this.entitlementOptionDefinition = entitlementOptionDefinition;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord entitlementOptionSetting(String entitlementOptionSetting) {
    this.entitlementOptionSetting = entitlementOptionSetting;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the entitlement option 
   * @return entitlementOptionSetting
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the entitlement option ")


  public String getEntitlementOptionSetting() {
    return entitlementOptionSetting;
  }

  public void setEntitlementOptionSetting(String entitlementOptionSetting) {
    this.entitlementOptionSetting = entitlementOptionSetting;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord restrictionOptionDefinition(String restrictionOptionDefinition) {
    this.restrictionOptionDefinition = restrictionOptionDefinition;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable restriction option 
   * @return restrictionOptionDefinition
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The definition of an applicable restriction option ")


  public String getRestrictionOptionDefinition() {
    return restrictionOptionDefinition;
  }

  public void setRestrictionOptionDefinition(String restrictionOptionDefinition) {
    this.restrictionOptionDefinition = restrictionOptionDefinition;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord restrictionOptionSetting(String restrictionOptionSetting) {
    this.restrictionOptionSetting = restrictionOptionSetting;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the restriction option 
   * @return restrictionOptionSetting
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The setting for the restriction option ")


  public String getRestrictionOptionSetting() {
    return restrictionOptionSetting;
  }

  public void setRestrictionOptionSetting(String restrictionOptionSetting) {
    this.restrictionOptionSetting = restrictionOptionSetting;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord loanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
    return this;
  }

  /**
   * `status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance 
   * @return loanOutstandingBalance
  **/
  @ApiModelProperty(value = "`status: Registered`  iso-link: https://www.iso20022.org/standardsrepository/public/wqt/Description/mx/dico/bc/_mw1ysHJTEeWwf47VrwMaTQ/elements/_QLjLYHJUEeWwf47VrwMaTQ  bian-reference: Loan.PrincipalAmount  general-info: The outstanding balance ")


  public String getLoanOutstandingBalance() {
    return loanOutstandingBalance;
  }

  public void setLoanOutstandingBalance(String loanOutstandingBalance) {
    this.loanOutstandingBalance = loanOutstandingBalance;
  }

  public BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord dateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
    return this;
  }

  /**
   * Get dateType
   * @return dateType
  **/
  @ApiModelProperty(value = "")

  @Valid

  public CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType getDateType() {
    return dateType;
  }

  public void setDateType(CRConsumerLoanFulfillmentArrangementInitiateInputModelConsumerLoanFulfillmentArrangementInstanceRecordDateType dateType) {
    this.dateType = dateType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord = (BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord) o;
    return Objects.equals(this.productInstanceReference, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.productInstanceReference) &&
        Objects.equals(this.consumerLoanNumber, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.consumerLoanNumber) &&
        Objects.equals(this.customerReference, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.customerReference) &&
        Objects.equals(this.partyReference, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.partyReference) &&
        Objects.equals(this.repaymentType, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.repaymentType) &&
        Objects.equals(this.loanAccessTerms, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanAccessTerms) &&
        Objects.equals(this.entitlementOptionDefinition, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.entitlementOptionDefinition) &&
        Objects.equals(this.entitlementOptionSetting, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.entitlementOptionSetting) &&
        Objects.equals(this.restrictionOptionDefinition, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.restrictionOptionDefinition) &&
        Objects.equals(this.restrictionOptionSetting, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.restrictionOptionSetting) &&
        Objects.equals(this.loanOutstandingBalance, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.loanOutstandingBalance) &&
        Objects.equals(this.dateType, bqRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord.dateType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productInstanceReference, consumerLoanNumber, customerReference, partyReference, repaymentType, loanAccessTerms, entitlementOptionDefinition, entitlementOptionSetting, restrictionOptionDefinition, restrictionOptionSetting, loanOutstandingBalance, dateType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQRepaymentRetrieveOutputModelConsumerLoanFulfillmentArrangementInstanceRecord {\n");
    
    sb.append("    productInstanceReference: ").append(toIndentedString(productInstanceReference)).append("\n");
    sb.append("    consumerLoanNumber: ").append(toIndentedString(consumerLoanNumber)).append("\n");
    sb.append("    customerReference: ").append(toIndentedString(customerReference)).append("\n");
    sb.append("    partyReference: ").append(toIndentedString(partyReference)).append("\n");
    sb.append("    repaymentType: ").append(toIndentedString(repaymentType)).append("\n");
    sb.append("    loanAccessTerms: ").append(toIndentedString(loanAccessTerms)).append("\n");
    sb.append("    entitlementOptionDefinition: ").append(toIndentedString(entitlementOptionDefinition)).append("\n");
    sb.append("    entitlementOptionSetting: ").append(toIndentedString(entitlementOptionSetting)).append("\n");
    sb.append("    restrictionOptionDefinition: ").append(toIndentedString(restrictionOptionDefinition)).append("\n");
    sb.append("    restrictionOptionSetting: ").append(toIndentedString(restrictionOptionSetting)).append("\n");
    sb.append("    loanOutstandingBalance: ").append(toIndentedString(loanOutstandingBalance)).append("\n");
    sb.append("    dateType: ").append(toIndentedString(dateType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

