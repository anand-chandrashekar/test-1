package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis   {
  @JsonProperty("consumerLoanFulfillmentArrangementInstanceAnalysisReference")
  private String consumerLoanFulfillmentArrangementInstanceAnalysisReference = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceAnalysisReportType")
  private String consumerLoanFulfillmentArrangementInstanceAnalysisReportType = null;

  @JsonProperty("consumerLoanFulfillmentArrangementInstanceAnalysisParameters")
  private String consumerLoanFulfillmentArrangementInstanceAnalysisParameters = null;

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysisReference(String consumerLoanFulfillmentArrangementInstanceAnalysisReference) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysisReference = consumerLoanFulfillmentArrangementInstanceAnalysisReference;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the control record instance analysis view 
   * @return consumerLoanFulfillmentArrangementInstanceAnalysisReference
  **/
  @ApiModelProperty(example = "752556", value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::ISO20022andUNCEFACT::Identifier  general-info: Reference to the control record instance analysis view ")


  public String getConsumerLoanFulfillmentArrangementInstanceAnalysisReference() {
    return consumerLoanFulfillmentArrangementInstanceAnalysisReference;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceAnalysisReference(String consumerLoanFulfillmentArrangementInstanceAnalysisReference) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysisReference = consumerLoanFulfillmentArrangementInstanceAnalysisReference;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysisReportType(String consumerLoanFulfillmentArrangementInstanceAnalysisReportType) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysisReportType = consumerLoanFulfillmentArrangementInstanceAnalysisReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available 
   * @return consumerLoanFulfillmentArrangementInstanceAnalysisReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available ")


  public String getConsumerLoanFulfillmentArrangementInstanceAnalysisReportType() {
    return consumerLoanFulfillmentArrangementInstanceAnalysisReportType;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceAnalysisReportType(String consumerLoanFulfillmentArrangementInstanceAnalysisReportType) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysisReportType = consumerLoanFulfillmentArrangementInstanceAnalysisReportType;
  }

  public CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis consumerLoanFulfillmentArrangementInstanceAnalysisParameters(String consumerLoanFulfillmentArrangementInstanceAnalysisParameters) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysisParameters = consumerLoanFulfillmentArrangementInstanceAnalysisParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) 
   * @return consumerLoanFulfillmentArrangementInstanceAnalysisParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) ")


  public String getConsumerLoanFulfillmentArrangementInstanceAnalysisParameters() {
    return consumerLoanFulfillmentArrangementInstanceAnalysisParameters;
  }

  public void setConsumerLoanFulfillmentArrangementInstanceAnalysisParameters(String consumerLoanFulfillmentArrangementInstanceAnalysisParameters) {
    this.consumerLoanFulfillmentArrangementInstanceAnalysisParameters = consumerLoanFulfillmentArrangementInstanceAnalysisParameters;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis = (CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis) o;
    return Objects.equals(this.consumerLoanFulfillmentArrangementInstanceAnalysisReference, crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis.consumerLoanFulfillmentArrangementInstanceAnalysisReference) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceAnalysisReportType, crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis.consumerLoanFulfillmentArrangementInstanceAnalysisReportType) &&
        Objects.equals(this.consumerLoanFulfillmentArrangementInstanceAnalysisParameters, crConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis.consumerLoanFulfillmentArrangementInstanceAnalysisParameters);
  }

  @Override
  public int hashCode() {
    return Objects.hash(consumerLoanFulfillmentArrangementInstanceAnalysisReference, consumerLoanFulfillmentArrangementInstanceAnalysisReportType, consumerLoanFulfillmentArrangementInstanceAnalysisParameters);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CRConsumerLoanFulfillmentArrangementRetrieveInputModelConsumerLoanFulfillmentArrangementInstanceAnalysis {\n");
    
    sb.append("    consumerLoanFulfillmentArrangementInstanceAnalysisReference: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceAnalysisReference)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceAnalysisReportType: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceAnalysisReportType)).append("\n");
    sb.append("    consumerLoanFulfillmentArrangementInstanceAnalysisParameters: ").append(toIndentedString(consumerLoanFulfillmentArrangementInstanceAnalysisParameters)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

