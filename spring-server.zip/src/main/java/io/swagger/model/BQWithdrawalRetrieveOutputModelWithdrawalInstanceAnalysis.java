package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-08-31T13:09:33.027Z")

public class BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis   {
  @JsonProperty("withdrawalInstanceAnalysisRecord")
  private Object withdrawalInstanceAnalysisRecord = null;

  @JsonProperty("withdrawalInstanceAnalysisReportType")
  private String withdrawalInstanceAnalysisReportType = null;

  @JsonProperty("withdrawalInstanceAnalysisParameters")
  private String withdrawalInstanceAnalysisParameters = null;

  @JsonProperty("withdrawalInstanceAnalysisReport")
  private Object withdrawalInstanceAnalysisReport = null;

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysisRecord(Object withdrawalInstanceAnalysisRecord) {
    this.withdrawalInstanceAnalysisRecord = withdrawalInstanceAnalysisRecord;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected 
   * @return withdrawalInstanceAnalysisRecord
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The inputs and results of the instance analysis that can be on-going, periodic and actual and projected ")


  public Object getWithdrawalInstanceAnalysisRecord() {
    return withdrawalInstanceAnalysisRecord;
  }

  public void setWithdrawalInstanceAnalysisRecord(Object withdrawalInstanceAnalysisRecord) {
    this.withdrawalInstanceAnalysisRecord = withdrawalInstanceAnalysisRecord;
  }

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysisReportType(String withdrawalInstanceAnalysisReportType) {
    this.withdrawalInstanceAnalysisReportType = withdrawalInstanceAnalysisReportType;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available 
   * @return withdrawalInstanceAnalysisReportType
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Code  general-info: The type of external performance analysis report available ")


  public String getWithdrawalInstanceAnalysisReportType() {
    return withdrawalInstanceAnalysisReportType;
  }

  public void setWithdrawalInstanceAnalysisReportType(String withdrawalInstanceAnalysisReportType) {
    this.withdrawalInstanceAnalysisReportType = withdrawalInstanceAnalysisReportType;
  }

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysisParameters(String withdrawalInstanceAnalysisParameters) {
    this.withdrawalInstanceAnalysisParameters = withdrawalInstanceAnalysisParameters;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) 
   * @return withdrawalInstanceAnalysisParameters
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Text  general-info: The selection parameters for the analysis (e.g. period, algorithm type) ")


  public String getWithdrawalInstanceAnalysisParameters() {
    return withdrawalInstanceAnalysisParameters;
  }

  public void setWithdrawalInstanceAnalysisParameters(String withdrawalInstanceAnalysisParameters) {
    this.withdrawalInstanceAnalysisParameters = withdrawalInstanceAnalysisParameters;
  }

  public BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis withdrawalInstanceAnalysisReport(Object withdrawalInstanceAnalysisReport) {
    this.withdrawalInstanceAnalysisReport = withdrawalInstanceAnalysisReport;
    return this;
  }

  /**
   * `status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate 
   * @return withdrawalInstanceAnalysisReport
  **/
  @ApiModelProperty(value = "`status: Not Mapped`  core-data-type-reference: BIAN::DataTypesLibrary::CoreDataTypes::UNCEFACT::Binary  general-info: The external analysis report in any suitable form including selection filters where appropriate ")


  public Object getWithdrawalInstanceAnalysisReport() {
    return withdrawalInstanceAnalysisReport;
  }

  public void setWithdrawalInstanceAnalysisReport(Object withdrawalInstanceAnalysisReport) {
    this.withdrawalInstanceAnalysisReport = withdrawalInstanceAnalysisReport;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis bqWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis = (BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis) o;
    return Objects.equals(this.withdrawalInstanceAnalysisRecord, bqWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis.withdrawalInstanceAnalysisRecord) &&
        Objects.equals(this.withdrawalInstanceAnalysisReportType, bqWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis.withdrawalInstanceAnalysisReportType) &&
        Objects.equals(this.withdrawalInstanceAnalysisParameters, bqWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis.withdrawalInstanceAnalysisParameters) &&
        Objects.equals(this.withdrawalInstanceAnalysisReport, bqWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis.withdrawalInstanceAnalysisReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(withdrawalInstanceAnalysisRecord, withdrawalInstanceAnalysisReportType, withdrawalInstanceAnalysisParameters, withdrawalInstanceAnalysisReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BQWithdrawalRetrieveOutputModelWithdrawalInstanceAnalysis {\n");
    
    sb.append("    withdrawalInstanceAnalysisRecord: ").append(toIndentedString(withdrawalInstanceAnalysisRecord)).append("\n");
    sb.append("    withdrawalInstanceAnalysisReportType: ").append(toIndentedString(withdrawalInstanceAnalysisReportType)).append("\n");
    sb.append("    withdrawalInstanceAnalysisParameters: ").append(toIndentedString(withdrawalInstanceAnalysisParameters)).append("\n");
    sb.append("    withdrawalInstanceAnalysisReport: ").append(toIndentedString(withdrawalInstanceAnalysisReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

